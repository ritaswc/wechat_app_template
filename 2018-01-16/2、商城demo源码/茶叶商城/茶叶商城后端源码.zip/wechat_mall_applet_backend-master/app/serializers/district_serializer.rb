class DistrictSerializer < ActiveModel::Serializer

end