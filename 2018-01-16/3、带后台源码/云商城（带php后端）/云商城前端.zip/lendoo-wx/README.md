## 请扫描下方二维码体验

![输入图片说明](https://static.oschina.net/uploads/img/201702/16103707_mrRD.jpg "在这里输入图片标题")

## 概览

![首页](https://static.oschina.net/uploads/img/201701/24201453_7EH9.png "在这里输入图片标题")

![分类](https://static.oschina.net/uploads/img/201701/24201505_ex9a.png "在这里输入图片标题")

![列表](https://static.oschina.net/uploads/img/201701/24201527_tdsD.png "在这里输入图片标题")

![购物车](https://static.oschina.net/uploads/img/201701/24201546_wcUk.png "在这里输入图片标题")

![我](https://static.oschina.net/uploads/img/201701/24201605_EhVL.png "在这里输入图片标题")

![收货地址](https://static.oschina.net/uploads/img/201701/24201616_hSyt.png "在这里输入图片标题")

![我的订单](https://static.oschina.net/uploads/img/201701/24201629_LK2X.png "在这里输入图片标题")

## 1.购物车

![git](https://static.oschina.net/uploads/img/201610/27155649_MeBK.gif "效果展示")

教程详见：[https://my.oschina.net/huangxiujie/blog/759693](https://my.oschina.net/huangxiujie/blog/759693)

## 2.地址三级联动

![git](https://static.oschina.net/uploads/img/201612/30102738_A3dt.gif "效果展示")

教程详见：

[https://my.oschina.net/huangxiujie/blog/809226](https://my.oschina.net/huangxiujie/blog/809226)

[https://my.oschina.net/huangxiujie/blog/812791](https://my.oschina.net/huangxiujie/blog/812791)

[https://my.oschina.net/huangxiujie/blog/815842](https://my.oschina.net/huangxiujie/blog/815842)

[https://my.oschina.net/huangxiujie/blog/816362](https://my.oschina.net/huangxiujie/blog/816362)

## 3.微信支付

![输入图片说明](https://static.oschina.net/uploads/img/201701/19155702_xIbI.gif "在这里输入图片标题")

教程详见：[https://my.oschina.net/huangxiujie/blog/817654](https://my.oschina.net/huangxiujie/blog/817654)

## 4.下拉筛选

![git](https://static.oschina.net/uploads/img/201610/08171205_p1hX.gif "效果展示")

LeanCloud数据包下载：[https://pan.baidu.com/s/1nvPmcsx](https://pan.baidu.com/s/1nvPmcsx)

教程详见：[https://my.oschina.net/huangxiujie/blog/755324](https://my.oschina.net/huangxiujie/blog/760429)

后台源码：[https://git.oschina.net/dotton/lendoo-web](https://git.oschina.net/dotton/lendoo-web)

对移动开发有兴趣的朋友可以关注我的公众号【huangxiujie85】与我交流讨论，给我留言或文章评论。

![公众号](https://static.oschina.net/uploads/img/201610/07111145_qD6d.jpg "二维码")