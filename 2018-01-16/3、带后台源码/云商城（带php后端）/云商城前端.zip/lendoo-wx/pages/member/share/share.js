Page({
	onLoad: function (options) {
		this.setData({
			uid: 123456
		});
	}
});