﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace jianyuejizhang.Model
{
    public class UserLogin_Model : Base_Model
    {
       
    }
}