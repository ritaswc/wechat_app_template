//index.js
//获取应用实例
var app = getApp()
Page({
  onShareAppMessage: function () {
    return {
      title: app.globalData.shareSetting.title,
      path: app.globalData.shareSetting.path,
      success: function (res) {
        // 分享成功
      },
      fail: function (res) {
        // 分享失败
      }
    }
  },
  onLoad: function (options) {
    wx.showShareMenu()
    let windowHeight;
    wx.getSystemInfo({
      success: function (res) {
        /*console.log('wx.getSystemInfo model', res.model)
        console.log('wx.getSystemInfo pixelRatio', res.pixelRatio)
        console.log('wx.getSystemInfo windowWidth', res.windowWidth)
        console.log('wx.getSystemInfo windowHeight', res.windowHeight)
        console.log('wx.getSystemInfo language', res.language)
        console.log('wx.getSystemInfo version', res.version)*/
        windowHeight = res.windowHeight;
      }
    })
    console.log('onLoad')
    var that = this;
    that.setData({
      display: 'none',
      windowHeight: windowHeight,
      setting_status: 0,
      font_size: app.globalData.localStorage.style.font_size || 38,
      background_color_idx: app.globalData.localStorage.style.background_color_idx || 6,
      style_font_size: '',
      style_background_color: '',
      scroll_top: 0,
      flex_turnpage_area_hidden: true,
      //是否已滚动到底部
      isscrolltolower: false,
      //预加载的下一章的数据
      remoteDataByNextChapter: {},
      setTimeFlag: -1
    })
    this.settingFunc(-1);
    this.getData(options.link);
  },
  getData(remoteUrl, isNextlink) {
    let that = this;
    console.info('******remoteDataByNextChapter', that.data.remoteDataByNextChapter, remoteUrl, !!isNextlink);
    if (!!that.data.remoteDataByNextChapter.data && !!isNextlink) {
      console.info('******************* 直接从预加载中数据取出')
      that.setPageData(that.data.remoteDataByNextChapter, remoteUrl);
      that.setData({
        remoteDataByNextChapter: {}
      })
      return;
      //console.info('下一章', that.data.remoteDataByNextChapter.data.data.nextlink);
    }

    console.info('******************* 需要请求服务器', remoteUrl)
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      duration: 10000
    })
    //let data = {}
    wx.request({
      url: app.globalData.domain + '/book/GetBookContent',
      data: { url: remoteUrl },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.info('数据请求结果', res);
        that.setPageData(res, remoteUrl);
      },
      fail: function (res) {
        console.info('fail', res)
        that.setData({
          aaa: 'is fail：' + res.errMsg
        })
      }
    })
  },
  setPageData: function (res, curremoteUrl) {
    console.info('setPageData', res)
    let that = this;
    if (that.data.setTimeFlag > 0) {
      clearTimeout(that.data.setTimeFlag);
    }
    let response = res.data;
    if (response.code > 0) {
      app.globalData.shareSetting.title = '喵喵看书 - ' + response.data.bookname + ': ' + response.data.chaptername;
      app.globalData.shareSetting.path = '/pages/read/index?link=' + curremoteUrl;
      that.setData({
        bookObj: response.data,
        display: 'block',
        scroll_top_turnpage: 0
      })
      //console.info('aaa1', response.data)
      wx.setNavigationBarTitle({
        title: response.data.chaptername + '-' + response.data.bookname + ' - 喵喵看书'
      })
      app.resetHistoryList({
        url: '../read/index?link=' + curremoteUrl,
        chaptername: response.data.chaptername,
        bookname: response.data.bookname
      });
      wx.hideToast();
      wx.setStorageSync(app.globalData.localStorageKey, app.globalData.localStorage);
      let _setTimeFlag = setTimeout(function () {
        //预加载下一章
        that.loadNextChapter(response.data.nextlink);
      }, 5000);
      that.setData({
        setTimeFlag: _setTimeFlag
      })
    } else {
      console.log('err', response)
      wx.hideToast()
      //失败就调回上个页面
      wx.redirectTo({
        url: '../intro/index?link=' + curremoteUrl
      })
    }
  },
  bindPrevTap(e) {
    //不知道为什么只要url包含.html就会不能跳转，所以这里先替换一下
    let link = encodeURIComponent(e.currentTarget.dataset.link.replace(new RegExp(/.html/g), '*html'))
    console.info('bindPrevTap', link);
    /*
    wx.redirectTo({
      url: '../read/index?link=' + link
    })
    */
    this.setData({
      remoteDataByNextChapter: {}
    })
    this.getData(link);
  },
  bindChapterTap(e) {
    //不知道为什么只要url包含.html就会不能跳转，所以这里先替换一下
    let link = encodeURIComponent(e.currentTarget.dataset.link.replace(new RegExp(/.html/g), '*html'))
    console.info('bindChapterTap', link);
    /*
    wx.redirectTo({
      url: '../intro/index?link=' + link
    })*/
    this.getData(link);
  },
  bindNextTap(e) {
    //不知道为什么只要url包含.html就会不能跳转，所以这里先替换一下
    let link = encodeURIComponent(e.currentTarget.dataset.link.replace(new RegExp(/.html/g), '*html'))
    console.info('bindNextTap', link);
    /*
    wx.redirectTo({
      url: '../read/index?link=' + link
    })*/
    this.getData(link, true);
  },
  bindSettingtap: function () {
    this.data.setting_status = (this.data.setting_status + 1) % 2;
    this.settingClick(this.data.setting_status);
  },
  settingClick: function (setting_status) {
    this.setData({
      css_display: setting_status == 0 ? 'none' : 'block'
    })
  },
  bindSettingitemTap: function (e) {
    //console.info('bindSettingitemTap', e);
    let idx = parseInt(e.target.dataset.item);
    this.settingFunc(idx);
  },
  settingFunc: function (idx) {
    //let _style_font_size = '', _style_background_color = '';
    let background_colors = ['#000', '#333', '#666', '#999', '#bbb', '#ddd', '#eee', '#fff'];
    let font_colors = ['#aaa', '#aaa', '#000', '#000', '#000', '#000', '#000', '#000'];
    let link_colors = ['#aaa', '#aaa', '#000', '#000', '#000', '#000', '#000', '#000'];
    let font_color = '#000!important;';
    let link_color = '#4183c4';
    switch (idx) {
      case -1:
        this.data.style_background_color = 'background-color:' + background_colors[this.data.background_color_idx] + '!important;';
        this.data.style_font_size = 'font-size:' + this.data.font_size + 'rpx!important;';
        font_color = 'color:' + font_colors[this.data.background_color_idx] + '!important;';
        link_color = 'color:' + link_colors[this.data.background_color_idx] + '!important;';
        console.info(-1, this.data.style_background_color, this.data.style_font_size, font_color)
        break;
      case 0:
        wx.redirectTo({
          url: '../home/index'
        })
        break;
      case 1:
        this.data.font_size = this.data.font_size + 2;
        this.data.style_font_size = 'font-size:' + this.data.font_size + 'rpx!important;';
        app.globalData.localStorage.style.font_size = this.data.font_size;
        break;
      case 2:
        this.data.font_size = this.data.font_size - 2;
        this.data.style_font_size = 'font-size:' + this.data.font_size + 'rpx!important;';
        app.globalData.localStorage.style.font_size = this.data.font_size;
        break;
      case 3:
        if (this.data.background_color_idx > 0) {
          this.data.background_color_idx = this.data.background_color_idx - 1;
        }
        this.data.style_background_color = 'background-color:' + background_colors[this.data.background_color_idx] + '!important;';
        font_color = 'color:' + font_colors[this.data.background_color_idx] + '!important;';
        link_color = 'color:' + link_colors[this.data.background_color_idx] + '!important;';
        app.globalData.localStorage.style.background_color_idx = this.data.background_color_idx;
        break;
      case 4:
        if (this.data.background_color_idx < background_colors.length - 1) {
          this.data.background_color_idx = this.data.background_color_idx + 1;
        }
        this.data.style_background_color = 'background-color:' + background_colors[this.data.background_color_idx] + '!important;';
        font_color = 'color:' + font_colors[this.data.background_color_idx] + '!important;';
        link_color = 'color:' + link_colors[this.data.background_color_idx] + '!important;';
        app.globalData.localStorage.style.background_color_idx = this.data.background_color_idx;
        break;
    }
    this.setData({
      css_body: this.data.style_background_color,
      css_font_size: this.data.style_font_size,
      css_font_color: font_color,
      css_link_color: link_color
    })
    wx.setStorageSync(app.globalData.localStorageKey, app.globalData.localStorage);
    //console.info('style', '{{style}}', this.data.style_font_size, this.data.style_background_color, this.data.background_color_idx);
  },
  bindTrunpageTap: function (e) {
    //console.info('bindTrunpageTap', e);
    let idx = parseInt(e.target.dataset.item);
    let link;
    switch (idx) {
      case 0:
        link = encodeURIComponent(e.target.dataset.link.replace(new RegExp(/.html/g), '*html'))
        //console.info('上一章', link);
        /*
        wx.redirectTo({
          url: '../read/index?link=' + link
        })*/
        this.setData({
          remoteDataByNextChapter: {}
        })
        this.getData(link);
        break;
      case 1:
        link = encodeURIComponent(e.target.dataset.link.replace(new RegExp(/.html/g), '*html'))
        //console.info('下一章', link);
        /*
        wx.redirectTo({
          url: '../read/index?link=' + link
        })*/
        this.getData(link, true);
        break;
    }
  },
  bindscrolltolower: function () {
    this.setData({
      isscrolltolower: true
    })
  },
  bindscroll: function (e) {
    //console.info('bindscroll', e);
    var scrollTop = e.detail.scrollTop;
    this.setData({
      scroll_top: scrollTop,
      isscrolltolower: false
    })
  },
  bindScrollTap: function (e) {
    //console.info('bindScrollTap', e);
    let clientY = e.touches[0].clientY;
    if (clientY < this.data.windowHeight / 3) {
      //上
      if (this.data.scroll_top > 0) {
        this.data.scroll_top = this.data.scroll_top - this.data.windowHeight;
        this.setData({
          scroll_top_turnpage: this.data.scroll_top,
          isscrolltolower: false
        })
      }
    }
    else if (clientY > this.data.windowHeight / 3 && clientY < this.data.windowHeight / 3 * 2) {
      //中
      this.data.flex_turnpage_area_hidden = !this.data.flex_turnpage_area_hidden;
      this.setData({
        flex_turnpage_area: this.data.flex_turnpage_area_hidden ? 'none' : 'block'
      })
    }
    else {
      //下
      if (!this.data.isscrolltolower) {
        this.data.scroll_top = this.data.scroll_top + this.data.windowHeight;
        this.setData({
          scroll_top_turnpage: this.data.scroll_top
        })
      }
    }
  },
  loadNextChapter: function (remoteUrl) {
    var that = this;
    wx.request({
      url: app.globalData.domain + '/book/GetBookContent',
      data: { url: remoteUrl },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        //console.info('loadNextChapter', res, res.data)
        let response = res.data;
        if (response.code > 0) {
          that.setData({
            remoteDataByNextChapter: res
          })
        }
        console.info('loadNextChapter 已预加载下一章数据', that.data.remoteDataByNextChapter);
      }
    });
  }
})