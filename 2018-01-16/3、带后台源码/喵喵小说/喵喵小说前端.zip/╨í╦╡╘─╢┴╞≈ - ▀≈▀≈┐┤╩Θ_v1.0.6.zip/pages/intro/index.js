//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    motto: '',
    userInfo: {},
    bookInfo: {}
  },
  onShareAppMessage: function () {
    return {
      title: app.globalData.shareSetting.title,
      path: app.globalData.shareSetting.path,
      success: function (res) {
        // 分享成功
      },
      fail: function (res) {
        // 分享失败
      }
    }
  },
  onLoad: function (options) {
    console.log('onLoad', options)
    wx.showShareMenu()
    var that = this;
    that.setData({
      style_display: 'none'
    })
    //调用应用实例的方法获取全局数据
    app.getUserInfo(function (userInfo) {
      //更新数据
      that.setData({
        userInfo: userInfo
      })
    })
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      duration: 10000
    })
    this.getData(options.link)
  },
  getData(remoteUrl) {
    if (remoteUrl == undefined || remoteUrl == '') {
      return;
    }
    let that = this;
    let data = {}
    wx.request({
      url: app.globalData.domain + '/book/GetBookChapter',
      data: { url: remoteUrl },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.info('数据请求结果', res);
        let response = res.data;
        app.globalData.shareSetting.title = '喵喵看书 - ' + response.data.bookname;
        app.globalData.shareSetting.path = '/pages/intro/index?link=' + remoteUrl;
        if (response.code > 0) {
          /*that.setData({
            books: response.data.list,
            pagenum: response.data.pn,
            count: response.data.count
          })*/
          that.setData({
            bookInfo: {
              bookname: response.data.bookname,
              author: response.data.author,
              status: response.data.status,
              last_update_time: response.data.last_update_time,
              last_update_chapter: response.data.last_update_chapter,
              last_update_chapterlink: response.data.last_update_chapterlink,
              intro: response.data.intro,
              chapters: response.data.list
            }
          })
          wx.hideToast()
          //console.info('aaa111', response.data.last_update_chapterlink)
        } else {
          console.log('err', response)
          wx.hideToast()
        }
        that.setData({
          style_display: 'block'
        })
      }
    })
  },
  bindReadTap(e) {
    let last_update_chapterlink = encodeURIComponent(e.currentTarget.dataset.last_update_chapterlink.replace(new RegExp(/.html/g), '*html'))
    //console.info('bindReadTap', last_update_chapterlink);
    wx.navigateTo({
      url: '../read/index?link=' + last_update_chapterlink
    })
  },
  bindChapterTap(e) {
    let chapterlink = encodeURIComponent(e.currentTarget.dataset.chapterlink.replace(new RegExp(/.html/g), '*html'))
    //console.info('bindChapterTap', chapterlink);
    wx.navigateTo({
      url: '../read/index?link=' + chapterlink
    })
  },
  bindBackTap(e) {
    wx.redirectTo({
      url: '../search/index?s=' + encodeURIComponent(this.data.bookInfo.bookname)
    })
  }
})