﻿
namespace Cat.Foundation.SiteConfig.Models
{
    /// <summary>
    /// 小说配置项
    /// </summary>
    public class BookSettingsConfig
    {
        /// <summary>
        /// 抓取来源：新笔趣阁、一本读全本小说网
        /// </summary>
        public string Crawler;
    }
}
