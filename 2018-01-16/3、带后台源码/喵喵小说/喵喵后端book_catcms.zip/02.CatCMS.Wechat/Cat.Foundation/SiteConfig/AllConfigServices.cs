﻿using Cat.Foundation.SiteConfig.Models;

namespace Cat.Foundation.SiteConfig
{
    /// <summary>
    /// 所有配置文件服务类（默认使用缓存，缓存一小时）
    /// </summary>
    public class AllConfigServices
    {
        /// <summary>
        /// 网站配置
        /// </summary>
        public static CatSettingsConfig CatSettingsConfig
        {
            get
            {
                return SiteConfig<CatSettingsConfig>.Instance;
            }
        }
        /// <summary>
        /// 图片上传配置
        /// </summary>
        public static ImageUploadBaseConfig ImageUploadConfig
        {
            get
            {
                return SiteConfig<ImageUploadBaseConfig>.Instance;
            }
        }
        ///// <summary>
        ///// 新闻图片上传配置
        ///// </summary>
        //public static NewsImageUploadConfig NewsImageUploadConfig
        //{
        //    get
        //    {
        //        return SiteConfig<NewsImageUploadConfig>.Instance;
        //    }
        //}
        /// <summary>
        /// 文件上传配置
        /// </summary>
        public static FileUploadConfig FileUploadConfig
        {
            get
            {
                return SiteConfig<FileUploadConfig>.Instance;
            }
        }
        /// <summary>
        /// 小说配置项
        /// </summary>
        public static BookSettingsConfig BookSettingsConfig
        {
            get
            {
                return SiteConfig<BookSettingsConfig>.Instance;
            }
        }
    }
}