﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat.Enums
{
    /// <summary>
    /// 账户（用户、角色）状态, 0:启用, 1:禁用
    /// </summary>
    public enum AccountState
    {
        /// <summary>
        /// 启用
        /// </summary>
        Enable,
        /// <summary>
        /// 禁用
        /// </summary>
        Disable
    }
}
