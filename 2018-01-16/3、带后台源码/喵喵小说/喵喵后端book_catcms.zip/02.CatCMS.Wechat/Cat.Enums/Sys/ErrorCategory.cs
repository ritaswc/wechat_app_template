﻿namespace Cat.Enums
{
    /// <summary>
    /// 异常信息分类
    /// </summary>
    public enum ErrorCategory
    {
        /// <summary>
        /// 其他
        /// </summary>
        Other,
        /// <summary>
        /// 来自后台
        /// </summary>
        FromAdmin,
        /// <summary>
        /// 来自前台
        /// </summary>
        FromUser
    }
}
