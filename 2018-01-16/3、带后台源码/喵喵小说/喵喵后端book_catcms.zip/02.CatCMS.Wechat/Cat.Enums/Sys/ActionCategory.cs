﻿namespace Cat.Enums
{
    /// <summary>
    /// 操作分类
    /// </summary>
    public enum ActionCategory
    {
        /// <summary>
        /// 其他
        /// </summary>
        Other,
        /// <summary>
        /// 新增
        /// </summary>
        Add,
        /// <summary>
        /// 删除
        /// </summary>
        Del,
        /// <summary>
        /// 更新
        /// </summary>
        Update,
        /// <summary>
        /// 新增/更新
        /// </summary>
        AddorUpdate,
        /// <summary>
        /// 查阅
        /// </summary>
        View,
        /// <summary>
        /// 导出
        /// </summary>
        Export
    }
}
