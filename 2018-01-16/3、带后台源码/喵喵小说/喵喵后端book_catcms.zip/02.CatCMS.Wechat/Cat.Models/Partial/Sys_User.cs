﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Cat.Models
{
    public partial class Sys_User
    {
        [NotMapped]
        public string Role_Id { get; set; }
        [NotMapped]
        public string Role_Name { get; set; }
        /// <summary>
        /// 登录时间
        /// </summary>
        [NotMapped]
        public DateTime Login_Time { get; set; }
    }
}
