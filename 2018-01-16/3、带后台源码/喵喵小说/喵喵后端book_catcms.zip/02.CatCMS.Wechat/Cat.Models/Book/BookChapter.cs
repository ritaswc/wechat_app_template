﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat.Models.Book
{
    /// <summary>
    /// 书本章节列表数据实体
    /// </summary>
    public class BookChapter
    {
        /// <summary>
        /// 计数(章节数)
        /// </summary>
        public int count { get; set; }
        /// <summary>
        /// 书名
        /// </summary>
        public string bookname { get; set; }
        /// <summary>
        /// 作者
        /// </summary>
        public string author { get; set; }
        /// <summary>
        /// 小说状态：连载中、完本...
        /// </summary>
        public string status { get; set; }
        /// <summary>
        /// 最近更新
        /// </summary>
        public string last_update_time { get; set; }
        /// <summary>
        /// 最新章节
        /// </summary>
        public string last_update_chapter { get; set; }
        /// <summary>
        /// 最新章节的链接地址
        /// </summary>
        public string last_update_chapterlink { get; set; }
        /// <summary>
        /// 介绍
        /// </summary>
        public string intro { get; set; }
        /// <summary>
        /// 章节数据列表
        /// </summary>
        public List<chapterlist> list { get; set; }
        public class chapterlist
        {
            /// <summary>
            /// 章节链接
            /// </summary>
            public string chapterlink { get; set; }
            /// <summary>
            /// 章节名称
            /// </summary>
            public string chaptername { get; set; }
        }
    }
}
