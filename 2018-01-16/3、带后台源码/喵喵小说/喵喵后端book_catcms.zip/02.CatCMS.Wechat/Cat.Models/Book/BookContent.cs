﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat.Models.Book
{
    /// <summary>
    /// 书本的内容数据实体
    /// </summary>
    public class BookContent
    {
        /// <summary>
        /// 小说名称
        /// </summary>
        public string bookname { get; set; }
        /// <summary>
        /// 章节名称
        /// </summary>
        public string chaptername { get; set; }
        /// <summary>
        /// 章节链接
        /// </summary>
        public string chapterlink { get; set; }
        /// <summary>
        /// 上一章
        /// </summary>
        public string prevlink { get; set; }
        /// <summary>
        /// 下一章
        /// </summary>
        public string nextlink { get; set; }
        /// <summary>
        /// 内容
        /// </summary>
        public string content { get; set; }
    }
}
