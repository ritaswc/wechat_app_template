﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat.Models.Book
{
    /// <summary>
    /// 书本列表数据实体
    /// </summary>
    public class BookList
    {
        /// <summary>
        /// 计数(搜索结果)
        /// </summary>
        public int count { get; set; }
        /// <summary>
        /// 页码
        /// </summary>
        public int pn { get; set; }
        /// <summary>
        /// 页大小
        /// </summary>
        public int ps { get; set; }
        /// <summary>
        /// 数据列表
        /// </summary>
        public List<booklist> list { get; set; }
        public class booklist
        {
            /// <summary>
            /// 书名
            /// </summary>
            public string bookname { get; set; }
            /// <summary>
            /// 作者
            /// </summary>
            public string author { get; set; }
            /// <summary>
            /// 封面图片
            /// </summary>
            public string coverimg { get; set; }
            /// <summary>
            /// 小说类型：玄幻、仙侠、都市...
            /// </summary>
            public string booktype { get; set; }
            /// <summary>
            /// 最近更新
            /// </summary>
            public string last_update_time { get; set; }
            /// <summary>
            /// 最新章节
            /// </summary>
            public string last_update_chapter { get; set; }
            /// <summary>
            /// 介绍
            /// </summary>
            public string intro { get; set; }
            /// <summary>
            /// 小说链接
            /// </summary>
            public string booklink { get; set; }
            /// <summary>
            /// 章节链接
            /// </summary>
            public string chapterlink { get; set; }
        }
    }
}
