﻿using Cat.Foundation.SiteConfig;
using Cat.Utility;
using System;
using System.Web;
using System.Web.Security;

namespace Cat.Services
{
    /// <summary>
    /// 身份验证票据帮助类(后台)
    /// </summary>
    /// <typeparam name="T">应传入用户信息实体类</typeparam>
    public class SysFormsAuthenticationHelper<T> where T : class
    {
        private readonly static string FormsCookieName = AllConfigServices.CatSettingsConfig.AdminLoginCookieKey;

        /// <summary>
        /// 创建身份验证票据
        /// </summary>
        /// <param name="userId">用户id</param>
        /// <param name="t">用户信息实例</param>
        public static bool SetAuthCookie(string userId, T t)
        {
            try
            {
                string userData = Serializer.JsonSerialize(t);
                userData = userData.Length > 800 ? string.Empty : userData; //防止最终存储的cookie的值大小超过浏览器限制
                FormsAuthenticationTicket ticket = new FormsAuthenticationTicket
                         (1,
                             userId,
                             DateTime.Now,
                             DateTime.Now.AddHours(AllConfigServices.CatSettingsConfig.AdminLoginCookieHours),
                             true,
                             userData,
                             "/"
                         );
                var cookie = new HttpCookie(FormsCookieName, FormsAuthentication.Encrypt(ticket));
                cookie.HttpOnly = true;
                cookie.Expires = DateTime.Now.AddHours(AllConfigServices.CatSettingsConfig.AdminLoginCookieHours);
                HttpContext.Current.Response.Cookies.Add(cookie);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 获取与 Forms 身份验证票相关联的用户Id
        /// </summary>
        /// <returns></returns>
        public static string GetUserId()
        {
            var ticket = GetTiket();
            return ticket == null ? null : ticket.Name;
        }

        /// <summary>
        /// 获取一个存储在票证中的用户信息的实例
        /// </summary>
        /// <returns></returns>
        public static T GetUserInstance()
        {
            var ticket = GetTiket();
            if (ticket == null)
                return null;
            else if (string.IsNullOrEmpty(ticket.UserData))
            {
                string userId = GetUserId();
                return AllServices.SysUserService.GetByUserId(userId) as T;
            }
            return Serializer.JsonDeserialize<T>(ticket.UserData);
        }

        private static FormsAuthenticationTicket GetTiket()
        {
            var cookie = HttpContext.Current.Request.Cookies[FormsCookieName];
            return cookie == null ? null : FormsAuthentication.Decrypt(cookie.Value);
        }

        /// <summary>
        /// 登出
        /// </summary>
        public static void SignOut()
        {
            var cookie = HttpContext.Current.Response.Cookies.Get(FormsCookieName);
            cookie.Expires = DateTime.Now.AddDays(-1);
            HttpContext.Current.Response.Cookies.Add(cookie);
        }

    }
}