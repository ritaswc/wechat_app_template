﻿using Cat.Foundation.SiteConfig;
using Cat.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat.Services
{
    /// <summary>
    /// 前台辅助类
    /// </summary>
    public class WebAssist
    {
        /// <summary>
        /// 修改前台的权限js脚本内容
        /// </summary>
        public static void ModifyPermissionJs()
        {
            //更新权限配置脚本，脚本路径：/Scripts/permission.js
            var userInstance = AllServices.SysUserService.GetUserByCookie();
            var user_Id = userInstance.User_Id;

            List<Models.Sys_Action_Permission> userPermissionList;

            if (userInstance.User_Id.ToLower() == AllConfigServices.CatSettingsConfig.SuperAdminAccount)
            {
                userPermissionList = AllServices.SysActionPermissionService.GetAllByCache();
            }
            else
            {
                userPermissionList = AllServices.SysActionPermissionService.GetAllByUserId(user_Id).ToList();
            }
            FileHelper.WriteTxt(PathHelper.GetMapPath("/Scripts/permission.js"), string.Format("window.localStorage.cat_action_permissions=JSON.stringify({0})", userPermissionList.ToJson()), Encoding.UTF8);
        }
    }
}
