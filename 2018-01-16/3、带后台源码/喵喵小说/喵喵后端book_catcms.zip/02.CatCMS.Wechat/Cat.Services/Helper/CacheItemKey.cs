﻿
namespace Cat.Services
{
    /// <summary>
    /// 每一个缓存项的key前缀应包含“cache_key_admin_”
    /// </summary>
    public class CacheItemKey
    {        
        /// <summary>
        /// 操作权限列表
        /// </summary>
        public static string Sys_Action_Permissions
        {
            get { return "cache_key_admin_Sys_Action_Permissions"; }
        }
        /// <summary>
        /// 菜单权限列表
        /// </summary>
        public static string Sys_Menu_Permissions
        {
            get { return "cache_key_admin_Sys_Menu_Permissions"; }
        }
        /// <summary>
        /// 系统用户操作权限
        /// </summary>
        public static string Sys_User_Action_Permissions
        {
            get { return "cache_key_admin_Sys_User_Action_Permissions"; }
        }
        /// <summary>
        /// 系统角色操作权限
        /// </summary>
        public static string Sys_Role_Action_Permissions
        {
            get { return "cache_key_admin_Sys_Role_Action_Permissions"; }
        }
        /// <summary>
        /// 系统角色用户关系
        /// </summary>
        public static string Sys_Role_User
        {
            get { return "cache_key_admin_Sys_Role_User"; }
        }
    }
}
