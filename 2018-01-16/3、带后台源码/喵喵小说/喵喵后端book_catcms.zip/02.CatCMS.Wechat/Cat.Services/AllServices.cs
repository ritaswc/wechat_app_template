﻿
namespace Cat.Services
{
    public class AllServices
    {
        #region Sys

        /// <summary>
        /// 操作日志服务类
        /// </summary>
        public static SysActionLogService ActionLogService
        {
            get { return new SysActionLogService(); }
        }
        /// <summary>
        /// 异常日志服务类
        /// </summary>
        public static SysErrorLogService SysErrorLogService
        {
            get { return new SysErrorLogService(); }
        }
        /// <summary>
        /// 登录日志服务类
        /// </summary>
        public static SysLoginLogService SysLoginLogService
        {
            get { return new SysLoginLogService(); }
        }
        /// <summary>
        /// 后台用户服务类
        /// </summary>
        public static SysUserService SysUserService
        {
            get { return new SysUserService(); }
        }
        /// <summary>
        /// 角色服务类
        /// </summary>
        public static SysRoleService SysRoleService
        {
            get { return new SysRoleService(); }
        }
        /// <summary>
        /// 操作权限服务类
        /// </summary>
        public static SysActionPermissionService SysActionPermissionService
        {
            get { return new SysActionPermissionService(); }
        }
        /// <summary>
        /// 菜单权限服务类
        /// </summary>
        public static SysMenuPermissionService SysMenuPermissionService
        {
            get { return new SysMenuPermissionService(); }
        }
        /// <summary>
        /// 角色用户关联服务类
        /// </summary>
        public static SysRoleUserService SysRoleUserService
        {
            get { return new SysRoleUserService(); }
        }
        /// <summary>
        /// SysRoleActionPermissionService
        /// </summary>
        public static SysRoleActionPermissionService SysRoleActionPermissionService
        {
            get { return new SysRoleActionPermissionService(); }
        }
        /// <summary>
        /// SysUserActionPermissionService
        /// </summary>
        public static SysUserActionPermissionService SysUserActionPermissionService
        {
            get { return new SysUserActionPermissionService(); }
        }
        /// <summary>
        /// 文件上传记录服务类
        /// </summary>
        public static SysUploadRecordService SysUploadRecordService
        {
            get { return new SysUploadRecordService(); }
        }
        /// <summary>
        /// 导出Excel服务类
        /// </summary>
        public static SysDataExportService SysDataExportService
        {
            get { return new SysDataExportService(); }
        }

        #endregion

        #region Common

        /// <summary>
        /// 上传图片处理服务类
        /// </summary>
        public static ImageUploadService ImageUploadService
        {
            get { return new ImageUploadService(); }
        }
        /// <summary>
        /// 上传文件处理服务类
        /// </summary>
        public static FileUploadService FileUploadService
        {
            get { return new FileUploadService(); }
        }

        #endregion

        #region Custom

        /// <summary>
        /// 项目信息表服务类
        /// </summary>
        public static CatProjectService CatProjectService
        {
            get { return new CatProjectService(); }
        }
        /// <summary>
        /// 项目浏览记录表服务类
        /// </summary>
        public static CatProjectPageViewRecordService CatProjectPageViewRecordService
        {
            get { return new CatProjectPageViewRecordService(); }
        }
        /// <summary>
        /// 项目下载记录表服务类
        /// </summary>
        public static CatProjectDownloadRecordService CatProjectDownloadRecordService
        {
            get { return new CatProjectDownloadRecordService(); }
        }
        ///// <summary>
        ///// book服务类
        ///// </summary>
        //public static BookService BookService
        //{
        //    get { return new BookService(); }
        //}

        #endregion

    }
}
