﻿using Cat.Utility;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat.Services
{
    public class BookService
    {
        public string Search_List(string url)
        {
            HtmlWeb webClient = new HtmlWeb();
            HtmlDocument doc = webClient.Load(url);
            var res = doc.DocumentNode.SelectSingleNode("//div[@id='content']").InnerHtml;



            return res;
        }

        public string Search_Chapter(string url)
        {
            HtmlWeb webClient = new HtmlWeb();
            HtmlDocument doc = webClient.Load(url);
            var res = doc.DocumentNode.SelectSingleNode("//div[@id='content']").InnerHtml;



            return res;
        }

        public string Search_Content(string url)
        {
            HtmlWeb webClient = new HtmlWeb();
            HtmlDocument doc = webClient.Load(url);
            var res = doc.DocumentNode.SelectSingleNode("//div[@id='content']").InnerHtml;



            return res;
        }
    }
}
