﻿using Cat.Utility;
using EntityFramework.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Cat.Services
{
    /// <summary>
    /// 项目下载记录表服务类
    /// </summary>
    public class CatProjectDownloadRecordService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        /// <summary>
        /// 根据id获取项目下载记录信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Models.Cat_Project_Download_Record GetById(string id)
        {
            return db.Cat_Project_Download_Record.Where(w => w.Project_Download_Record_Id == id).FirstOrDefault();
        }

        /// <summary>
        /// 加载分页数据
        /// </summary>
        /// <param name="pn"></param>
        /// <param name="ps"></param>
        /// <param name="whereLambda"></param>
        /// <param name="dicOrderBy"></param>
        /// <returns></returns>
        public Page<Models.Cat_Project_Download_Record> GetByPage(int pn, int ps,
            Expression<Func<Models.Cat_Project_Download_Record, bool>> whereLambda = null,
            Dictionary<string, string> dicOrderBy = null)
        {
            if (whereLambda == null) whereLambda = u => 1 == 1;

            var q = db.Cat_Project_Download_Record.Where(whereLambda).OrderBy(dicOrderBy);
            var list = q.Skip((pn - 1) * ps).Take(ps).ToList();
            return new Page<Models.Cat_Project_Download_Record>(pn, ps, q.Count(), list);
        }

        /// <summary>
        /// 新增项目下载记录
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public CommonResult Add(Models.Cat_Project_Download_Record model)
        {
            model.Project_Download_Record_Id = ServiceHelper.GetKeyNum();
            model.Create_Time = DateTime.Now;
            db.Cat_Project_Download_Record.Add(model);
            db.SaveChanges();
            AllServices.ActionLogService.AddLog("新增项目下载记录", model.ToJson(), Enums.ActionCategory.Add);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 新增项目下载记录(同时更新项目的下载量)
        /// </summary>
        /// <param name="project_Id">项目表Id</param>
        /// <returns></returns>
        public CommonResult Add(string project_Id)
        {
            using (TransactionScope transaction = new TransactionScope())
            {

                var projectInstance = AllServices.CatProjectService.GetById(project_Id);
                if (projectInstance == null)
                {
                    return CommonResult.Instance("找不到对应的项目");
                }

                var ipInstance = IPHelper.GetIpDetail();
                //同一IP只能新增一次
                int pageViews = db.Cat_Project_Download_Record.Where(w => w.Project_Id == project_Id && w.Client_IP == ipInstance.ip).Count();
                if (pageViews > 0)
                {
                    return CommonResult.Instance("新增失败，同一个IP只保存一次下载记录");
                }

                projectInstance.Download_Times = projectInstance.Download_Times + 1;
                db.Entry(projectInstance).State = System.Data.Entity.EntityState.Modified;

                var model = db.Cat_Project_Download_Record.Add(new Models.Cat_Project_Download_Record()
                {
                    Project_Download_Record_Id = ServiceHelper.GetKeyNum(),
                    Project_Id = project_Id,
                    Client_IP = ipInstance.ip,
                    Country = ipInstance.country,
                    Province = ipInstance.province,
                    City = ipInstance.city,
                    District = ipInstance.district,
                    Create_Time = DateTime.Now
                });
                db.SaveChanges();
                AllServices.ActionLogService.AddLog("新增项目下载记录", model.ToJson(), Enums.ActionCategory.Add);

                transaction.Complete();
            }
            return CommonResult.Instance();
        }

    }
}