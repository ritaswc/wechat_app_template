﻿using Cat.Utility;
using EntityFramework.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Cat.Services
{
    /// <summary>
    /// 项目信息表服务类
    /// </summary>
    public class CatProjectService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        /// <summary>
        /// 根据Project_Id获取项目信息
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public Models.Cat_Project GetById(string projectId)
        {
            return db.Cat_Project.Where(w => w.Project_Id == projectId).FirstOrDefault();
        }

        /// <summary>
        /// 加载分页数据
        /// </summary>
        /// <param name="pn"></param>
        /// <param name="ps"></param>
        /// <param name="whereLambda"></param>
        /// <param name="dicOrderBy"></param>
        /// <returns></returns>
        public Page<Models.Cat_Project> GetByPage(int pn, int ps,
            Expression<Func<Models.Cat_Project, bool>> whereLambda = null,
            Dictionary<string, string> dicOrderBy = null)
        {
            if (whereLambda == null) whereLambda = u => 1 == 1;

            var q = db.Cat_Project.Where(whereLambda).OrderBy(dicOrderBy);
            var list = q.Skip((pn - 1) * ps).Take(ps).ToList();
            return new Page<Models.Cat_Project>(pn, ps, q.Count(), list);
        }

        /// <summary>
        /// 新增项目
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public CommonResult Add(Models.Cat_Project model)
        {
            if (IsRepeatProjectName(model.Project_Id, model.Project_Name))
            {
                return CommonResult.Instance("已存在此项目名，请换一个再试");
            }
            model.Project_Id = ServiceHelper.GetKeyNum();
            model.Create_Time = DateTime.Now;
            model.Update_Time = DateTime.Now;
            db.Cat_Project.Add(model);
            db.SaveChanges();
            AllServices.ActionLogService.AddLog("新增项目", model.ToJson(), Enums.ActionCategory.Add);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 更新项目
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public CommonResult Update(Models.Cat_Project model)
        {
            if (IsRepeatProjectName(model.Project_Id, model.Project_Name))
            {
                return CommonResult.Instance("已存在此项目名，请换一个再试");
            }

            db.Cat_Project.Where(w => w.Project_Id == model.Project_Id).Update(u => new Models.Cat_Project()
            {
                Project_Name = model.Project_Name,
                Lead = model.Lead,
                Static_Page_Path = model.Static_Page_Path,
                Sort_Num = model.Sort_Num,
                Update_Time = DateTime.Now
            });

            AllServices.ActionLogService.AddLog("更新项目信息", model.ToJson(), Enums.ActionCategory.Update);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 删除多个项目
        /// </summary>
        /// <param name="projectIds"></param>
        /// <returns></returns>
        public CommonResult Delete(string[] projectIds)
        {
            //删除项目
            db.Cat_Project.Where(w => projectIds.Contains(w.Project_Id)).Delete();
            AllServices.ActionLogService.AddLog("删除项目", string.Join(",", projectIds), Enums.ActionCategory.Del);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 检查是否已经有重复的项目名
        /// </summary>
        /// <param name="project_Id"></param>
        /// <param name="project_Name"></param>
        /// <returns></returns>
        public bool IsRepeatProjectName(string project_Id, string project_Name)
        {
            var instance = db.Cat_Project.Where(w => w.Project_Name.ToLower() == project_Name.ToLower()).FirstOrDefault();
            return !(instance == null || instance.Project_Id == project_Id);
        }

    }
}