﻿using Cat.Foundation.SiteConfig.Models;
using Cat.Utility;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Cat.Services
{
    /// <summary>
    /// 上传文件处理服务类
    /// </summary>
    public class FileUploadService
    {
        /// <summary>
        /// 上传文件处理
        /// </summary>
        /// <param name="file"></param>
        /// <param name="fileUploadConfig">文件上传配置基类或其派生类</param>
        /// <returns></returns>
        public CommonResult FileHandler(HttpPostedFileBase file, FileUploadConfig fileUploadConfig)
        {
            try
            {
                #region 验证并保存文件
                //验证目标目录是否存在
                if (!Directory.Exists(PathHelper.GetMapPath(fileUploadConfig.SavePath)))
                {
                    return CommonResult.Instance("找不到指定的上传文件目录");
                }
                //获取文件扩展名
                string fileExtension = Path.GetExtension(file.FileName);
                //检查文件是否为可上传的文件格式
                bool isAllowExtension = fileUploadConfig.AllowExtension.ToStr().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Contains(fileExtension);
                if (!isAllowExtension)
                {
                    return CommonResult.Instance("不允许上传的文件类型");
                }
                //上传文件大小限制
                if (file.ContentLength > fileUploadConfig.MaxSize * 1024)
                {
                    return CommonResult.Instance(string.Format("上传的文件不能大于{0}K", fileUploadConfig.MaxSize));
                }
                //设置文件名称
                var fileName = FileHelper.ResetFileName(file.FileName);
                //设置文件存放目录(虚拟路径)
                string fileSaveVirtualPath = string.Format("{0}/{1}/", fileUploadConfig.SavePath, fileName);
                //设置文件存放目录(物理路径)
                string fileSavePath = PathHelper.GetMapPath(fileSaveVirtualPath);
                //保存文件
                file.SaveAs(fileSavePath);
                //添加上传文件记录
                AllServices.SysUploadRecordService.Add(new Models.Sys_Upload_Record()
                {
                    File_Name = fileName,
                    File_Extension = fileExtension.ToLower(),
                    File_Path = fileSaveVirtualPath,
                    ContentLength = file.ContentLength,
                    IsSystemCreate = false
                });
                #endregion

                return CommonResult.Instance(0, "上传保存成功", fileSaveVirtualPath);
            }
            catch (Exception ex)
            {
                return CommonResult.Instance(ex.ToString());
            }
        }
    }
}