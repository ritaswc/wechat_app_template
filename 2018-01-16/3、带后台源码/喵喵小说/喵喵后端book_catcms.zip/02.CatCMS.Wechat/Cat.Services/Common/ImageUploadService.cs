﻿using Cat.Foundation.SiteConfig;
using Cat.Foundation.SiteConfig.Models;
using Cat.Utility;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace Cat.Services
{
    /// <summary>
    /// 上传图片处理服务类
    /// </summary>
    public class ImageUploadService
    {
        /// <summary>
        /// 上传图片处理
        /// </summary>
        /// <param name="file"></param>
        /// <param name="imageUploadConfig">图片上传配置基类或其派生类</param>
        /// <returns></returns>
        public CommonResult ImageHandler(HttpPostedFileBase file, ImageUploadBaseConfig imageUploadConfig)
        {
            try
            {
                #region 验证并保存原图
                //验证目标目录是否存在
                if (!Directory.Exists(PathHelper.GetMapPath(imageUploadConfig.SavePath)))
                {
                    return CommonResult.Instance("找不到指定的上传文件目录");
                }
                //获取文件扩展名
                string fileExtension = Path.GetExtension(file.FileName);
                //检查文件是否为可上传的文件格式
                bool isAllowExtension = imageUploadConfig.AllowExtension.ToStr().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Contains(fileExtension);
                if (!isAllowExtension)
                {
                    return CommonResult.Instance("不允许上传的图片类型");
                }
                //上传文件大小限制
                if (file.ContentLength > imageUploadConfig.MaxSize * 1024)
                {
                    return CommonResult.Instance(string.Format("上传的图片不能大于{0}K", imageUploadConfig.MaxSize));
                }
                //设置图片名称
                var fileName = FileHelper.ResetFileName(file.FileName);
                //设置图片存放目录(虚拟路径)
                string fileSaveVirtualPath = string.Format("{0}/{1}/", imageUploadConfig.SavePath, fileName);
                //设置图片存放目录(物理路径)
                string fileSavePath = PathHelper.GetMapPath(fileSaveVirtualPath);
                //保存图片
                file.SaveAs(fileSavePath);
                #endregion

                #region 处理图片
                string mode = imageUploadConfig.Mode;
                if (!mode.Contains("None"))
                {
                    //处理后的图片保存目录
                    string imgHandlerDir = imageUploadConfig.SavePath + "/" + "m";
                    if (!Directory.Exists(PathHelper.GetMapPath(imgHandlerDir)))
                    {
                        Directory.CreateDirectory(PathHelper.GetMapPath(imgHandlerDir));
                    }
                    //目标图片名称
                    string fileNameByTarget = Path.GetFileName(fileSavePath);
                    //目标图片的虚拟路径
                    string fileSaveVirtualPathByTarget = string.Format("{0}/{1}", imgHandlerDir, fileNameByTarget);
                    //目标图片的物理路径
                    string fileSavePathByTarget = PathHelper.GetMapPath(fileSaveVirtualPathByTarget);
                    //处理图片
                    ImageHelper.CompressType cType = ImageHelper.CompressType.Zoom;
                    switch (mode.ToLower())
                    {
                        case "cut":
                            cType = ImageHelper.CompressType.WidthAndHeightCut;
                            break;
                        case "zoom":
                            cType = ImageHelper.CompressType.Zoom;
                            break;
                        case "stretch":
                            cType = ImageHelper.CompressType.WidthAndHeight;
                            break;
                    }
                    ImageHelper.Thumb(fileSavePath, fileSavePathByTarget, imageUploadConfig.Width, imageUploadConfig.Height, cType, imageUploadConfig.Quality);
                    //添加上传文件记录（处理后的图片）
                    AllServices.SysUploadRecordService.Add(new Models.Sys_Upload_Record()
                    {
                        File_Name = fileNameByTarget,
                        File_Extension = fileExtension.ToLower(),
                        File_Path = fileSaveVirtualPathByTarget,
                        ContentLength = (int)new System.IO.FileInfo(fileSavePathByTarget).Length,
                        IsSystemCreate = true
                    });
                    //删除原图
                    if (imageUploadConfig.DelOriginalPhoto)
                    {
                        File.Delete(fileSavePath);
                    }
                    else
                    {
                        //添加上传文件记录（原图）
                        AllServices.SysUploadRecordService.Add(new Models.Sys_Upload_Record()
                        {
                            File_Name = fileName,
                            File_Extension = fileExtension.ToLower(),
                            File_Path = fileSaveVirtualPath,
                            ContentLength = file.ContentLength,
                            IsSystemCreate = false
                        });
                    }
                    fileSaveVirtualPath = fileSaveVirtualPathByTarget;
                }
                #endregion

                return CommonResult.Instance(0, "图片保存成功", fileSaveVirtualPath);
            }
            catch (Exception ex)
            {
                return CommonResult.Instance(ex.ToString());
            }
        }
    }
}