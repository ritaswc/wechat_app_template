﻿using Cat.Utility;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Cat.Services.BookService
{
    public class XxbiqugeBookServer : IBookServer
    {
        /// <summary>
        /// 获取小说列表（搜索结果）
        /// </summary>
        /// <param name="bookname"></param>
        /// <returns></returns>
        public Models.Book.BookList GetBookList(string bookname)
        {
            var url = string.Format("http://zhannei.baidu.com/cse/search?q={0}&s=8823758711381329060", bookname);

            HtmlWeb webClient = new HtmlWeb();
            HtmlDocument doc = webClient.Load(url);

            List<Models.Book.BookList.booklist> _list = new List<Models.Book.BookList.booklist>();
            var chapters = doc.DocumentNode.SelectNodes("//div[@class='result-list']/div");

            if (chapters != null)
            {
                int i = 0;
                foreach (var item in chapters)
                {
                    _list.Add(new Models.Book.BookList.booklist()
                    {
                        bookname = item.SelectNodes("//a[@class='result-game-item-title-link']")[i].Attributes["title"].Value,
                        author = item.SelectNodes("//p[@class='result-game-item-info-tag']")[i * 4 + 0].SelectNodes("span")[1].InnerText.Replace("\r\n", string.Empty).Trim(),
                        coverimg = item.SelectNodes("//img[@class='result-game-item-pic-link-img']")[i].Attributes["src"].Value,
                        booktype = item.SelectNodes("//p[@class='result-game-item-info-tag']")[i * 4 + 1].SelectNodes("span")[1].InnerText.Replace("\r\n", string.Empty).Trim(),
                        last_update_time = item.SelectNodes("//p[@class='result-game-item-info-tag']")[i * 4 + 2].SelectNodes("span")[1].InnerText.Replace("\r\n", string.Empty).Trim(),
                        last_update_chapter = item.SelectNodes("//p[@class='result-game-item-info-tag']")[i * 4 + 3].SelectSingleNode("a").InnerText.Trim(),
                        intro = item.SelectNodes("//p[@class='result-game-item-desc']")[i].InnerText,
                        booklink = item.SelectNodes("//a[@class='result-game-item-title-link']")[i].Attributes["href"].Value.Trim(),
                        chapterlink = item.SelectNodes("//p[@class='result-game-item-info-tag']")[i * 4 + 3].SelectSingleNode("a").Attributes["href"].Value.Trim()
                    });
                    i++;
                }
            }

            Models.Book.BookList model = new Models.Book.BookList()
            {
                count = _list.Count,
                pn = 0,
                ps = _list.Count,
                list = _list
            };

            return model;
        }

        /// <summary>
        /// 获取小说的章节列表
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public Models.Book.BookChapter GetBookChapter(string url)
        {
            url = HttpUtility.UrlDecode(url).Replace("*html", ".html");

            HtmlWeb webClient = new HtmlWeb();
            HtmlDocument doc = webClient.Load(url);

            var nodes = doc.DocumentNode.SelectNodes("//div[@id='info']/p");
            var _domain = StringHelper.GetUrlDomain(url);
            var _author = nodes[0].InnerText.Replace(nodes[0].InnerText.Split('：')[0] + "：", string.Empty);
            var _status = nodes[1].InnerText.Replace(nodes[1].InnerText.Split('：')[0] + "：", string.Empty).Replace(",加入书架,直达底部", string.Empty);
            var _last_update_time = nodes[2].InnerText.Replace(nodes[2].InnerText.Split('：')[0] + "：", string.Empty);
            var _last_update_chapter = nodes[3].InnerText.Replace(nodes[3].InnerText.Split('：')[0] + "：", string.Empty);
            var _last_update_chapterlink = _domain + nodes[3].ChildNodes["a"].Attributes["href"].Value;
            var _intro = doc.DocumentNode.SelectSingleNode("//div[@id='intro']/p").InnerText;

            List<Models.Book.BookChapter.chapterlist> _list = new List<Models.Book.BookChapter.chapterlist>();
            var chapters = doc.DocumentNode.SelectNodes("//div[@id='list']/dl/dd/a");
            foreach (var item in chapters)
            {
                _list.Add(new Models.Book.BookChapter.chapterlist()
                {
                    chaptername = item.InnerText,
                    chapterlink = _domain + item.Attributes["href"].Value.Trim()
                });
            }

            Models.Book.BookChapter model = new Models.Book.BookChapter()
            {
                count = _list.Count,
                bookname = doc.DocumentNode.SelectSingleNode("//div[@id='info']/h1").InnerText,
                author = _author,
                status = _status,
                last_update_time = _last_update_time,
                last_update_chapter = _last_update_chapter,
                last_update_chapterlink = _last_update_chapterlink.Trim(),
                intro = _intro.Replace("&nbsp;", ""),
                list = _list
            };

            return model;
        }

        /// <summary>
        /// 获取小说的内容
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public Models.Book.BookContent GetBookContent(string url)
        {
            url = HttpUtility.UrlDecode(url).Replace("*html", ".html");

            HtmlWeb webClient = new HtmlWeb();
            HtmlDocument doc = webClient.Load(url);

            var nodes = doc.DocumentNode.SelectNodes("//div[@class='bookname']/div[@class='bottem1']/a[@href]");
            var _domain = StringHelper.GetUrlDomain(url);
            var _prevlink = _domain + nodes[0].Attributes["href"].Value;
            var _chapterlink = _domain + nodes[1].Attributes["href"].Value;
            var _nextlink = _domain + nodes[2].Attributes["href"].Value;
            var _content = doc.DocumentNode.SelectSingleNode("//div[@id='content']").InnerHtml;
            _content = string.IsNullOrEmpty(_content) ? "这章节真的没有内容 (*・ω・)" : _content;

            Models.Book.BookContent model = new Models.Book.BookContent()
            {
                bookname = doc.DocumentNode.SelectSingleNode("//div[@class='footer_cont']/p/a").InnerText,
                chaptername = doc.DocumentNode.SelectSingleNode("//div[@class='bookname']/h1").InnerText,
                chapterlink = _chapterlink.Trim(),
                content = _content.Replace("&nbsp;", "").Replace("<br>", "\n").Replace("<br/>", "\n").Replace("<br />", "\n").Replace("readx();", "").Replace("&amp;nbsp;", ""),
                nextlink = _nextlink.Trim(),
                prevlink = _prevlink.Trim()
            };

            return model;
        }
    }
}
