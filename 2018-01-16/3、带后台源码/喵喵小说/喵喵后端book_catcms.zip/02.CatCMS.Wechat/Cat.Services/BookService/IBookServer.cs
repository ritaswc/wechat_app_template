﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat.Services.BookService
{
    public interface IBookServer
    {
        /// <summary>
        /// 获取小说列表（搜索结果）
        /// </summary>
        /// <param name="bookname">要搜索的小说名称</param>
        /// <returns></returns>
        Models.Book.BookList GetBookList(string bookname);
        /// <summary>
        /// 获取小说的章节列表
        /// </summary>
        /// <param name="url">链接地址</param>
        /// <returns></returns>
        Models.Book.BookChapter GetBookChapter(string url);
        /// <summary>
        /// 获取小说的内容
        /// </summary>
        /// <param name="url">链接地址</param>
        /// <returns></returns>
        Models.Book.BookContent GetBookContent(string url);
    }
}
