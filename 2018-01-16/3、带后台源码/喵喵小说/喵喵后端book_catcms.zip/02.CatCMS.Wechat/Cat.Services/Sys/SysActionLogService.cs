﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Cat.Utility;

namespace Cat.Services
{
    /// <summary>
    /// 操作日志服务类
    /// </summary>
    public class SysActionLogService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        /// <summary>
        /// 加载分页数据
        /// </summary>
        /// <param name="pn"></param>
        /// <param name="ps"></param>
        /// <param name="whereLambda"></param>
        /// <param name="dicOrderBy"></param>
        /// <returns></returns>
        public Page<Models.Sys_Action_Log> GetByPage(int pn, int ps, 
            Expression<Func<Models.Sys_Action_Log, bool>> whereLambda = null, 
            Dictionary<string, string> dicOrderBy = null)
        {
            if (whereLambda == null) whereLambda = u => 1 == 1;

            var q = db.Sys_Action_Log.Where(whereLambda).OrderBy(dicOrderBy);
            var list = q.Skip((pn - 1) * ps).Take(ps).ToList();
            return new Page<Models.Sys_Action_Log>(pn, ps, q.Count(), list);
        }

        /// <summary>
        /// 新增日志
        /// </summary>
        /// <param name="title">标题</param>
        /// <param name="message">内容（一般为实体序列化后的json字符串）</param>
        /// <param name="category">操作类别</param>
        public void AddLog(string title, string message, Enums.ActionCategory category)
        {
            db.Sys_Action_Log.Add(new Models.Sys_Action_Log()
            {
                Action_Log_Id = ServiceHelper.GetKeyNum(),
                Category = (int)category,
                Title = title,
                Message = message,
                Client_IP = ServiceHelper.GetClientIp(),
                Create_Time = DateTime.Now,
                Creator_Login_Name = SysFormsAuthenticationHelper<Models.Sys_User>.GetUserId()
            });
            db.SaveChanges();
        }

    }
}
