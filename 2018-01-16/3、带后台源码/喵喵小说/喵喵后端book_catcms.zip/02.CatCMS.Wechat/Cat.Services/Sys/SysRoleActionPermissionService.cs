﻿using Cat.Utility;
using EntityFramework.Extensions;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace Cat.Services
{
    public class SysRoleActionPermissionService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        ///// <summary>
        ///// 设置权限
        ///// </summary>
        ///// <param name="role_Id"></param>
        ///// <param name="action_Permission_Ids"></param>
        ///// <param name=""></param>
        //public CommonResult SetPermission(string role_Id, string action_Permission_Ids = "", string menu_Permission_Ids = "")
        //{
        //    var instance = this.GetAllByCache().Where(w => w.Role_Id == role_Id).FirstOrDefault();

        //    if (instance == null)
        //    {
        //        var model = new Models.Sys_Role_Action_Permission()
        //        {
        //            Role_Action_Permission_Id = ServiceHelper.GetKeyNum(),
        //            Role_Id = role_Id,
        //            Action_Permission_Ids = action_Permission_Ids,
        //            Menu_Permission_Ids = menu_Permission_Ids
        //        };
        //        db.Sys_Role_Action_Permission.Add(model);
        //        db.SaveChanges();
        //        AllServices.ActionLogService.AddLog("设置权限 - 添加", model.ToJson(), Enums.ActionCategory.Add);
        //    }
        //    else
        //    {
        //        if (action_Permission_Ids.IsNotNullAndEmpty())
        //            instance.Action_Permission_Ids = action_Permission_Ids;
        //        if (menu_Permission_Ids.IsNotNullAndEmpty())
        //            instance.Menu_Permission_Ids = menu_Permission_Ids;
        //        db.Entry(instance).State = EntityState.Modified;
        //        db.SaveChanges();
        //        AllServices.ActionLogService.AddLog("设置权限 - 更新", instance.ToJson(), Enums.ActionCategory.Update);
        //    }
        //    //移除缓存项
        //    CacheHelper.Remove(CacheItemKey.Sys_Role_Action_Permissions, WebAssist.ModifyPermissionJs);
        //    return CommonResult.Instance();
        //}

        /// <summary>
        /// 设置角色操作权限
        /// </summary>
        /// <param name="role_Id"></param>
        /// <param name="action_Permission_Ids"></param>
        /// <param name=""></param>
        public CommonResult SetActionPermission(string role_Id, string action_Permission_Ids)
        {
            var instance = this.GetAllByCache().Where(w => w.Role_Id == role_Id).FirstOrDefault();

            if (instance == null)
            {
                var model = new Models.Sys_Role_Action_Permission()
                {
                    Role_Action_Permission_Id = ServiceHelper.GetKeyNum(),
                    Role_Id = role_Id,
                    Action_Permission_Ids = action_Permission_Ids,
                    Menu_Permission_Ids = string.Empty
                };
                db.Sys_Role_Action_Permission.Add(model);
                db.SaveChanges();
                AllServices.ActionLogService.AddLog("设置角色操作权限 - 添加", model.ToJson(), Enums.ActionCategory.Add);
            }
            else
            {
                instance.Action_Permission_Ids = action_Permission_Ids;
                db.Entry(instance).State = EntityState.Modified;
                db.SaveChanges();
                AllServices.ActionLogService.AddLog("设置角色操作权限 - 更新", instance.ToJson(), Enums.ActionCategory.Update);
            }
            //移除缓存项
            CacheHelper.Remove(CacheItemKey.Sys_Role_Action_Permissions, WebAssist.ModifyPermissionJs);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 设置角色菜单权限
        /// </summary>
        /// <param name="role_Id"></param>
        /// <param name="menu_Permission_Ids"></param>
        /// <param name=""></param>
        public CommonResult SetMenuPermission(string role_Id, string menu_Permission_Ids)
        {
            var instance = this.GetAllByCache().Where(w => w.Role_Id == role_Id).FirstOrDefault();

            if (instance == null)
            {
                var model = new Models.Sys_Role_Action_Permission()
                {
                    Role_Action_Permission_Id = ServiceHelper.GetKeyNum(),
                    Role_Id = role_Id,
                    Action_Permission_Ids = string.Empty,
                    Menu_Permission_Ids = menu_Permission_Ids
                };
                db.Sys_Role_Action_Permission.Add(model);
                db.SaveChanges();
                AllServices.ActionLogService.AddLog("设置角色菜单权限 - 添加", model.ToJson(), Enums.ActionCategory.Add);
            }
            else
            {
                instance.Menu_Permission_Ids = menu_Permission_Ids;
                db.Entry(instance).State = EntityState.Modified;
                db.SaveChanges();
                AllServices.ActionLogService.AddLog("设置角色菜单权限 - 更新", instance.ToJson(), Enums.ActionCategory.Update);
            }
            //移除缓存项
            CacheHelper.Remove(CacheItemKey.Sys_Role_Action_Permissions, WebAssist.ModifyPermissionJs);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 获取权限
        /// </summary>
        /// <param name="role_Id"></param>
        /// <returns></returns>
        public CommonResult GetPermission(string role_Id)
        {
            var instance = this.GetAllByCache().Where(w => w.Role_Id == role_Id).FirstOrDefault() ?? new Models.Sys_Role_Action_Permission();
            return new CommonResult(0, string.Empty, instance.ToJson());
        }

        /// <summary>
        /// 从缓存中获取所有数据
        /// </summary>
        /// <returns></returns>
        public List<Models.Sys_Role_Action_Permission> GetAllByCache()
        {
            if (CacheHelper.Get(CacheItemKey.Sys_Role_Action_Permissions) == null)
            {
                var list = db.Sys_Role_Action_Permission.ToList();
                CacheHelper.Insert(CacheItemKey.Sys_Role_Action_Permissions, list, CacheHelper.DayFactor);
                return list;
            }
            else
            {
                return CacheHelper.Get(CacheItemKey.Sys_Role_Action_Permissions) as List<Models.Sys_Role_Action_Permission>;
            }
        }

        /// <summary>
        /// 删除多个角色权限
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public CommonResult DeleteByRoles(string[] roleIds)
        {
            db.Sys_Role_Action_Permission.Where(w => roleIds.Contains(w.Role_Id)).Delete();
            return CommonResult.Instance();
        }

    }
}
