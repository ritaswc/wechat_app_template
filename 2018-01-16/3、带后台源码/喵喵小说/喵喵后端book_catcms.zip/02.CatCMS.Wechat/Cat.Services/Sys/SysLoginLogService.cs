﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Cat.Utility;

namespace Cat.Services
{
    /// <summary>
    /// 登录日志服务类
    /// </summary>
    public class SysLoginLogService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        /// <summary>
        /// 加载分页数据
        /// </summary>
        /// <param name="pn"></param>
        /// <param name="ps"></param>
        /// <param name="whereLambda"></param>
        /// <param name="dicOrderBy"></param>
        /// <returns></returns>
        public Page<Models.Sys_Login_Log> GetByPage(int pn, int ps,
            Expression<Func<Models.Sys_Login_Log, bool>> whereLambda = null,
            Dictionary<string, string> dicOrderBy = null)
        {
            if (whereLambda == null) whereLambda = u => 1 == 1;

            var q = db.Sys_Login_Log.Where(whereLambda).OrderBy(dicOrderBy);
            var list = q.Skip((pn - 1) * ps).Take(ps).ToList();
            return new Page<Models.Sys_Login_Log>(pn, ps, q.Count(), list);
        }

        /// <summary>
        /// 获取上次登录(上次登录，即过滤最新的一次登录)
        /// </summary>
        /// <returns></returns>
        public Models.Sys_Login_Log GetLastLogin()
        {
            var User_Id = SysFormsAuthenticationHelper<Models.Sys_User>.GetUserId();
            return db.Sys_Login_Log.Where(w => w.User_Id == User_Id).OrderByDescending(o => o.Create_Time).Skip(1).FirstOrDefault() ?? new Models.Sys_Login_Log();
        }

        /// <summary>
        /// 新增登录日志
        /// </summary>
        public void AddLog()
        {
            var ipInstance = IPHelper.GetIpDetail();
            var model = db.Sys_Login_Log.Add(new Models.Sys_Login_Log()
            {
                Login_Log_Id = ServiceHelper.GetKeyNum(),
                User_Id = SysFormsAuthenticationHelper<Models.Sys_User>.GetUserId(),
                Client_IP = ipInstance.ip,
                Country = ipInstance.country,
                Province = ipInstance.province,
                City = ipInstance.city,
                District = ipInstance.district,
                Create_Time = DateTime.Now
            });
            db.SaveChanges();
            AllServices.ActionLogService.AddLog("新增登录日志", model.ToJson(), Enums.ActionCategory.Add);
        }

    }
}
