﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Cat.Utility;
using EntityFramework.Extensions;
using System.Reflection;
using System.ComponentModel;

namespace Cat.Services
{
    public class SysMenuPermissionService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        /// <summary>
        /// 获取指定用户所拥有的权限列表
        /// </summary>
        /// <param name="user_Id"></param>
        /// <returns></returns>
        public List<Models.Sys_Menu_Permission> GetAllByUserId(string user_Id)
        {
            //用户权限
            List<string> userPermissions = new List<string>();
            var userPermissionInstance = AllServices.SysUserActionPermissionService.GetAllByCache().Where(w => w.User_Id == user_Id).FirstOrDefault();
            if (userPermissionInstance != null)
            {
                userPermissions = userPermissionInstance.Menu_Permission_Ids.ToStr().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();
            }
            //用户所属角色
            var roles = db.Sys_Role_User.Where(w => w.User_Id == user_Id).Select(s => s.Role_Id).ToArray();
            //用户所属角色的权限
            List<string> rolePermissions = new List<string>();
            var rolePermissionList = AllServices.SysRoleActionPermissionService.GetAllByCache().Where(w => roles.Contains(w.Role_Id)).ToList();
            List<string> tempList;
            if (rolePermissionList.Count > 0)
            {
                foreach (var item in rolePermissionList)
                {
                    tempList = item.Menu_Permission_Ids.ToStr().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    foreach (var i in tempList)
                    {
                        rolePermissions.Add(i);
                    }
                }
            }
            var q = this.GetAllByCache().Where(w =>
                userPermissions.Contains(w.Menu_Permission_Id) ||
                rolePermissions.Contains(w.Menu_Permission_Id)
            );
            var list = q.ToList();
            return list;
        }

        /// <summary>
        /// 从缓存中获取所有数据
        /// </summary>
        /// <returns></returns>
        public List<Models.Sys_Menu_Permission> GetAllByCache()
        {
            if (CacheHelper.Get(CacheItemKey.Sys_Menu_Permissions) == null)
            {
                var list = db.Sys_Menu_Permission.OrderByDescending(o => o.Sort_Num).ToList();
                CacheHelper.Insert(CacheItemKey.Sys_Menu_Permissions, list, CacheHelper.DayFactor);
                return list;
            }
            else
            {
                return CacheHelper.Get(CacheItemKey.Sys_Menu_Permissions) as List<Models.Sys_Menu_Permission>;
            }
        }

        /// <summary>
        /// 加载分页数据
        /// </summary>
        /// <param name="pn"></param>
        /// <param name="ps"></param>
        /// <param name="whereLambda"></param>
        /// <param name="dicOrderBy"></param>
        /// <returns></returns>
        public Page<Models.Sys_Menu_Permission> GetByPage(int pn, int ps,
            Expression<Func<Models.Sys_Menu_Permission, bool>> whereLambda = null,
            Dictionary<string, string> dicOrderBy = null)
        {
            if (whereLambda == null) whereLambda = u => 1 == 1;
            if (dicOrderBy == null) { dicOrderBy = new Dictionary<string, string>(); dicOrderBy.Add("Sort_Num", "desc"); }

            var q = this.GetAllByCache().AsQueryable().Where(whereLambda).OrderBy(dicOrderBy);
            var list = q.Skip((pn - 1) * ps).Take(ps).ToList();
            return new Page<Models.Sys_Menu_Permission>(pn, ps, q.Count(), list);
        }

        /// <summary>
        /// 删除权限（删除指定id及其下级节点数据）
        /// </summary>
        /// <param name="roleIds"></param>
        /// <returns></returns>
        public CommonResult Delete(string action_Permission_Id)
        {
            var list = GetSonID(action_Permission_Id).ToList();
            List<string> ids = list.Select(s => s.Menu_Permission_Id).ToList();
            ids.Add(action_Permission_Id);

            db.Sys_Menu_Permission.Where(w => ids.Contains(w.Menu_Permission_Id)).Delete();

            AllServices.ActionLogService.AddLog("删除菜单权限项", string.Join(",", ids), Enums.ActionCategory.Del);
            CacheHelper.Remove(CacheItemKey.Sys_Menu_Permissions);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 递归获取指定父节点下的所有子节点
        /// </summary>
        /// <param name="pId"></param>
        /// <returns></returns>
        private IEnumerable<Models.Sys_Menu_Permission> GetSonID(string pId)
        {
            var query = this.GetAllByCache().AsQueryable().Where(w => w.Parent_Id == pId);
            return query.ToList().Concat(query.ToList().SelectMany(t => GetSonID(t.Menu_Permission_Id)));
        }

        /// <summary>
        /// 新增菜单权限项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public CommonResult Add(Models.Sys_Menu_Permission model)
        {
            model.Menu_Permission_Id = ServiceHelper.GetKeyNum();
            db.Sys_Menu_Permission.Add(model);
            db.SaveChanges();
            AllServices.ActionLogService.AddLog("新增菜单权限项", model.ToJson(), Enums.ActionCategory.Add);
            CacheHelper.Remove(CacheItemKey.Sys_Menu_Permissions);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 更新菜单权限项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public CommonResult Update(Models.Sys_Menu_Permission model)
        {
            db.Entry(model).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            AllServices.ActionLogService.AddLog("更新菜单权限项", model.ToJson(), Enums.ActionCategory.Update);
            CacheHelper.Remove(CacheItemKey.Sys_Menu_Permissions);
            return CommonResult.Instance();
        }

    }
}
