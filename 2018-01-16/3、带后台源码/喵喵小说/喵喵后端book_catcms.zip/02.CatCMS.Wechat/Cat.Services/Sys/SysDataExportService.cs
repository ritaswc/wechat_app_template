﻿using Cat.Utility;
using EntityFramework.Extensions;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Cat.Services
{
    public class SysDataExportService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        /// <summary>
        /// 数据导出到Excel
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public CommonResult Export(string key)
        {
            var instance = GetByKey(key);
            if (instance == null)
            {
                return CommonResult.Instance("找不到指定的key");
            }

            try
            {
                EntityFrameworkHelper helper = new EntityFrameworkHelper();
                SqlParameter[] sqlparams = new SqlParameter[0];
                var dt = helper.SqlQueryForDataTatable(db.ConnectionString, instance.SQL, sqlparams);
                var filePath = ExcelHelper.ExportDataTableToExcel(dt, string.Format("{0}.xls", instance.Title));
                return new CommonResult()
                {
                    code = 0,
                    errmsg = string.Empty,
                    data = filePath
                };
            }
            catch (Exception ex)
            {
                return CommonResult.Instance(ex.ToString());
            }
        }

        /// <summary>
        /// 根据key获取数据导出信息
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public Models.Sys_Data_Export GetByKey(string key)
        {
            return db.Sys_Data_Export.Where(w => w.Key == key).FirstOrDefault();
        }

        /// <summary>
        /// 加载分页数据
        /// </summary>
        /// <param name="pn"></param>
        /// <param name="ps"></param>
        /// <param name="whereLambda"></param>
        /// <param name="dicOrderBy"></param>
        /// <returns></returns>
        public Page<Models.Sys_Data_Export> GetByPage(int pn, int ps,
            Expression<Func<Models.Sys_Data_Export, bool>> whereLambda = null,
            Dictionary<string, string> dicOrderBy = null)
        {
            if (whereLambda == null) whereLambda = u => 1 == 1;

            var q = db.Sys_Data_Export.Where(whereLambda).OrderBy(dicOrderBy);
            var list = q.Skip((pn - 1) * ps).Take(ps).ToList();
            return new Page<Models.Sys_Data_Export>(pn, ps, q.Count(), list);
        }

        /// <summary>
        /// 删除多个数据导出表信息
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public CommonResult Delete(string[] userIds)
        {
            db.Sys_Data_Export.Where(w => userIds.Contains(w.Data_Export_Id)).Delete();
            AllServices.ActionLogService.AddLog("删除数据导出表信息", string.Join(",", userIds), Enums.ActionCategory.Del);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 新增数据导出表信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public CommonResult Add(Models.Sys_Data_Export model)
        {
            if (IsRepeatkey(model.Data_Export_Id, model.Key))
            {
                return CommonResult.Instance("已存在此key，请换一个再试");
            }
            model.Data_Export_Id = ServiceHelper.GetKeyNum();
            model.Create_Time = DateTime.Now;
            model.Update_Time = DateTime.Now;
            model.Creator_Login_Name = SysFormsAuthenticationHelper<Models.Sys_User>.GetUserId();
            db.Sys_Data_Export.Add(model);
            db.SaveChanges();
            AllServices.ActionLogService.AddLog("新增数据导出表信息", model.ToJson(), Enums.ActionCategory.Add);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 更新数据导出表信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public CommonResult Update(Models.Sys_Data_Export model)
        {
            if (IsRepeatkey(model.Data_Export_Id, model.Key))
            {
                return CommonResult.Instance("已存在此key，请换一个再试");
            }
            //更新数据导出表信息
            db.Sys_Data_Export.Where(w => w.Data_Export_Id == model.Data_Export_Id).Update(u => new Models.Sys_Data_Export()
            {
                Key = model.Key,
                SQL = model.SQL,
                Title = model.Title,
                Desc = model.Desc,
                Update_Time = DateTime.Now
            });
            AllServices.ActionLogService.AddLog("更新数据导出表信息信息", model.ToJson(), Enums.ActionCategory.Update);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 检查是否已经有重复的key
        /// </summary>
        /// <param name="data_Export_Id"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool IsRepeatkey(string data_Export_Id, string key)
        {
            var instance = db.Sys_Data_Export.Where(w => w.Key == key).FirstOrDefault();
            return !(instance == null || instance.Data_Export_Id == data_Export_Id);
        }
    }
}
