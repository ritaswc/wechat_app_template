﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Cat.Utility;
using EntityFramework.Extensions;
using System.Reflection;
using System.ComponentModel;

namespace Cat.Services
{
    public class SysActionPermissionService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        /// <summary>
        /// 获取指定用户所拥有的操作权限列表
        /// </summary>
        /// <param name="user_Id"></param>
        /// <returns></returns>
        public List<Models.Sys_Action_Permission> GetAllByUserId(string user_Id)
        {
            //用户操作权限
            List<string> userPermissions = new List<string>();
            var userPermissionInstance = AllServices.SysUserActionPermissionService.GetAllByCache().Where(w => w.User_Id == user_Id).FirstOrDefault();
            if (userPermissionInstance != null)
            {
                userPermissions = userPermissionInstance.Action_Permission_Ids.ToStr().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();
            }
            //用户所属角色
            var roles = AllServices.SysRoleUserService.GetAllByCache().Where(w => w.User_Id == user_Id).Select(s => s.Role_Id).ToArray();
            //用户所属角色的操作权限
            List<string> rolePermissions = new List<string>();
            var rolePermissionList = AllServices.SysRoleActionPermissionService.GetAllByCache().Where(w => roles.Contains(w.Role_Id)).ToList();
            List<string> tempList;
            if (rolePermissionList.Count > 0)
            {
                foreach (var item in rolePermissionList)
                {
                    tempList = item.Action_Permission_Ids.ToStr().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    foreach (var i in tempList)
                    {
                        rolePermissions.Add(i);
                    }
                }
            }
            var q = this.GetAllByCache().Where(w =>
                userPermissions.Contains(w.Action_Permission_Id) ||
                rolePermissions.Contains(w.Action_Permission_Id)
            );
            var list = q.ToList();
            return list;
        }

        /// <summary>
        /// 从缓存中获取所有数据
        /// </summary>
        /// <returns></returns>
        public List<Models.Sys_Action_Permission> GetAllByCache()
        {
            if (CacheHelper.Get(CacheItemKey.Sys_Action_Permissions) == null)
            {
                var list = db.Sys_Action_Permission.OrderBy(o => o.Sort_Num).ToList();
                CacheHelper.Insert(CacheItemKey.Sys_Action_Permissions, list, CacheHelper.DayFactor);
                return list;
            }
            else
            {
                return CacheHelper.Get(CacheItemKey.Sys_Action_Permissions) as List<Models.Sys_Action_Permission>;
            }
        }

        /// <summary>
        /// 加载分页数据
        /// </summary>
        /// <param name="pn"></param>
        /// <param name="ps"></param>
        /// <param name="whereLambda"></param>
        /// <param name="dicOrderBy"></param>
        /// <returns></returns>
        public Page<Models.Sys_Action_Permission> GetByPage(int pn, int ps,
            Expression<Func<Models.Sys_Action_Permission, bool>> whereLambda = null,
            Dictionary<string, string> dicOrderBy = null)
        {
            if (whereLambda == null) whereLambda = u => 1 == 1;
            if (dicOrderBy == null) { dicOrderBy = new Dictionary<string, string>(); dicOrderBy.Add("Create_Time", "desc"); }

            var q = this.GetAllByCache().AsQueryable().Where(whereLambda).OrderBy(dicOrderBy);
            var list = q.Skip((pn - 1) * ps).Take(ps).ToList();
            return new Page<Models.Sys_Action_Permission>(pn, ps, q.Count(), list);
        }

        /// <summary>
        /// 删除操作权限（删除指定id及其下级节点数据）
        /// </summary>
        /// <param name="roleIds"></param>
        /// <returns></returns>
        public CommonResult Delete(string action_Permission_Id)
        {
            var list = GetSonID(action_Permission_Id).ToList();
            List<string> ids = list.Select(s => s.Action_Permission_Id).ToList();
            ids.Add(action_Permission_Id);

            db.Sys_Action_Permission.Where(w => ids.Contains(w.Action_Permission_Id)).Delete();

            AllServices.ActionLogService.AddLog("删除操作权限项", string.Join(",", ids), Enums.ActionCategory.Del);
            CacheHelper.Remove(CacheItemKey.Sys_Action_Permissions, WebAssist.ModifyPermissionJs);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 递归获取指定父节点下的所有子节点
        /// </summary>
        /// <param name="pId"></param>
        /// <returns></returns>
        private IEnumerable<Models.Sys_Action_Permission> GetSonID(string pId)
        {
            var query = this.GetAllByCache().AsQueryable().Where(w => w.Parent_Id == pId);
            return query.ToList().Concat(query.ToList().SelectMany(t => GetSonID(t.Action_Permission_Id)));
        }

        /// <summary>
        /// 新增操作权限项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public CommonResult Add(Models.Sys_Action_Permission model)
        {
            if (model.IsDirectory == false && IsRepeat(model.Action_Permission_Id, model.Controller_Name,model.Action_Name))
            {
                return CommonResult.Instance("已存在相同的ControllerName和ActionName，不能重复添加");
            }

            model.Action_Permission_Id = ServiceHelper.GetKeyNum();
            db.Sys_Action_Permission.Add(model);
            db.SaveChanges();
            AllServices.ActionLogService.AddLog("新增操作权限项", model.ToJson(), Enums.ActionCategory.Add);
            CacheHelper.Remove(CacheItemKey.Sys_Action_Permissions, WebAssist.ModifyPermissionJs);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 更新操作权限项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public CommonResult Update(Models.Sys_Action_Permission model)
        {
            if (model.IsDirectory == false && IsRepeat(model.Action_Permission_Id, model.Controller_Name, model.Action_Name))
            {
                return CommonResult.Instance("已存在相同的ControllerName和ActionName，不能重复添加");
            }

            db.Entry(model).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            AllServices.ActionLogService.AddLog("更新操作权限项", model.ToJson(), Enums.ActionCategory.Update);
            CacheHelper.Remove(CacheItemKey.Sys_Action_Permissions);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 检查是否已经有重复
        /// </summary>
        /// <param name="action_Permission_Id"></param>
        /// <param name="controller_Name"></param>
        /// <returns></returns>
        public bool IsRepeat(string action_Permission_Id, string controller_Name,string action_Name)
        {
            var instance = db.Sys_Action_Permission.AsNoTracking().Where(w => w.Controller_Name == controller_Name && w.Action_Name == action_Name).FirstOrDefault();
            return !(instance == null || instance.Action_Permission_Id == action_Permission_Id);
        }

        /// <summary>
        /// CatCMS.Areas.Admin.Controllers 命名空间下的所有控制器与方法组成的集合
        /// </summary>
        /// <returns></returns>
        public IList<ControllerAndActionModel> GetAllActionByAssembly()
        {
            var list = new List<ControllerAndActionModel>();
            string[] AllowReturnType = new string[] { "string", "actionresult", "contentresult" };  //要遍历的方法的返回类型
            var types = Assembly.Load("CatCMS").GetTypes();

            ControllerAndActionModel model;
            foreach (var type in types.Where(
                w => w.Name.EndsWith("Controller") &&
                     w.Namespace.Contains("CatCMS.Areas.Admin.Controllers")
            )) //只遍历Admin下的Controller
            {
                var members = type.GetMethods();
                foreach (var member in members.Where(w => w.DeclaringType.Name == type.Name)) //只遍历控制器里“自定义”的方法
                {
                    model = new ControllerAndActionModel();
                    //Controller名称和描述
                    model.ControllerName = type.Name;
                    object[] controllerAttrs = type.GetCustomAttributes(typeof(DescriptionAttribute), true);
                    if (controllerAttrs.Length > 0)
                        model.ControllerDesc = (controllerAttrs[0] as DescriptionAttribute).Description;
                    //Action名称和描述
                    if (AllowReturnType.Contains(member.ReturnType.Name.ToLower()))
                    {
                        var flag = true;
                        //跳过筛选器中IsNoAuthorize=true的方法
                        if (member.GetCustomAttributesData().Count > 0)
                        {
                            foreach (var attr in member.GetCustomAttributesData())
                            {
                                foreach (var arg in attr.NamedArguments)
                                {
                                    if (arg.MemberName == "IsNoAuthorize" && arg.TypedValue.Value.ToBoolean() == true)
                                    {
                                        flag = false;
                                    }
                                }
                            }
                        }
                        if (flag)
                        {
                            model.ActionName = member.Name;
                            object[] actionAttrs = member.GetCustomAttributes(typeof(DescriptionAttribute), true);
                            if (actionAttrs.Length > 0)
                                model.ActionDesc = (actionAttrs[0] as DescriptionAttribute).Description;
                            list.Add(model);
                        }
                    }

                }
            }

            return list;
        }

        /// <summary>
        /// CatCMS.Areas.Admin.Controllers 命名空间下的所有控制器与方法组成的集合（分层级关系）
        /// </summary>
        /// <returns></returns>
        public List<Models.Sys_Action_Permission> GetByAssembly()
        {
            var list = AllServices.SysActionPermissionService.GetAllActionByAssembly();
            var nList = new List<Models.Sys_Action_Permission>();
            //添加一级节点（根节点）
            string parentId = StringHelper.GuidTo16String();
            nList.Add(new Models.Sys_Action_Permission()
            {
                Action_Permission_Id = parentId,
                Alias_Name = "CatCMS操作权限",
                IsDirectory = true,
                Parent_Id = string.Empty
            });
            //添加二级节点
            var secondNodes = new List<Models.Sys_Action_Permission>();
            foreach (var item in list)
            {
                if (secondNodes.Where(w => w.Controller_Name == item.ControllerName).Count() == 0)
                {
                    secondNodes.Add(new Models.Sys_Action_Permission()
                    {
                        Action_Permission_Id = StringHelper.GuidTo16String(),
                        Parent_Id = parentId,
                        Alias_Name = item.ControllerName,
                        IsDirectory = true,
                        Controller_Name = item.ControllerName,
                        Desc = item.ControllerDesc
                    });
                }
            }
            nList.AddRange(secondNodes);
            //添加三级节点
            foreach (var item in list)
            {
                nList.Add(new Models.Sys_Action_Permission()
                {
                    Action_Permission_Id = StringHelper.GuidTo16String(),
                    Parent_Id = secondNodes.Where(w => w.Controller_Name == item.ControllerName).FirstOrDefault().Action_Permission_Id,
                    IsDirectory = false,
                    Alias_Name = item.ControllerName,
                    Controller_Name = item.ControllerName,
                    Action_Name = item.ActionName,
                    Desc = item.ActionDesc
                });
            }
            return nList;
        }

























        public class ControllerAndActionModel
        {
            private string _controllerDesc;
            private string _actionDesc;

            public string ControllerName
            {
                get;
                set;
            }
            public string ControllerDesc
            {
                get { return _controllerDesc == null ? string.Empty : _controllerDesc; }
                set { _controllerDesc = value; }
            }
            public string ActionName
            {
                get;
                set;
            }
            public string ActionDesc
            {
                get { return _actionDesc == null ? string.Empty : _actionDesc; }
                set { _actionDesc = value; }
            }
        }

    }
}
