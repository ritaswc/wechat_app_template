﻿using Cat.Utility;
using EntityFramework.Extensions;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat.Services
{
    public class SysUserActionPermissionService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        ///// <summary>
        ///// 设置权限
        ///// </summary>
        ///// <param name="user_Id"></param>
        ///// <param name="action_Permission_Ids"></param>
        ///// <param name=""></param>
        //public CommonResult SetPermission(string user_Id, string action_Permission_Ids = "", string menu_Permission_Ids = "")
        //{
        //    var instance = AllServices.SysUserActionPermissionService.GetAllByCache().Where(w => w.User_Id == user_Id).FirstOrDefault();

        //    if (instance == null)
        //    {
        //        var model = new Models.Sys_User_Action_Permission()
        //        {
        //            User_Action_Permission_Id = ServiceHelper.GetKeyNum(),
        //            User_Id = user_Id,
        //            Action_Permission_Ids = action_Permission_Ids,
        //            Menu_Permission_Ids = menu_Permission_Ids
        //        };
        //        db.Sys_User_Action_Permission.Add(model);
        //        db.SaveChanges();
        //        AllServices.ActionLogService.AddLog("设置权限 - 添加", model.ToJson(), Enums.ActionCategory.Add);
        //    }
        //    else
        //    {
        //        if (action_Permission_Ids.IsNotNullAndEmpty())
        //            instance.Action_Permission_Ids = action_Permission_Ids;
        //        if (menu_Permission_Ids.IsNotNullAndEmpty())
        //            instance.Menu_Permission_Ids = menu_Permission_Ids;
        //        db.Entry(instance).State = EntityState.Modified;
        //        db.SaveChanges();
        //        AllServices.ActionLogService.AddLog("设置权限 - 更新", instance.ToJson(), Enums.ActionCategory.Update);
        //    }
        //    //移除缓存项
        //    CacheHelper.Remove(CacheItemKey.Sys_User_Action_Permissions, WebAssist.ModifyPermissionJs);
        //    return CommonResult.Instance();
        //}

        /// <summary>
        /// 设置用户操作权限
        /// </summary>
        /// <param name="user_Id"></param>
        /// <param name="action_Permission_Ids"></param>
        /// <param name=""></param>
        public CommonResult SetActionPermission(string user_Id, string action_Permission_Ids)
        {
            var instance = AllServices.SysUserActionPermissionService.GetAllByCache().Where(w => w.User_Id == user_Id).FirstOrDefault();

            if (instance == null)
            {
                var model = new Models.Sys_User_Action_Permission()
                {
                    User_Action_Permission_Id = ServiceHelper.GetKeyNum(),
                    User_Id = user_Id,
                    Action_Permission_Ids = action_Permission_Ids,
                    Menu_Permission_Ids = string.Empty
                };
                db.Sys_User_Action_Permission.Add(model);
                db.SaveChanges();
                AllServices.ActionLogService.AddLog("设置用户操作权限 - 添加", model.ToJson(), Enums.ActionCategory.Add);
            }
            else
            {
                instance.Action_Permission_Ids = action_Permission_Ids;
                db.Entry(instance).State = EntityState.Modified;
                db.SaveChanges();
                AllServices.ActionLogService.AddLog("设置用户操作权限 - 更新", instance.ToJson(), Enums.ActionCategory.Update);
            }
            //移除缓存项
            CacheHelper.Remove(CacheItemKey.Sys_User_Action_Permissions, WebAssist.ModifyPermissionJs);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 设置用户菜单权限
        /// </summary>
        /// <param name="user_Id"></param>
        /// <param name="action_Permission_Ids"></param>
        /// <param name=""></param>
        public CommonResult SetMenuPermission(string user_Id, string menu_Permission_Ids)
        {
            var instance = AllServices.SysUserActionPermissionService.GetAllByCache().Where(w => w.User_Id == user_Id).FirstOrDefault();

            if (instance == null)
            {
                var model = new Models.Sys_User_Action_Permission()
                {
                    User_Action_Permission_Id = ServiceHelper.GetKeyNum(),
                    User_Id = user_Id,
                    Action_Permission_Ids = string.Empty,
                    Menu_Permission_Ids = menu_Permission_Ids
                };
                db.Sys_User_Action_Permission.Add(model);
                db.SaveChanges();
                AllServices.ActionLogService.AddLog("设置用户菜单权限 - 添加", model.ToJson(), Enums.ActionCategory.Add);
            }
            else
            {
                instance.Menu_Permission_Ids = menu_Permission_Ids;
                db.Entry(instance).State = EntityState.Modified;
                db.SaveChanges();
                AllServices.ActionLogService.AddLog("设置用户菜单权限 - 更新", instance.ToJson(), Enums.ActionCategory.Update);
            }
            //移除缓存项
            CacheHelper.Remove(CacheItemKey.Sys_User_Action_Permissions, WebAssist.ModifyPermissionJs);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 获取权限
        /// </summary>
        /// <param name="user_Id"></param>
        /// <returns></returns>
        public CommonResult GetPermission(string user_Id)
        {
            //用户权限
            var instance = this.GetAllByCache().Where(w => w.User_Id == user_Id).FirstOrDefault() ?? new Models.Sys_User_Action_Permission();
            return new CommonResult(0, string.Empty, instance.ToJson());

            ////添加返回 用户所属角色的权限
            //var role_Ids = AllServices.SysRoleUserService.GetAllByCache().Where(w => w.User_Id == user_Id).Select(s => s.Role_Id).ToList();
            //List<string> actionPermissionList = new List<string>();
            //List<string> menuPermissionList = new List<string>();
            //actionPermissionList.Add(instance.Action_Permission_Ids);
            //menuPermissionList.Add(instance.Menu_Permission_Ids);
            //foreach (var role_Id in role_Ids)
            //{
            //    var roleInstance = AllServices.SysRoleActionPermissionService.GetAllByCache().Where(w => w.Role_Id == role_Id).FirstOrDefault();
            //    if (roleInstance != null)
            //    {
            //        actionPermissionList.Add(roleInstance.Action_Permission_Ids);
            //        menuPermissionList.Add(roleInstance.Menu_Permission_Ids);
            //    }
            //}
            ////去重
            //var actions = string.Join(",", actionPermissionList).ToStr().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Distinct().ToArray();
            //var menus = string.Join(",", menuPermissionList).ToStr().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Distinct().ToArray();
            //var model = new Models.Sys_User_Action_Permission()
            //{
            //    User_Action_Permission_Id = instance.User_Action_Permission_Id,
            //    User_Id = instance.User_Id,
            //    Action_Permission_Ids = string.Join(",", actions),
            //    Menu_Permission_Ids = string.Join(",", menus)
            //};
            //return new CommonResult(0, string.Empty, model.ToJson());
        }

        /// <summary>
        /// 从缓存中获取所有数据
        /// </summary>
        /// <returns></returns>
        public List<Models.Sys_User_Action_Permission> GetAllByCache()
        {
            if (CacheHelper.Get(CacheItemKey.Sys_User_Action_Permissions) == null)
            {
                var list = db.Sys_User_Action_Permission.ToList();
                CacheHelper.Insert(CacheItemKey.Sys_User_Action_Permissions, list, CacheHelper.DayFactor);
                return list;
            }
            else
            {
                return CacheHelper.Get(CacheItemKey.Sys_User_Action_Permissions) as List<Models.Sys_User_Action_Permission>;
            }
        }

        /// <summary>
        /// 删除多个用户权限
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public CommonResult DeleteByUsers(string[] userIds)
        {
            db.Sys_User_Action_Permission.Where(w => userIds.Contains(w.User_Id)).Delete();
            return CommonResult.Instance();
        }

    }
}
