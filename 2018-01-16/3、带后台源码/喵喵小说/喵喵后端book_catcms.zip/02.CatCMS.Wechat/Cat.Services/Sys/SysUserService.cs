﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Cat.Utility;
using EntityFramework.Extensions;
using Cat.Foundation.SiteConfig;
using Cat.Enums;

namespace Cat.Services
{
    public class SysUserService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        /// <summary>
        /// 用户登录
        /// </summary>
        /// <param name="loginName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public CommonResult Login(string loginName, string password)
        {
            if (loginName.ToLower() == AllConfigServices.CatSettingsConfig.SuperAdminAccount &&
                password == AllConfigServices.CatSettingsConfig.SuperAdminPassword)
            {
                SysFormsAuthenticationHelper<Models.Sys_User>.SetAuthCookie(loginName, new Models.Sys_User()
                {
                    User_Id = loginName,
                    Login_Name = loginName,
                    User_Name = loginName,
                    Password = password,
                    Login_Time = DateTime.Now
                });
                return CommonResult.Instance();
            }

            password = (password + AllConfigServices.CatSettingsConfig.PasswordKey).ToMD5();
            var userInfo = db.Sys_User.Where(w => w.Login_Name == loginName && w.Password == password).FirstOrDefault();
            if (userInfo != null)
            {
                userInfo.Login_Time = DateTime.Now;
                int state = (int)AccountState.Disable;
                if (userInfo.State == state)
                {
                    return CommonResult.Instance("账号被禁用，请联系管理员");
                }
                else
                {

                    var q = from r in db.Sys_Role
                            join ru in db.Sys_Role_User on r.Role_Id equals ru.Role_Id
                            join u in db.Sys_User on ru.User_Id equals u.User_Id
                            where u.User_Id == userInfo.User_Id
                            select r;
                    var listRole = q.ToList();
                    if (listRole.Where(w => w.State == state).Count() > 0)  //只要所属角色中任意角色被禁用，则不可登录
                    {
                        return CommonResult.Instance("账号所属角色被禁用，请联系管理员");
                    }
                    else
                    {
                        SysFormsAuthenticationHelper<Models.Sys_User>.SetAuthCookie(loginName, userInfo);
                    }
                }
            }
            else
            {
                return CommonResult.Instance("账号或密码错误");
            }
            return CommonResult.Instance();
        }

        /// <summary>
        /// 用户登出
        /// </summary>
        public void Logout()
        {
            SysFormsAuthenticationHelper<Models.Sys_User>.SignOut();
        }

        /// <summary>
        /// 是否已登录
        /// </summary>
        /// <returns></returns>
        public bool IsLogined()
        {
            //string userId = SysFormsAuthenticationHelper<Models.Sys_User>.GetUserId();
            //return !string.IsNullOrEmpty(userId);

            var user = SysFormsAuthenticationHelper<Models.Sys_User>.GetUserInstance();
            if (user != null)
            {
                var lastLoginTime = user.Login_Time.ToLocalTime();
                //防止客户端修改（延长）过期时间
                if (lastLoginTime.AddHours(AllConfigServices.CatSettingsConfig.AdminLoginCookieHours) < DateTime.Now.ToLocalTime())
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 从客户端cookie中获取用户信息
        /// </summary>
        /// <returns></returns>
        public Models.Sys_User GetUserByCookie()
        {
            return SysFormsAuthenticationHelper<Models.Sys_User>.GetUserInstance();
        }

        /// <summary>
        /// 根据User_Id获取用户信息
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public Models.Sys_User GetByUserId(string userId)
        {
            return db.Sys_User.Where(w => w.User_Id == userId).FirstOrDefault();
        }

        /// <summary>
        /// 加载分页数据
        /// </summary>
        /// <param name="pn"></param>
        /// <param name="ps"></param>
        /// <param name="whereLambda"></param>
        /// <param name="dicOrderBy"></param>
        /// <returns></returns>
        public Page<Models.Sys_User> GetByPage(int pn, int ps,
            Expression<Func<Models.Sys_User, bool>> userWhereLambda = null,
            Expression<Func<Models.Sys_Role, bool>> roleWhereLambda = null,
            Dictionary<string, string> dicOrderBy = null)
        {
            if (userWhereLambda == null) userWhereLambda = u => 1 == 1;
            if (roleWhereLambda == null) roleWhereLambda = u => 1 == 1;

            var q = db.Sys_User.Where(userWhereLambda).OrderBy(dicOrderBy);
            var list = q.Skip((pn - 1) * ps).Take(ps).ToList();
            foreach (var item in list)
            {
                item.Role_Id = string.Join(",", db.Sys_Role_User.Where(w => w.User_Id == item.User_Id).Select(a => a.Role_Id).ToArray());
            }
            return new Page<Models.Sys_User>(pn, ps, q.Count(), list);
        }

        /// <summary>
        /// 删除多个用户
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public CommonResult Delete(string[] userIds)
        {

            db.Sys_User.Where(w => userIds.Contains(w.User_Id)).Delete();
            AllServices.ActionLogService.AddLog("删除用户", string.Join(",", userIds), Enums.ActionCategory.Del);
            //删除多个角色与用户的关联
            AllServices.SysRoleUserService.DeleteByUsers(userIds);
            //删除多个角色权限
            AllServices.SysUserActionPermissionService.DeleteByUsers(userIds);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 新增用户
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public CommonResult Add(Models.Sys_User model)
        {
            if (IsRepeatLoginName(model.User_Id, model.Login_Name))
            {
                return CommonResult.Instance("已存在此登录名，请换一个再试");
            }
            model.User_Id = ServiceHelper.GetKeyNum();
            model.Password = (model.Password + AllConfigServices.CatSettingsConfig.PasswordKey).ToMD5();
            model.Create_Time = DateTime.Now;
            model.Update_Time = DateTime.Now;
            db.Sys_User.Add(model);
            db.SaveChanges();
            AllServices.ActionLogService.AddLog("新增用户", model.ToJson(), Enums.ActionCategory.Add);
            AllServices.SysRoleUserService.Add(model.Role_Id, model.User_Id);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="user_Id"></param>
        /// <param name="password"></param>
        /// <param name="newPassword"></param>
        /// <returns></returns>
        public CommonResult ModifyPwd(string user_Id, string password, string newPassword)
        {
            password = (password + AllConfigServices.CatSettingsConfig.PasswordKey).ToMD5();
            newPassword = newPassword.ToMD5();
            var instance = db.Sys_User.Where(w => w.User_Id == user_Id && w.Password == password).FirstOrDefault();
            if (instance != null)
            {
                instance.Password = newPassword;
                db.Entry(instance).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();

                AllServices.ActionLogService.AddLog("修改用户密码", instance.ToJson(), Enums.ActionCategory.Update);
                return CommonResult.Instance();
            }
            else
            {
                return CommonResult.Instance("修改密码失败，密码错误");
            }
        }

        /// <summary>
        /// 更新用户
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public CommonResult Update(Models.Sys_User model, string[] role_Ids)
        {
            if (IsRepeatLoginName(model.User_Id, model.Login_Name))
            {
                return CommonResult.Instance("已存在此登录名，请换一个再试");
            }
            //更新用户
            db.Sys_User.Where(w => w.User_Id == model.User_Id).Update(u => new Models.Sys_User()
            {
                Login_Name = model.Login_Name,
                User_Name = model.User_Name,
                //Password = model.Password,
                Desc = model.Desc,
                State = model.State,
                Update_Time = DateTime.Now,
                Sort_Num = model.Sort_Num
            });
            AllServices.ActionLogService.AddLog("更新用户信息", model.ToJson(), Enums.ActionCategory.Update);

            //更新角色用户关系
            AllServices.SysRoleUserService.Update(model.User_Id, role_Ids);

            return CommonResult.Instance();
        }

        /// <summary>
        /// 检查是否已经有重复的登录名
        /// </summary>
        /// <param name="user_Id"></param>
        /// <param name="login_Name"></param>
        /// <returns></returns>
        public bool IsRepeatLoginName(string user_Id, string login_Name)
        {
            var instance = db.Sys_User.Where(w => w.Login_Name == login_Name).FirstOrDefault();
            return !(instance == null || instance.User_Id == user_Id);
        }

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="user_Id"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public CommonResult ModifyPwd(string user_Id, string password)
        {
            var instance = this.GetByUserId(user_Id);
            instance.Password = (password + AllConfigServices.CatSettingsConfig.PasswordKey).ToMD5();
            db.Entry(instance).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            return CommonResult.Instance();
        }

    }
}
