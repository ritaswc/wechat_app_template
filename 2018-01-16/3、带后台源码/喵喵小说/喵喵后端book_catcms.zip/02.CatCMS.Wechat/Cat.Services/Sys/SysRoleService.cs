﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Cat.Utility;
using EntityFramework.Extensions;

namespace Cat.Services
{
    public class SysRoleService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        /// <summary>
        /// 根据Role_Id获取角色信息
        /// </summary>
        /// <param name="roleId"></param>
        /// <returns></returns>
        public Models.Sys_Role GetByRoleId(string roleId)
        {
            return db.Sys_Role.Where(w => w.Role_Id == roleId).FirstOrDefault();
        }

        /// <summary>
        /// 加载分页数据
        /// </summary>
        /// <param name="pn"></param>
        /// <param name="ps"></param>
        /// <param name="whereLambda"></param>
        /// <param name="dicOrderBy"></param>
        /// <returns></returns>
        public Page<Models.Sys_Role> GetByPage(int pn, int ps, 
            Expression<Func<Models.Sys_Role, bool>> whereLambda = null, 
            Dictionary<string, string> dicOrderBy = null)
        {
            if (whereLambda == null) whereLambda = u => 1 == 1;

            var q = db.Sys_Role.Where(whereLambda).OrderBy(dicOrderBy);
            var list = q.Skip((pn - 1) * ps).Take(ps).ToList();
            return new Page<Models.Sys_Role>(pn, ps, q.Count(), list);
        }

        /// <summary>
        /// 新增角色
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public CommonResult Add(Models.Sys_Role model)
        {
            if (IsRepeatRoleName(model.Role_Id, model.Role_Name))
            {
                return CommonResult.Instance("已存在此角色名，请换一个再试");
            }
            model.Role_Id = ServiceHelper.GetKeyNum();
            model.Create_Time = DateTime.Now;
            model.Update_Time = DateTime.Now;
            db.Sys_Role.Add(model);
            db.SaveChanges();
            AllServices.ActionLogService.AddLog("新增角色", model.ToJson(), Enums.ActionCategory.Add);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 更新角色
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public CommonResult Update(Models.Sys_Role model)
        {
            if (IsRepeatRoleName(model.Role_Id, model.Role_Name))
            {
                return CommonResult.Instance("已存在此角色名，请换一个再试");
            }
            
            db.Sys_Role.Where(w => w.Role_Id == model.Role_Id).Update(u => new Models.Sys_Role()
            {
                Role_Name = model.Role_Name,
                Desc = model.Desc,
                State = model.State,
                Sort_Num = model.Sort_Num,
                Update_Time = DateTime.Now
            });

            AllServices.ActionLogService.AddLog("更新角色信息", model.ToJson(), Enums.ActionCategory.Update);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 删除多个角色
        /// </summary>
        /// <param name="roleIds"></param>
        /// <returns></returns>
        public CommonResult Delete(string[] roleIds)
        {
            //删除角色
            db.Sys_Role.Where(w => roleIds.Contains(w.Role_Id)).Delete();
            AllServices.ActionLogService.AddLog("删除角色", string.Join(",", roleIds), Enums.ActionCategory.Del);
            //删除多个角色与用户的关联
            AllServices.SysRoleUserService.DeleteByRoles(roleIds);
            //删除多个角色权限
            AllServices.SysRoleActionPermissionService.DeleteByRoles(roleIds);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 检查是否已经有重复的角色名
        /// </summary>
        /// <param name="role_Id"></param>
        /// <param name="role_Name"></param>
        /// <returns></returns>
        public bool IsRepeatRoleName(string role_Id, string role_Name)
        {
            var instance = db.Sys_Role.Where(w => w.Role_Name == role_Name).FirstOrDefault();
            return !(instance == null || instance.Role_Id == role_Id);
        }

    }
}
