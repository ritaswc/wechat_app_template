﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Cat.Utility;

namespace Cat.Services
{
    /// <summary>
    /// 文件上传记录服务类
    /// </summary>
    public class SysUploadRecordService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        /// <summary>
        /// 根据Upload_Record_Id获取上传记录信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Models.Sys_Upload_Record GetByRoleId(string id)
        {
            return db.Sys_Upload_Record.Where(w => w.Upload_Record_Id == id).FirstOrDefault();
        }

        /// <summary>
        /// 加载分页数据
        /// </summary>
        /// <param name="pn"></param>
        /// <param name="ps"></param>
        /// <param name="whereLambda"></param>
        /// <param name="dicOrderBy"></param>
        /// <returns></returns>
        public Page<Models.Sys_Upload_Record> GetByPage(int pn, int ps,
            Expression<Func<Models.Sys_Upload_Record, bool>> whereLambda = null,
            Dictionary<string, string> dicOrderBy = null)
        {
            if (whereLambda == null) whereLambda = u => 1 == 1;

            var q = db.Sys_Upload_Record.Where(whereLambda).OrderBy(dicOrderBy);
            var list = q.Skip((pn - 1) * ps).Take(ps).ToList();
            return new Page<Models.Sys_Upload_Record>(pn, ps, q.Count(), list);
        }

        /// <summary>
        /// 新增上传记录
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public CommonResult Add(Models.Sys_Upload_Record model)
        {
            model.Upload_Record_Id = ServiceHelper.GetKeyNum();
            model.Create_Time = DateTime.Now;
            db.Sys_Upload_Record.Add(model);
            db.SaveChanges();
            AllServices.ActionLogService.AddLog("新增上传记录", model.ToJson(), Enums.ActionCategory.Add);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 删除多个上传记录
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        public CommonResult Delete(string[] ids)
        {
            //删除上传记录
            var list = db.Sys_Upload_Record.Where(w => ids.Contains(w.Upload_Record_Id)).ToList();

            foreach (var item in list)
            {
                db.Entry(item).State = System.Data.Entity.EntityState.Deleted;
            }
            db.SaveChanges();

            //删除文件
            var files = list.Select(s => s.File_Path).ToList();
            try
            {
                foreach (var item in files)
                {
                    System.IO.File.Delete(PathHelper.GetMapPath(item));
                }
            }
            catch
            {
                CommonResult.Instance("上传记录删除成功，但删除文件失败");
            }

            AllServices.ActionLogService.AddLog("删除上传记录（多个）", list.ToJson(), Enums.ActionCategory.Del);
            return CommonResult.Instance();
        }
    }
}