﻿using Cat.Utility;
using EntityFramework.Extensions;
using System.Collections.Generic;
using System.Linq;

namespace Cat.Services
{
    public class SysRoleUserService
    {
        public readonly Models.CatCmsDBEntities db = new Models.CatCmsDBEntities();

        public CommonResult Add(string role_Id, string user_Id)
        {
            return Add(new Models.Sys_Role_User()
            {
                Role_Id = role_Id,
                User_Id = user_Id
            });
        }

        public CommonResult Add(Models.Sys_Role_User model)
        {
            string[] role_Ids = model.Role_Id.ToStr().Split(new string[] { "," }, System.StringSplitOptions.RemoveEmptyEntries);
            foreach (var role_Id in role_Ids)
            {
                var instance = db.Sys_Role_User.Where(w => w.Role_Id == role_Id && w.User_Id == model.User_Id).FirstOrDefault();
                if (instance == null)
                {
                    db.Sys_Role_User.Add(new Models.Sys_Role_User()
                    {
                        Role_User_Id = ServiceHelper.GetKeyNum(),
                        Role_Id = role_Id,
                        User_Id = model.User_Id
                    });
                    db.SaveChanges();
                }
            }
            AllServices.ActionLogService.AddLog("新增角色用户关联", model.ToJson(), Enums.ActionCategory.Add);
            //移除缓存项
            CacheHelper.Remove(CacheItemKey.Sys_Role_User, WebAssist.ModifyPermissionJs);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 更新角色用户关联
        /// </summary>
        /// <param name="old_role_Id"></param>
        /// <param name="old_user_Id"></param>
        /// <param name="new_role_Id"></param>
        /// <returns></returns>
        public CommonResult Update(string user_Id, string[] role_Ids)
        {
            //删除原有关系
            db.Sys_Role_User.Where(w => w.User_Id == user_Id).Delete();
            //新建关联
            foreach (var role_Id in role_Ids)
            {
                Add(role_Id, user_Id);
            }
            //移除缓存项
            CacheHelper.Remove(CacheItemKey.Sys_Role_User, WebAssist.ModifyPermissionJs);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 删除多个角色与用户的关联
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public CommonResult DeleteByUsers(string[] userIds)
        {
            db.Sys_Role_User.Where(w => userIds.Contains(w.User_Id)).Delete();
            //移除缓存项
            CacheHelper.Remove(CacheItemKey.Sys_Role_User, WebAssist.ModifyPermissionJs);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 删除多个角色与用户的关联
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        public CommonResult DeleteByRoles(string[] roleIds)
        {
            db.Sys_Role_User.Where(w => roleIds.Contains(w.Role_Id)).Delete();
            //移除缓存项
            CacheHelper.Remove(CacheItemKey.Sys_Role_User, WebAssist.ModifyPermissionJs);
            return CommonResult.Instance();
        }

        /// <summary>
        /// 从缓存中获取所有数据
        /// </summary>
        /// <returns></returns>
        public List<Models.Sys_Role_User> GetAllByCache()
        {
            if (CacheHelper.Get(CacheItemKey.Sys_Role_User) == null)
            {
                var list = db.Sys_Role_User.ToList();
                CacheHelper.Insert(CacheItemKey.Sys_Role_User, list, CacheHelper.DayFactor);
                return list;
            }
            else
            {
                return CacheHelper.Get(CacheItemKey.Sys_Role_User) as List<Models.Sys_Role_User>;
            }
        }

    }
}
