﻿using Cat.Foundation.SiteConfig;
using Cat.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Support.System.Filter
{
    /// <summary>
    /// 认证&授权 筛选器
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]    
    public class AuthorizeFilterAttribute : ActionFilterAttribute
    {
        public bool IsNoAuthorize = false;

        FilterContextInfo filterContextInfo;

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

            filterContextInfo = new FilterContextInfo(filterContext);

            //不用检查
            if (IsNoAuthorize)
            {
                return;
            }

            #region  检查认证
            var isLogined = AllServices.SysUserService.IsLogined();
            if (!isLogined)
            {
                var absoluteUri = filterContext.HttpContext.Request.Url.AbsoluteUri;
                filterContext.Result = new RedirectResult("/Admin/Home/Login?callbackurl=" + HttpUtility.UrlEncode(absoluteUri));
                return;
            }
            #endregion

            var userInstance = AllServices.SysUserService.GetUserByCookie();
            var login_Name = userInstance.Login_Name;
            var password = userInstance.Password;

            if (login_Name.ToLower() == AllConfigServices.CatSettingsConfig.SuperAdminAccount &&
                password == AllConfigServices.CatSettingsConfig.SuperAdminPassword)
            {
                //系统预留的超级管理员账号不用检查授权
            }
            else
            {
                #region 检查授权
                //先检查是否在权限控制列表下
                var permissionList = AllServices.SysActionPermissionService.GetAllByCache();
                var isInPermission = permissionList.Where(w => w.Controller_Name.StartsWith(filterContextInfo.ControllerName) && w.Action_Name == filterContextInfo.ActionName).Count() > 0;
                if (isInPermission)
                {
                    //检查是否拥有权限
                    var user_Id = userInstance.User_Id;
                    var userPermissionList = AllServices.SysActionPermissionService.GetAllByUserId(user_Id).ToList();
                    var userHasPermission = userPermissionList.Where(w => w.Controller_Name.StartsWith(filterContextInfo.ControllerName) && w.Action_Name == filterContextInfo.ActionName).Count() > 0;
                    if (!userHasPermission)
                    {
                        ContentResult content = new ContentResult();
                        content.Content = CommonResult.ToJsonStr("您没有此操作权限！");
                        filterContext.Result = content;
                    }
                }
                #endregion
            }
        }

        public class FilterContextInfo
        {
            public FilterContextInfo(ActionExecutingContext filterContext)
            {
                //获取域名
                DomainName = filterContext.HttpContext.Request.Url.Authority;
                //获取 ControllerName 名称
                ControllerName = filterContext.RouteData.Values["controller"].ToString();
                //获取 Action 名称
                ActionName = filterContext.RouteData.Values["action"].ToString();
            }
            /// <summary>
            /// 获取域名
            /// </summary>
            public string DomainName { get; set; }
            /// <summary>
            /// 获取 ControllerName 名称
            /// </summary>
            public string ControllerName { get; set; }
            /// <summary>
            /// 获取 Action 名称
            /// </summary>
            public string ActionName { get; set; }
        }

    }
}