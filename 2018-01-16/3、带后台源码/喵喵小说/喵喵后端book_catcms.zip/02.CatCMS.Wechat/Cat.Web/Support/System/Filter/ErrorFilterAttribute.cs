﻿using Cat.Services;
using Cat.Utility;
using System;
using System.Web.Mvc;

namespace CatCMS.Support.System.Filter
{
    /// <summary>
    /// 异常信息 筛选器
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public class ErrorFilterAttribute : HandleErrorAttribute
    {
        /// <summary>
        /// 异常信息类型
        /// </summary>
        public Cat.Enums.ErrorCategory ErrorCategory = Cat.Enums.ErrorCategory.Other;

        //在程序中任何地方出现异常都会执行
        public override void OnException(ExceptionContext filterContext)
        {
            //获取异常对象
            Exception ex = filterContext.Exception;

            //记录错误日志
            AllServices.SysErrorLogService.AddLog(ex.ToString() + "\r\n" + ex.StackTrace, ErrorCategory);

            //异常信息处理
            if (ErrorCategory == Cat.Enums.ErrorCategory.FromAdmin)
            {
                //后台异常信息的处理
                var commonResult = new CommonResult(-1, ex.Message, string.Empty);
                var content = new ContentResult();
                content.Content = commonResult.ToJson();
                filterContext.Result = content;
            }
            else if (ErrorCategory == Cat.Enums.ErrorCategory.FromUser)
            {
                //前台异常信息的处理
            }
            else
            {
                //other
            }

            filterContext.ExceptionHandled = true;
            //base.OnException(filterContext);
        }
    }
}