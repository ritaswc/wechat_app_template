﻿using CatCMS.Support.System.Filter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Areas.Web.Controllers
{
    /// <summary>
    /// 前台控制器基类
    /// </summary>
    [ErrorFilter(ErrorCategory = Cat.Enums.ErrorCategory.FromUser)]
    public class BaseController : Controller
    {
    }
}