﻿using Cat.Services;
using Cat.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Areas.Web.Controllers
{
    public class CatProjectController : Controller
    {
        /// <summary>
        /// 项目列表
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            //排序所需字典
            Dictionary<string, string> dicOrderBy = new Dictionary<string, string>();
            dicOrderBy.Add("Sort_Num", "desc");
            dicOrderBy.Add("Create_Time", "desc");
            var page = AllServices.CatProjectService.GetByPage(1, 1000, null, dicOrderBy);

            ViewBag.Count = page.PageCount;
            ViewBag.List = page.List;

            return View();
        }

        /// <summary>
        /// 项目详细
        /// </summary>
        /// <returns></returns>
        public ActionResult Detail()
        {
            string id = Request["id"].ToStr();
            var instance = AllServices.CatProjectService.GetById(id) ?? new Cat.Models.Cat_Project();
            string content = string.Empty;
            try
            {
                content = FileHelper.GetTxt(Server.MapPath(instance.Static_Page_Path));
            }
            catch
            {
                content = "找不到指定路径的文件或没有权限访问文件";
            }

            //浏览量 +1
            AllServices.CatProjectPageViewRecordService.Add(id);

            ViewBag.Instance = instance;
            ViewBag.Content = content;

            return View();
        }

        /// <summary>
        /// 下载量 +1
        /// </summary>
        /// <returns></returns>
        public string AddDownloadTimes()
        {
            string id = Request["Id"].ToStr();
            return AllServices.CatProjectDownloadRecordService.Add(id).ToJson();
        }
    }
}