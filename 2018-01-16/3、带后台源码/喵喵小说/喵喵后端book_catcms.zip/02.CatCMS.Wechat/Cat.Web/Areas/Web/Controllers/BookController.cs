﻿using Cat.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Cat.Utility;
using System.Text;
using Cat.Services.BookService;
using Cat.Foundation.SiteConfig;
using Cat.Models;

namespace CatCMS.Areas.Web.Controllers
{
    public class BookController : BaseController
    {
        IBookServer iBookServer
        {
            get
            {
                return GetBookServer();
            }
        }

        // GET: Web/Book
        public ActionResult Index()
        {
            return View();
            // http://zhannei.baidu.com/cse/search?q=%E6%8B%A9%E5%A4%A9%E8%AE%B0&s=8823758711381329060
        }

        #region GetBookServer
        private IBookServer GetBookServer()
        {
            IBookServer iBookServer;
            switch (AllConfigServices.BookSettingsConfig.Crawler)
            {
                case "新笔趣阁":
                    iBookServer = new XxbiqugeBookServer();
                    break;
                default:
                    iBookServer = new XxbiqugeBookServer();
                    break;
            }
            return iBookServer;
        }
        #endregion

        /// <summary>
        /// 获取小说列表（搜索结果）
        /// </summary>
        /// <param name="q"></param>
        /// <returns></returns>
        public string GetBookList(string q)
        {
            try
            {
                Cat.Models.Book.BookList instance = iBookServer.GetBookList(q);
                return CommonResult.ToJsonStr(1, "", instance);
            }
            catch (Exception ex)
            {
                return CommonResult.ToJsonStr(ex.ToString());
            }
        }

        /// <summary>
        /// 获取小说的章节列表
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public string GetBookChapter(string url)
        {
            try
            {
                Cat.Models.Book.BookChapter instance = iBookServer.GetBookChapter(url);
                return CommonResult.ToJsonStr(1, "", instance);
            }
            catch (Exception ex)
            {
                return CommonResult.ToJsonStr(ex.ToString());
            }
        }

        /// <summary>
        /// 获取小说的内容
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public string GetBookContent(string url)
        {
            try
            {
                Cat.Models.Book.BookContent instance = iBookServer.GetBookContent(url);
                return CommonResult.ToJsonStr(1, "", instance);
            }
            catch (Exception ex)
            {
                return CommonResult.ToJsonStr(ex.ToString());
            }
        }
    }
}