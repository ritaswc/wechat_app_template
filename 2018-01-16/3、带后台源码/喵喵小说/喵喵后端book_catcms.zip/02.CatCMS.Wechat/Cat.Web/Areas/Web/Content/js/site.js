$(function () {
    //���ض���
    $(window).scroll(function () {
        $(this).scrollTop() > 100 ? $("#back-to-top").fadeIn() : $("#back-to-top").fadeOut();
    });
    $(window).scroll();
});