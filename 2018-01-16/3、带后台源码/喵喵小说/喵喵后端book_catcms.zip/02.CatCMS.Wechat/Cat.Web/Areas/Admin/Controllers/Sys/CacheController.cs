﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel;

namespace CatCMS.Areas.Admin.Controllers.Sys
{
    [Description("后台数据缓存管理 控制器")]
    public class CacheController : BaseController
    {
        [Description("缓存清理页面")]
        public ActionResult Clear()
        {
            return View();
        }
    }
}