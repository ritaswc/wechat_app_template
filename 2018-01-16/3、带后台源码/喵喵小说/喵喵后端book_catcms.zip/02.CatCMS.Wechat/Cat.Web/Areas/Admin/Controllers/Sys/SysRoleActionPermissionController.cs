﻿using Cat.Services;
using Cat.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Areas.Admin.Controllers
{
    [Description("角色操作权限控制器")]
    public class SysRoleActionPermissionController : BaseController
    {
        //[Description("设置角色权限")]
        //public string SetPermission()
        //{
        //    string role_Id = Request["Role_Id"].ToStr();
        //    string action_Permission_Ids = Request["Action_Permission_Ids"].ToStr();
        //    string menu_Permission_Ids = Request["Menu_Permission_Ids"].ToStr();

        //    CommonResult commonResult;

        //    if (role_Id.IsNullOrEmpty() || (action_Permission_Ids.IsNullOrEmpty() && menu_Permission_Ids.IsNullOrEmpty()))
        //    {
        //        commonResult = new CommonResult("不能为空");
        //    }
        //    else
        //    {
        //        commonResult = AllServices.SysRoleActionPermissionService.SetPermission(role_Id, action_Permission_Ids, menu_Permission_Ids);
        //    }

        //    return commonResult.ToJson();
        //}

        [Description("设置角色操作权限")]
        public string SetActionPermission()
        {
            string role_Id = Request["Role_Id"].ToStr();
            string action_Permission_Ids = Request["Action_Permission_Ids"].ToStr();

            CommonResult commonResult;

            if (role_Id.IsNullOrEmpty())
            {
                commonResult = new CommonResult("不能为空");
            }
            else
            {
                commonResult = AllServices.SysRoleActionPermissionService.SetActionPermission(role_Id, action_Permission_Ids);
            }

            return commonResult.ToJson();
        }

        [Description("设置角色菜单权限")]
        public string SetMenuPermission()
        {
            string role_Id = Request["Role_Id"].ToStr();
            string menu_Permission_Ids = Request["Menu_Permission_Ids"].ToStr();

            CommonResult commonResult;

            if (role_Id.IsNullOrEmpty())
            {
                commonResult = new CommonResult("不能为空");
            }
            else
            {
                commonResult = AllServices.SysRoleActionPermissionService.SetMenuPermission(role_Id, menu_Permission_Ids);
            }

            return commonResult.ToJson();
        }

        [Description("获取角色权限")]
        public string GetPermission()
        {
            string role_Id = Request["Role_Id"].ToStr();
            return AllServices.SysRoleActionPermissionService.GetPermission(role_Id).ToJson();
        }
    }
}