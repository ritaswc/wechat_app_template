﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Cat.Utility;
using Cat.Models;
using Cat.Services;

namespace CatCMS.Areas.Admin.Controllers
{
    [Description("上传文件记录控制器")]
    public class SysUploadRecordController : BaseController
    {
        [Description("查看上传文件记录页面")]
        public ActionResult Index()
        {
            return View();
        }

        [Description("搜索上传文件记录数据")]
        public string GetListByPage()
        {
            int pn = Request["page"].ToInt(1);
            int ps = Request["rows"].ToInt(10);
            string file_Name = Request["File_Name"].ToStr();
            string sort = Request["sort"].ToStr("Create_Time");
            string order = Request["order"].ToStr("desc");

            var listFilter = new List<Cat.Utility.Filter>();

            //动态查询表达式
            listFilter.Add(Cat.Utility.Filter.Add("File_Name", Op.Contains, file_Name, true));
            var exp = LambdaExpressionBuilder.GetExpressionByAndAlso<Sys_Upload_Record>(listFilter);

            //排序所需字典
            Dictionary<string, string> dicOrderBy = new Dictionary<string, string>();
            dicOrderBy.Add(sort, order);

            //分页获取数据
            Page<Sys_Upload_Record> list = AllServices.SysUploadRecordService.GetByPage(pn, ps, exp, dicOrderBy);

            return list.ToJson();
        }

        [HttpPost]
        [Description("新增上传记录")]
        public string Add()
        {
            string file_Name = Request["File_Name"].ToStr();
            string file_Extension = Request["File_Extension"].ToStr();
            string file_Path = Request["File_Path"].ToStr();
            int contentLength = Request["ContentLength"].ToInt();
            bool isSystemCreate = Request["IsSystemCreate"].ToBoolean(false);

            if (file_Name.IsNullOrEmpty() || file_Extension.IsNullOrEmpty() || file_Path.IsNullOrEmpty() || contentLength == 0)
            {
                return CommonResult.ToJsonStr("不能为空");
            }

            var res = AllServices.SysUploadRecordService.Add(new Sys_Upload_Record()
            {
                File_Name = file_Name,
                File_Extension = file_Extension,
                File_Path = file_Path,
                ContentLength = contentLength,
                IsSystemCreate = isSystemCreate
            });
            return res.ToJson();
        }

        [HttpPost]
        [Description("删除上传记录")]
        public string Delete()
        {
            string id = Request["Upload_Record_Id"].ToStr();
            string[] userIds = id.Split(',');
            var res = AllServices.SysUploadRecordService.Delete(userIds);
            return res.ToJson();
        }

    }
}