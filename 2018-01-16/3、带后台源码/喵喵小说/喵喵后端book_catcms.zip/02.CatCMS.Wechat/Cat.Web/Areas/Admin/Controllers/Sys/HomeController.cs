﻿using Cat.Foundation.SiteConfig;
using Cat.Services;
using Cat.Utility;
using CatCMS.Support.System.Filter;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Areas.Admin.Controllers
{
    [Description("首页，登录、登出等")]
    public class HomeController : BaseController
    {
        [Description("后台默认页")]
        public ActionResult Index()
        {
            return RedirectToAction("Default");
        }

        [Description("后台默认页")]
        public ActionResult Default()
        {
            var userInstance = AllServices.SysUserService.GetUserByCookie();
            ViewBag.LoginName = userInstance.Login_Name;
            ViewBag.DisableModifyPwd = userInstance.Login_Name == AllConfigServices.CatSettingsConfig.SuperAdminAccount;

            List<Cat.Models.Sys_Menu_Permission> userMenuPermissionList;
            List<Cat.Models.Sys_Action_Permission> userActionPermissionList;
            if (userInstance.Login_Name.ToLower() == AllConfigServices.CatSettingsConfig.SuperAdminAccount &&
                userInstance.Password == AllConfigServices.CatSettingsConfig.SuperAdminPassword)
            {
                //系统预留的超级管理员拥有全部权限
                userMenuPermissionList = AllServices.SysMenuPermissionService.GetAllByCache();
                userActionPermissionList = AllServices.SysActionPermissionService.GetAllByCache();
            }
            else
            {
                userMenuPermissionList = AllServices.SysMenuPermissionService.GetAllByUserId(userInstance.User_Id).ToList();
                userActionPermissionList = AllServices.SysActionPermissionService.GetAllByUserId(userInstance.User_Id).ToList();
            }

            ViewBag.MenuPermissions = userMenuPermissionList.ToJson();
            ViewBag.ActionPermissions = userActionPermissionList.ToJson();

            //获取上次登录(上次登录，即过滤最新的一次登录)
            ViewBag.LastLogin = AllServices.SysLoginLogService.GetLastLogin();

            return View();
        }

        [Description("登录页")]
        [AuthorizeFilter(IsNoAuthorize = true)]
        public ActionResult Login()
        {
            return View();
        }

        [Description("确定登录")]
        [AuthorizeFilter(IsNoAuthorize = true)]
        public string LoginConfirm()
        {
            string login_Name = Request["Login_Name"].ToStr();
            string password = Request["Password"].ToStr();

            var res = AllServices.SysUserService.Login(login_Name, password);

            if (res.code < 0)
            {
                return res.ToJson();
            }

            //新增登录日志
            AllServices.SysLoginLogService.AddLog();

            string callbackURL = Request["callbackurl"];
            if (string.IsNullOrEmpty(callbackURL))
            {
                return CommonResult.ToJsonStr(0, string.Empty, "/Admin/Home/Default");
            }
            else
            {
                return CommonResult.ToJsonStr(0, string.Empty, callbackURL);
            }
        }

        [Description("修改密码")]
        [HttpPost]
        public string ModifyPwd()
        {
            string oldPassword = Request["OldPassword"].ToStr();
            string newPassword = Request["NewPassword"].ToStr();
            if (oldPassword.IsNullOrEmpty() || newPassword.IsNullOrEmpty())
            {
                return CommonResult.ToJsonStr("不能为空");
            }
            else
            {
                var userInstance = AllServices.SysUserService.GetUserByCookie();
                return AllServices.SysUserService.ModifyPwd(userInstance.User_Id, oldPassword, newPassword).ToJson();
            }
        }

        [Description("注销")]
        [AuthorizeFilter(IsNoAuthorize = true)]
        public ActionResult LoginOut()
        {
            AllServices.SysUserService.Logout();
            return Redirect("/Admin/Home/Login");
        }

    }
}