﻿using Cat.Models;
using Cat.Services;
using Cat.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Areas.Admin.Controllers.Custom
{
    [Description("项目浏览记录控制器")]
    public class CatProjectPageViewRecordController : BaseController
    {
        [Description("查看项目浏览记录数据页面")]
        public ActionResult Index()
        {
            return View();
        }

        [Description("搜索项目浏览记录数据")]
        public string GetListByPage()
        {
            int pn = Request["page"].ToInt(1);
            int ps = Request["rows"].ToInt(10);
            string project_Id = Request["Project_Id"].ToStr();
            string sort = Request["sort"].ToStr("Create_Time");
            string order = Request["order"].ToStr("desc");

            var listFilter = new List<Cat.Utility.Filter>();

            //动态查询表达式
            listFilter.Add(Cat.Utility.Filter.Add("Project_Id", Op.Equals, project_Id, true));
            var exp = LambdaExpressionBuilder.GetExpressionByAndAlso<Cat_Project_PageView_Record>(listFilter);

            //排序所需字典
            Dictionary<string, string> dicOrderBy = new Dictionary<string, string>();
            dicOrderBy.Add(sort, order);

            //分页获取数据
            Page<Cat_Project_PageView_Record> list = AllServices.CatProjectPageViewRecordService.GetByPage(pn, ps, exp, dicOrderBy);

            return list.ToJson();
        }
    }
}