﻿using Cat.Services;
using Cat.Utility;
using CatCMS.Areas.Admin.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Areas.Admin.Controllers
{
    [Description("上传文件管理控制器")]
    public class UploadFileManageController : BaseController
    {
        [Description("上传文件管理页面")]
        public ActionResult Index()
        {
            return View();
        }

        [Description("获取上传文件数据")]
        public string GetList()
        {
            string rootDirName = "UploadFiles";
            string root = Server.MapPath(string.Format("\\{0}", rootDirName));
            string rootId = StringHelper.GuidTo16String();
            List<DirFileTree> listDirFile = GetAllDirectory(root, rootId);
            //添加根节点
            listDirFile.Add(new DirFileTree()
            {
                Id = rootId,
                ParentId = string.Empty,
                IsDir = true,
                DirFileName = rootDirName,
                DirFileVirtualPath = "/" + rootDirName
            });

            foreach (var item in listDirFile)
            {
                item.DirFileVirtualPath = (string.Format("\\{0}{1}", rootDirName, item.DirFileVirtualPath.Replace(root, ""))).Replace("\\", "/");
            }

            return listDirFile.ToJson();

            //Page<DirFileTree> list = new Page<DirFileTree>(1, 10000, listDirFile.Count, listDirFile);
            //return list.ToJson();

        }

        [Description("替换文件(用来判断是否拥有操作权限)")]
        public string ReplaceFile()
        {
            return string.Empty;
        }

        private List<DirFileTree> GetAllDirectory(string sourceDirectory, string pid)
        {
            List<DirFileTree> dirFileTrees = new List<DirFileTree>();
            string id;
            if (Directory.Exists(sourceDirectory))
            {
                string[] folders = Directory.GetDirectories(sourceDirectory);
                if (folders.Length > 0)
                {
                    foreach (string folder in folders)
                    {
                        id = StringHelper.GuidTo16String();
                        //添加文件夹数据
                        dirFileTrees.Add(new DirFileTree()
                        {
                            Id = id,
                            ParentId = pid,
                            IsDir = true,
                            DirFileName = folder.Substring(folder.LastIndexOf("\\")).Replace("\\", ""),
                            DirFileVirtualPath = folder
                        });
                        dirFileTrees.AddRange(GetAllDirectory(folder, id));
                    }
                }
                //添加文件数据
                var files = Directory.GetFiles(sourceDirectory);
                foreach (var item in files)
                {
                    id = StringHelper.GuidTo16String();
                    dirFileTrees.Add(new DirFileTree()
                    {
                        Id = id,
                        ParentId = pid,
                        IsDir = false,
                        DirFileName = Path.GetFileName(item),
                        DirFileVirtualPath = item
                    });
                }
            }
            return dirFileTrees;
        }
    }

    public class DirFileTree
    {
        public string Id { get; set; }
        public string ParentId { get; set; }
        public bool IsDir { get; set; }
        public string DirFileName { get; set; }
        public string DirFileVirtualPath { get; set; }
    }

}