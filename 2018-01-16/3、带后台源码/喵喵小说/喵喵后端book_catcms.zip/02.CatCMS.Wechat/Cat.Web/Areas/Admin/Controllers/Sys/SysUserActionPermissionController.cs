﻿using Cat.Services;
using Cat.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Areas.Admin.Controllers
{
    [Description("用户操作控制器")]
    public class SysUserActionPermissionController : BaseController
    {
        //[Description("设置角色权限")]
        //public string SetPermission()
        //{
        //    string user_Id = Request["User_Id"].ToStr();
        //    string action_Permission_Ids = Request["Action_Permission_Ids"].ToStr();
        //    string menu_Permission_Ids = Request["Menu_Permission_Ids"].ToStr();

        //    CommonResult commonResult;
            
        //    if (user_Id.IsNullOrEmpty() || (action_Permission_Ids.IsNullOrEmpty() && menu_Permission_Ids.IsNullOrEmpty()))
        //    {
        //        commonResult = new CommonResult("不能为空");
        //    }
        //    else
        //    {
        //        commonResult = AllServices.SysUserActionPermissionService.SetPermission(user_Id, action_Permission_Ids, menu_Permission_Ids);
        //    }

        //    return commonResult.ToJson();
        //}

        [Description("设置用户操作权限")]
        public string SetActionPermission()
        {
            string user_Id = Request["User_Id"].ToStr();
            string action_Permission_Ids = Request["Action_Permission_Ids"].ToStr();

            CommonResult commonResult;

            if (user_Id.IsNullOrEmpty())
            {
                commonResult = new CommonResult("不能为空");
            }
            else
            {
                commonResult = AllServices.SysUserActionPermissionService.SetActionPermission(user_Id, action_Permission_Ids);
            }

            return commonResult.ToJson();
        }

        [Description("设置用户角色菜单权限")]
        public string SetMenuPermission()
        {
            string user_Id = Request["User_Id"].ToStr();
            string menu_Permission_Ids = Request["Menu_Permission_Ids"].ToStr();

            CommonResult commonResult;

            if (user_Id.IsNullOrEmpty())
            {
                commonResult = new CommonResult("不能为空");
            }
            else
            {
                commonResult = AllServices.SysUserActionPermissionService.SetMenuPermission(user_Id, menu_Permission_Ids);
            }

            return commonResult.ToJson();
        }

        [Description("获取角色权限")]
        public string GetPermission()
        {
            string user_Id = Request["User_Id"].ToStr();
            var userPermissionList = AllServices.SysUserActionPermissionService.GetPermission(user_Id);
            //var rolePermissionList = AllServices.SysRoleActionPermissionService.GetPermission(user_Id);
            return userPermissionList.ToJson();
        }
    }
}