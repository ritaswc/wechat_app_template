﻿using Cat.Services;
using Cat.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Cat.Utility;
using System.ComponentModel;
using Cat.Foundation.SiteConfig;

namespace CatCMS.Areas.Admin.Controllers
{
    [Description("用户控制器")]
    public class SysUserController : BaseController
    {
        [Description("查看用户页面")]
        public ActionResult Index()
        {
            return View();
        }

        [Description("搜索用户数据")]
        public string GetListByPage()
        {
            int pn = Request["page"].ToInt(1);
            int ps = Request["rows"].ToInt(10);
            string login_Name = Request["Login_Name"].ToStr();
            string user_Id = Request["User_Id"].ToStr();
            string user_Name = Request["User_Name"].ToStr();
            string role_Name = Request["Role_Name"].ToStr();
            string sort = Request["sort"].ToStr("Sort_Num");
            string order = Request["order"].ToStr("desc");

            var listFilter = new List<Cat.Utility.Filter>();
            //动态查询表达式
            listFilter.Add(Cat.Utility.Filter.Add("User_Id", Op.Contains, user_Id, true));
            listFilter.Add(Cat.Utility.Filter.Add("Login_Name", Op.Contains, login_Name, true));
            listFilter.Add(Cat.Utility.Filter.Add("User_Name", Op.Contains, user_Name, true));
            var expUser = LambdaExpressionBuilder.GetExpressionByAndAlso<Sys_User>(listFilter);

            var listFilterRole = new List<Cat.Utility.Filter>();
            //动态查询表达式
            listFilterRole.Add(Cat.Utility.Filter.Add("Role_Name", Op.Contains, role_Name, true));
            var expRole = LambdaExpressionBuilder.GetExpressionByAndAlso<Sys_Role>(listFilterRole);

            //排序所需字典
            Dictionary<string, string> dicOrderBy = new Dictionary<string, string>();
            dicOrderBy.Add(sort, order);

            //分页获取数据
            Page<Sys_User> list = AllServices.SysUserService.GetByPage(pn, ps, expUser, expRole, dicOrderBy);

            return list.ToJson();
        }

        [HttpPost]
        [Description("删除用户数据")]
        public string Delete()
        {
            string userId = Request["User_Id"].ToStr();
            string[] userIds = userId.Split(',');
            var res = AllServices.SysUserService.Delete(userIds);
            return res.ToJson();
        }

        [HttpPost]
        [Description("新增用户数据")]
        public string Add()
        {
            string role_Id = Request["Role_Id"].ToStr();
            string login_Name = Request["Login_Name"].ToStr();
            string user_Name = Request["User_Name"].ToStr();
            string password = Request["Password"].ToStr();
            int state = Request["State"].ToInt();
            string desc = Request["Desc"].ToStr();
            string sort_Num = Request["Sort_Num"].ToStr(StringHelper.GetSortNum().ToStr());

            if (login_Name.IsNullOrEmpty() || user_Name.IsNullOrEmpty() || password.IsNullOrEmpty() || role_Id.IsNullOrEmpty())
            {
                return CommonResult.ToJsonStr("不能为空");
            }
            else if (login_Name.ToLower() == AllConfigServices.CatSettingsConfig.SuperAdminAccount.ToLower() ||
                user_Name.ToLower() == AllConfigServices.CatSettingsConfig.SuperAdminAccount.ToLower())
            {
                return CommonResult.ToJsonStr(string.Format("不能 {0} 作为登录名或用户名", login_Name.ToLower()));
            }

            var res = AllServices.SysUserService.Add(new Sys_User()
            {
                Role_Id = role_Id,
                Login_Name = login_Name,
                User_Name = user_Name,
                Password = password,
                State = state,
                Sort_Num = Convert.ToInt64(sort_Num),
                Desc = desc
            });
            return res.ToJson();
        }

        [HttpPost]
        [Description("更新用户数据")]
        public string Update()
        {
            string role_Id = Request["Role_Id"].ToStr();
            string user_Id = Request["User_Id"].ToStr();
            string login_Name = Request["Login_Name"].ToStr();
            string user_Name = Request["User_Name"].ToStr();
            int state = Request["State"].ToInt();
            string desc = Request["Desc"].ToStr();
            string sort_Num = Request["Sort_Num"].ToStr(StringHelper.GetSortNum().ToStr());

            if (login_Name.IsNullOrEmpty() || user_Name.IsNullOrEmpty() || role_Id.IsNullOrEmpty())
            {
                return CommonResult.ToJsonStr("不能为空");
            }
            else if (login_Name.ToLower() == AllConfigServices.CatSettingsConfig.SuperAdminAccount.ToLower() ||
                user_Name.ToLower() == AllConfigServices.CatSettingsConfig.SuperAdminAccount.ToLower())
            {
                return CommonResult.ToJsonStr(string.Format("不能 {0} 作为登录名或用户名", login_Name.ToLower()));
            }

            var res = AllServices.SysUserService.Update(new Sys_User()
            {
                User_Id = user_Id,
                Login_Name = login_Name,
                User_Name = user_Name,
                State = state,
                Sort_Num = Convert.ToInt64(sort_Num),
                Desc = desc
            }, role_Id.Split(','));
            return res.ToJson();
        }

        [Description("后台用户数据导出")]
        public string Export()
        {
            return AllServices.SysDataExportService.Export("sys_user_export").ToJson();
        }

        [Description("修改密码")]
        public string ModifyPwd()
        {
            string user_Id = Request["User_Id"].ToStr();
            string password = Request["Password"].ToStr();
            return AllServices.SysUserService.ModifyPwd(user_Id, password).ToJson();
        }

    }
}