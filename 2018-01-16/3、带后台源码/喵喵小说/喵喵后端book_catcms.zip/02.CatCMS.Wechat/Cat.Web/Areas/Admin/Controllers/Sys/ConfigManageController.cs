﻿using Cat.Services;
using Cat.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Areas.Admin.Controllers
{
    [Description("配置文件控制器,更新配置文件 控制器")]
    public class ConfigManageController : BaseController
    {

        [Description("AppSettings配置文件预览页面")]
        public ActionResult AppSettings()
        {
            ///是否开启文件防盗链
            ViewBag.AntitheftLink = ConfigHelper.GetAppSetting("AntitheftLink");
            ///是否登录(前台或后台)后才能下载文件(~/UploadFiles)
            ViewBag.LoginValidation = ConfigHelper.GetAppSetting("LoginValidation");
            ///主机名
            ViewBag.Host = ConfigHelper.GetAppSetting("Host");
            ///是否缓存配置文件（缓存时间默认为1小时）
            ViewBag.CacheConfig = ConfigHelper.GetAppSetting("CacheConfig");
            ///后台按钮操作权限控制模式
            ViewBag.ActionPermissionControllerModel = ConfigHelper.GetAppSetting("ActionPermissionControllerModel");
            return View();
        }

        [HttpPost]
        [Description("修改AppSettings配置文件")]
        public string AppSettingsConfirm()
        {
            string AntitheftLink = Request["AntitheftLink"].ToStr("true");
            string LoginValidation = Request["LoginValidation"].ToStr("false");
            string CacheConfig = Request["CacheConfig"].ToStr("false");
            string Host = Request["Host"].ToStr("");
            string ActionPermissionControllerModel = Request["ActionPermissionControllerModel"].ToStr("disable");

            ConfigHelper.SetAppSetting("AntitheftLink", AntitheftLink);
            ConfigHelper.SetAppSetting("LoginValidation", LoginValidation);
            ConfigHelper.SetAppSetting("CacheConfig", CacheConfig);
            ConfigHelper.SetAppSetting("Host", Host);
            ConfigHelper.SetAppSetting("ActionPermissionControllerModel", ActionPermissionControllerModel);

            return new CommonResult().ToJson();
        }
    }
}