﻿using Cat.Models;
using Cat.Services;
using Cat.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Areas.Admin.Controllers.Custom
{
    [Description("项目信息控制器")]
    public class CatProjectController : BaseController
    {
        [Description("查看项目信息数据页面")]
        public ActionResult Index()
        {
            return View();
        }

        [Description("搜索项目信息数据")]
        public string GetListByPage()
        {
            int pn = Request["page"].ToInt(1);
            int ps = Request["rows"].ToInt(10);
            string user_Name = Request["Project_Name"].ToStr();
            string sort = Request["sort"].ToStr("Sort_Num");
            string order = Request["order"].ToStr("desc");

            var listFilter = new List<Cat.Utility.Filter>();

            //动态查询表达式
            listFilter.Add(Cat.Utility.Filter.Add("Project_Name", Op.Contains, user_Name, true));
            var exp = LambdaExpressionBuilder.GetExpressionByAndAlso<Cat_Project>(listFilter);

            //排序所需字典
            Dictionary<string, string> dicOrderBy = new Dictionary<string, string>();
            dicOrderBy.Add(sort, order);

            //分页获取数据
            Page<Cat_Project> list = AllServices.CatProjectService.GetByPage(pn, ps, exp, dicOrderBy);

            return list.ToJson();
        }

        [HttpPost]
        [Description("新增项目信息")]
        public string Add()
        {
            string project_Name = Request["Project_Name"].ToStr();
            string lead = Request["Lead"].ToStr();
            string static_Page_Path = Request["Static_Page_Path"].ToStr();
            int page_Views = Request["Page_Views"].ToInt();
            int download_Times = Request["Download_Times"].ToInt();
            string sort_Num = Request["Sort_Num"].ToStr(StringHelper.GetSortNum().ToStr());

            if (project_Name.IsNullOrEmpty())
            {
                return CommonResult.ToJsonStr("不能为空");
            }

            var res = AllServices.CatProjectService.Add(new Cat_Project()
            {
                Project_Name = project_Name,
                Lead = lead,
                Static_Page_Path = static_Page_Path,
                Page_Views = page_Views,
                Download_Times = download_Times,
                Sort_Num = Convert.ToInt64(sort_Num)
            });
            return res.ToJson();
        }

        [HttpPost]
        [Description("更新项目信息")]
        public string Update()
        {
            string project_Id = Request["Project_Id"].ToStr();
            string project_Name = Request["Project_Name"].ToStr();
            string lead = Request["Lead"].ToStr();
            string static_Page_Path = Request["Static_Page_Path"].ToStr();
            int page_Views = Request["Page_Views"].ToInt();
            int download_Times = Request["Download_Times"].ToInt();
            string sort_Num = Request["Sort_Num"].ToStr(StringHelper.GetSortNum().ToStr());

            if (project_Name.IsNullOrEmpty())
            {
                return CommonResult.ToJsonStr("不能为空");
            }

            var res = AllServices.CatProjectService.Update(new Cat_Project()
            {
                Project_Id = project_Id,
                Project_Name = project_Name,
                Lead = lead,
                Static_Page_Path = static_Page_Path,
                Page_Views = page_Views,
                Download_Times = download_Times,
                Sort_Num = Convert.ToInt64(sort_Num)
            });
            return res.ToJson();
        }

        [HttpPost]
        [Description("删除项目信息")]
        public string Delete()
        {
            string project_Id = Request["Project_Id"].ToStr();
            string[] ids = project_Id.Split(',');
            var res = AllServices.CatProjectService.Delete(ids);
            return res.ToJson();
        }
    }
}