﻿using Cat.Models;
using Cat.Services;
using Cat.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Areas.Admin.Controllers
{
    [Description("角色控制器")]
    public class SysRoleController : BaseController
    {
        [Description("查看角色数据页面")]
        public ActionResult Index()
        {
            return View();
        }

        [Description("搜索角色数据")]
        public string GetListByPage()
        {
            int pn = Request["page"].ToInt(1);
            int ps = Request["rows"].ToInt(10);
            string user_Id = Request["Role_Id"].ToStr();
            string user_Name = Request["Role_Name"].ToStr();
            string sort = Request["sort"].ToStr("Sort_Num");
            string order = Request["order"].ToStr("desc");

            var listFilter = new List<Cat.Utility.Filter>();

            //动态查询表达式
            listFilter.Add(Cat.Utility.Filter.Add("Role_Id", Op.Contains, user_Id, true));
            listFilter.Add(Cat.Utility.Filter.Add("Role_Name", Op.Contains, user_Name, true));
            var exp = LambdaExpressionBuilder.GetExpressionByAndAlso<Sys_Role>(listFilter);

            //排序所需字典
            Dictionary<string, string> dicOrderBy = new Dictionary<string, string>();
            dicOrderBy.Add(sort, order);

            //分页获取数据
            Page<Sys_Role> list = AllServices.SysRoleService.GetByPage(pn, ps, exp, dicOrderBy);

            return list.ToJson();
        }

        [HttpPost]
        [Description("新增角色")]
        public string Add()
        {
            string role_Name = Request["Role_Name"].ToStr();
            int state = Request["State"].ToInt();
            string desc = Request["Desc"].ToStr();
            string sort_Num = Request["Sort_Num"].ToStr(StringHelper.GetSortNum().ToStr());

            if (role_Name.IsNullOrEmpty())
            {
                return CommonResult.ToJsonStr("不能为空");
            }

            var res = AllServices.SysRoleService.Add(new Sys_Role()
            {
                Role_Name = role_Name,
                State = state,
                Sort_Num = Convert.ToInt64(sort_Num),
                Desc = desc
            });
            return res.ToJson();
        }

        [HttpPost]
        [Description("更新角色")]
        public string Update()
        {
            string role_Id = Request["Role_Id"].ToStr();
            string role_Name = Request["Role_Name"].ToStr();
            int state = Request["State"].ToInt();
            string desc = Request["Desc"].ToStr();
            string sort_Num = Request["Sort_Num"].ToStr(StringHelper.GetSortNum().ToStr());

            if (role_Id.IsNullOrEmpty() || role_Name.IsNullOrEmpty())
            {
                return CommonResult.ToJsonStr("不能为空");
            }

            var res = AllServices.SysRoleService.Update(new Sys_Role()
            {
                Role_Id = role_Id,
                Role_Name = role_Name,
                State = state,
                Sort_Num = Convert.ToInt64(sort_Num),
                Desc = desc
            });
            return res.ToJson();
        }

        [HttpPost]
        [Description("删除角色")]
        public string Delete()
        {
            string userId = Request["Role_Id"].ToStr();
            string[] userIds = userId.Split(',');
            var res = AllServices.SysRoleService.Delete(userIds);
            return res.ToJson();
        }

    }
}