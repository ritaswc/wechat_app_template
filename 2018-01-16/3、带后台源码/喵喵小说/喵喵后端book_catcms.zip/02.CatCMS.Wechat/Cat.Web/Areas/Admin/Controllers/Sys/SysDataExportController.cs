﻿using Cat.Services;
using Cat.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Cat.Utility;
using System.ComponentModel;
using Cat.Foundation.SiteConfig;

namespace CatCMS.Areas.Admin.Controllers
{
    [Description("数据导出控制器")]
    public class SysDataExportController : BaseController
    {
        [Description("数据导出页面")]
        public ActionResult Index()
        {
            return View();
        }

        [Description("查看数据导出信息")]
        public string GetListByPage()
        {
            int pn = Request["page"].ToInt(1);
            int ps = Request["rows"].ToInt(10);
            string key = Request["Key"].ToStr();
            string title = Request["Title"].ToStr();
            string sort = Request["sort"].ToStr("Create_Time");
            string order = Request["order"].ToStr("desc");

            var listFilter = new List<Cat.Utility.Filter>();
            //动态查询表达式
            listFilter.Add(Cat.Utility.Filter.Add("Key", Op.Contains, key, true));
            listFilter.Add(Cat.Utility.Filter.Add("Title", Op.Contains, title, true));
            var exp = LambdaExpressionBuilder.GetExpressionByAndAlso<Sys_Data_Export>(listFilter);

            //排序所需字典
            Dictionary<string, string> dicOrderBy = new Dictionary<string, string>();
            dicOrderBy.Add(sort, order);

            //分页获取数据
            Page<Sys_Data_Export> list = AllServices.SysDataExportService.GetByPage(pn, ps, exp, dicOrderBy);

            return list.ToJson();
        }

        [HttpPost]
        [Description("删除数据导出信息")]
        public string Delete()
        {
            string userId = Request["Data_Export_Id"].ToStr();
            string[] userIds = userId.Split(',');
            var res = AllServices.SysDataExportService.Delete(userIds);
            return res.ToJson();
        }

        [HttpPost]
        [Description("新增数据导出信息")]
        public string Add()
        {
            string key = Request["Key"].ToStr();
            string sql = Request["SQL"].ToStr();
            string title = Request["Title"].ToStr();
            string desc = Request["Desc"].ToStr();

            if (key.IsNullOrEmpty() || sql.IsNullOrEmpty() || title.IsNullOrEmpty())
            {
                return CommonResult.ToJsonStr("不能为空");
            }

            var res = AllServices.SysDataExportService.Add(new Sys_Data_Export()
            {
                Key = key,
                SQL = sql,
                Title = title,
                Desc = desc
            });
            return res.ToJson();
        }

        [HttpPost]
        [Description("更新数据导出信息")]
        public string Update()
        {
            string data_Export_Id = Request["Data_Export_Id"].ToStr();
            string key = Request["Key"].ToStr();
            string sql = Request["SQL"].ToStr();
            string title = Request["Title"].ToStr();
            string desc = Request["Desc"].ToStr();

            if (data_Export_Id.IsNullOrEmpty() || key.IsNullOrEmpty() || title.IsNullOrEmpty() || sql.IsNullOrEmpty())
            {
                return CommonResult.ToJsonStr("不能为空");
            }

            var res = AllServices.SysDataExportService.Update(new Sys_Data_Export()
            {
                Data_Export_Id = data_Export_Id,
                Key = key,
                SQL = sql,
                Title = title,
                Desc = desc
            });
            return res.ToJson();
        }

    }
}