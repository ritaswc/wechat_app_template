﻿using Cat.Models;
using Cat.Services;
using Cat.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Areas.Admin.Controllers
{
    [Description("菜单权限控制器")]
    public class SysMenuPermissionController : BaseController
    {
        // GET: Admin/Action_Permission
        [Description("查看菜单权限控制页面")]
        public ActionResult Index()
        {
            return View();
        }

        [Description("搜索菜单权限控制数据")]
        public string GetListByPage()
        {
            int pn = 1;
            int ps = 10000;

            //排序所需字典
            Dictionary<string, string> dicOrderBy = new Dictionary<string, string>();
            dicOrderBy.Add("Sort_Num", "desc");

            //分页获取数据
            Page<Sys_Menu_Permission> list = AllServices.SysMenuPermissionService.GetByPage(pn, ps, null, dicOrderBy);

            return list.ToJson();
        }

        [Description("新增菜单权限控制数据")]
        [HttpPost]
        public string Add()
        {
            string parent_Id = Request["Menu_Permission_Id"].ToStr();
            string menu_Name = Request["Menu_Name"].ToStr();
            string icon = Request["Icon"].ToStr();
            string redirect_URL = Request["Redirect_URL"].ToStr();
            string sort_Num = Request["Sort_Num"].ToStr(StringHelper.GetSortNum().ToStr());

            var res = AllServices.SysMenuPermissionService.Add(new Sys_Menu_Permission()
            {
                Parent_Id = parent_Id,
                Menu_Name = menu_Name,
                Icon = icon,
                Redirect_URL = redirect_URL,
                Sort_Num = Convert.ToInt64(sort_Num),
                Create_Time = DateTime.Now,
                Update_Time = DateTime.Now
            });
            return res.ToJson();
        }

        [Description("更新菜单权限控制数据")]
        [HttpPost]
        public string Update()
        {
            string menu_Permission_Id = Request["Menu_Permission_Id"].ToStr();
            string parent_Id = Request["Parent_Id"].ToStr();
            string menu_Name = Request["Menu_Name"].ToStr();
            string icon = Request["Icon"].ToStr();
            string sort_Num = Request["Sort_Num"].ToStr(StringHelper.GetSortNum().ToStr());
            string redirect_URL = Request["Redirect_URL"].ToStr();

            var res = AllServices.SysMenuPermissionService.Update(new Sys_Menu_Permission()
            {
                Menu_Permission_Id = menu_Permission_Id,
                Parent_Id = parent_Id,
                Menu_Name = menu_Name,
                Icon = icon,
                Sort_Num = Convert.ToInt64(sort_Num),
                Redirect_URL = redirect_URL,
                Create_Time = DateTime.Now,
                Update_Time = DateTime.Now
            });
            return res.ToJson();
        }

        [Description("删除菜单权限控制数据")]
        [HttpPost]
        public string Delete()
        {
            string id = Request["id"].ToStr();
            var res = AllServices.SysMenuPermissionService.Delete(id);
            return res.ToJson();
        }

        [Description("菜单权限赋予（角色、用户）页面")]
        public ActionResult Give()
        {
            return View();
        }

    }
}