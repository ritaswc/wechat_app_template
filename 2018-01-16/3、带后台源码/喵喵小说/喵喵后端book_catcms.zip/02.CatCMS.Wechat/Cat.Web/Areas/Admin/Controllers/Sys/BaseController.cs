﻿using CatCMS.Support.System.Filter;
using System.Web.Mvc;

namespace CatCMS.Areas.Admin.Controllers
{
    /// <summary>
    /// 后台控制器基类
    /// </summary>
    [ErrorFilter(ErrorCategory = Cat.Enums.ErrorCategory.FromAdmin)]
    [AuthorizeFilter]
    public class BaseController : Controller
    {
    }
}