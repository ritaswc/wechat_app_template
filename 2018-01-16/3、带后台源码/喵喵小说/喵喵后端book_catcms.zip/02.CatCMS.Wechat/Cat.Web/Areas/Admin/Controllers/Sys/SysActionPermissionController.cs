﻿using Cat.Models;
using Cat.Services;
using Cat.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace CatCMS.Areas.Admin.Controllers
{
    [Description("操作权限控制器")]
    public class SysActionPermissionController : BaseController
    {
        [Description("查看操作权限控制页面")]
        public ActionResult Index()
        {
            ViewBag.AllActionByAssembly = AllServices.SysActionPermissionService.GetAllActionByAssembly().ToJson();
            return View();
        }

        [Description("搜索操作权限控制数据")]
        public string GetListByPage()
        {
            int pn = 1;
            int ps = 10000;

            //排序所需字典
            Dictionary<string, string> dicOrderBy = new Dictionary<string, string>();
            dicOrderBy.Add("Sort_Num", "desc");

            //分页获取数据
            Page<Sys_Action_Permission> list = AllServices.SysActionPermissionService.GetByPage(pn, ps, null, dicOrderBy);
            
            return list.ToJson();
        }

        [Description("新增操作权限")]
        [HttpPost]
        public string Add()
        {
            string parent_Id = Request["Action_Permission_Id"].ToStr();
            string isDirectory = Request["IsDirectory"].ToStr();
            string alias_Name = Request["Alias_Name"].ToStr();
            string controller_Name = Request["Controller_Name"].ToStr();
            string action_Name = Request["Action_Name"].ToStr();
            int category = Request["Category"].ToInt(0);
            string desc = Request["Desc"].ToStr();
            string sort_Num = Request["Sort_Num"].ToStr(StringHelper.GetSortNum().ToStr());

            var res = AllServices.SysActionPermissionService.Add(new Sys_Action_Permission()
            {
                Parent_Id = parent_Id,
                IsDirectory = isDirectory == "on",
                Alias_Name = alias_Name,
                Controller_Name = controller_Name,
                Action_Name = action_Name,
                Category = category,
                Desc = desc,
                Sort_Num = Convert.ToInt64(sort_Num),
                Create_Time = DateTime.Now,
                Update_Time = DateTime.Now
            });
            return res.ToJson();
        }

        [Description("更新操作权限")]
        [HttpPost]
        public string Update()
        {
            string action_Permission_Id = Request["Action_Permission_Id"].ToStr();
            string parent_Id = Request["Parent_Id"].ToStr();
            string isDirectory = Request["IsDirectory"].ToStr();
            string alias_Name = Request["Alias_Name"].ToStr();
            string controller_Name = Request["Controller_Name"].ToStr();
            string action_Name = Request["Action_Name"].ToStr();
            int category = Request["Category"].ToInt(0);
            string desc = Request["Desc"].ToStr();
            string sort_Num = Request["Sort_Num"].ToStr(StringHelper.GetSortNum().ToStr());

            var res = AllServices.SysActionPermissionService.Update(new Sys_Action_Permission()
            {
                Action_Permission_Id = action_Permission_Id,
                Parent_Id = parent_Id,
                IsDirectory = isDirectory == "on",
                Alias_Name = alias_Name,
                Controller_Name = controller_Name,
                Action_Name = action_Name,
                Category = category,
                Desc = desc,
                Sort_Num = Convert.ToInt64(sort_Num),
                Create_Time = DateTime.Now,
                Update_Time = DateTime.Now
            });
            return res.ToJson();
        }

        [Description("删除操作权限")]
        [HttpPost]
        public string Delete()
        {
            string id = Request["id"].ToStr();
            var res = AllServices.SysActionPermissionService.Delete(id);
            return res.ToJson();
        }
        
        [Description("获取指定命名空间下的控制器与方法组成的集合")]
        public string GetActions()
        {
            var list = AllServices.SysActionPermissionService.GetAllActionByAssembly();
            return list.OrderBy(o => o.ControllerName).ThenBy(t => t.ActionName).ToJson();
        }

        [Description("操作权限赋予（角色、用户）页面")]
        public ActionResult Give()
        {
            return View();
        }

    }
}