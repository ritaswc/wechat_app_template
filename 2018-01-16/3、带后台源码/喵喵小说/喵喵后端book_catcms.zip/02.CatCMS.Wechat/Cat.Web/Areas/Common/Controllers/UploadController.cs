﻿using Cat.Foundation.SiteConfig;
using Cat.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Cat.Utility;

namespace CatCMS.Areas.Common.Controllers
{
    /// <summary>
    /// 上传文件控制器
    /// </summary>
    public class UploadController : Controller
    {
        /// <summary>
        /// 上传图片,根据config的参数值确定对应的配置文件
        /// </summary>
        /// <param name="fileData"></param>
        /// <returns></returns>
        public string UploadImage(HttpPostedFileBase fileData)
        {
            string config = Request["config"].ToStr("ImageUploadBaseConfig");

            var configInstance = ConfigHelper.GetConfig<Cat.Foundation.SiteConfig.Models.ImageUploadBaseConfig>(config);
            var res = AllServices.ImageUploadService.ImageHandler(fileData, configInstance);

            //var res = AllServices.ImageUploadService.ImageHandler(fileData, AllConfigServices.NewsImageUploadConfig);
            return res.ToJson();
        }

        /// <summary>
        /// 上传文件,根据config的参数值确定对应的配置文件
        /// </summary>
        /// <param name="fileData"></param>
        /// <returns></returns>
        public string UploadFile(HttpPostedFileBase fileData)
        {
            string config = Request["config"].ToStr("FileUploadConfig");

            var configInstance = ConfigHelper.GetConfig<Cat.Foundation.SiteConfig.Models.FileUploadConfig>(config);
            var res = AllServices.FileUploadService.FileHandler(fileData, configInstance);

            return res.ToJson();
        }

        /// <summary>
        /// 替换文件
        /// </summary>
        /// <param name="fileData"></param>
        /// <returns></returns>
        public string ReplaceFile(HttpPostedFileBase fileData)
        {
            CommonResult result = new CommonResult();

            string filePath = Request["FilePath"].ToStr();
            string extension = System.IO.Path.GetExtension(filePath);

            if (extension.ToLower() != System.IO.Path.GetExtension(fileData.FileName).ToLower())
            {
                result = new CommonResult("上传的文件必须与目标文件的文件扩展名一致");
            }
            else
            {
                //临时保存新文件
                fileData.SaveAs(Server.MapPath(filePath) + "_temp");
                //删除原文件
                System.IO.File.Delete(Server.MapPath(filePath));
                //重命名新文件
                System.IO.FileInfo fileInfo = new System.IO.FileInfo(Server.MapPath(filePath) + "_temp");
                fileInfo.MoveTo(Server.MapPath(filePath));
            }

            return result.ToJson();
        }
    }
}