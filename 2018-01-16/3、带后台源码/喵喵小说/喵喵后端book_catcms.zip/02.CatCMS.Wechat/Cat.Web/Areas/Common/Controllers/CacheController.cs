﻿using System.Web.Mvc;

namespace CatCMS.Areas.Common.Controllers
{
    /// <summary>
    /// 缓存处理控制器
    /// </summary>
    public class CacheController : Controller
    {
        /// <summary>
        /// 清除配置文件实例的缓存
        /// </summary>
        /// <returns></returns>
        public string ClearConfig()
        {
            Cat.Utility.CacheHelper.RemoveByPattern("^CK_SiteConfigCode_.*");
            return "配置文件缓存已清理";
        }

        /// <summary>
        /// 后台数据缓存清理
        /// </summary>
        /// <returns></returns>
        public string ClearAdmin()
        {
            Cat.Utility.CacheHelper.RemoveByPattern("^cache_key_admin_.*");
            return "后台数据缓存已清理";
        }
    }
}