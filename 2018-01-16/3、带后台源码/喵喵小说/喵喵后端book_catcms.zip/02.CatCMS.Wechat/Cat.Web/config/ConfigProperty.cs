﻿using Cat.Foundation.SiteConfig;

namespace CatCMS
{
    /// <summary>
    /// 站点的配置属性
    /// </summary>
    public class ConfigProperty
    {
        /// <summary>
        /// 当前站点版本号
        /// </summary>
        public static string Version
        {
            get
            {
                return AllConfigServices.CatSettingsConfig.Version;
            }
        }
    }
}