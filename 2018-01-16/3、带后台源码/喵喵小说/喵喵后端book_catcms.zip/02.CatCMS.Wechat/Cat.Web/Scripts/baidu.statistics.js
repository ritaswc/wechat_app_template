﻿var _hmt = _hmt || [];
(function () {
    if (window.location.hostname != "localhost") {
        var hm = document.createElement("script");
        hm.src = "//hm.baidu.com/hm.js?184cd52f9e03be5890ef3213f6dc3c24";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
    }
})();