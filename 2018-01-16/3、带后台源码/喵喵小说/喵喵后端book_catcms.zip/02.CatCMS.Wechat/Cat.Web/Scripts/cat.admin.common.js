﻿/// <reference path="jquery-1.10.2.min.js" />
/// <reference path="~/Support/Web/easyui/jquery.easyui.min.js" />

cat = window.cat || {};
cat.admin = cat.admin || {};

/*
* 操作结果处理(数据的 增、删、改 等)
* data: 后台返回的结果，格式如：{"code":0,"errmsg":"服务器错误","data":null}
* callbackFunc: 回调函数
*/
cat.admin.OpResultResponse = function (data, callbackFunc) {
    try {
        var _data = $.parseJSON(data);
        if (_data.code < 0)
            $.messager.alert("操作失败", _data.errmsg, "error");
        else
            callbackFunc(_data);
    }
    catch (ex) {
        $.messager.alert("操作失败", "请刷新后再试", "error");
    }
    finally {
        cat.admin.loading(false);
    }
};
/*
* 加载中
*/
cat.admin.loading = function (visible) {
    if (visible == false) {
        $('#cat-alert-layer-mask, #cat-alert-layer-mask-msg').remove();
    }
    else {
        $("<div id=\"cat-alert-layer-mask\" class=\"datagrid-mask\"></div>").css({ display: "block", 'z-index': 10000, width: "100%", height: $(window).height() }).appendTo("body");
        $("<div id=\"cat-alert-layer-mask-msg\" class=\"datagrid-mask-msg\"></div>").html("正在处理，请稍候。。。").appendTo("body").css({ display: "block", 'z-index': 10001, left: ($(document.body).outerWidth(true) - 190) / 2, top: ($(window).height() - 45) / 2 });
    }
};
/*
* 获取url中的参数
*/
cat.admin.getUrlParam = function getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg);  //匹配目标参数
    if (r != null) return decodeURIComponent(r[2]); return null; //返回参数值
};
/*
* 判断指定操作是否有权限
*/
cat.admin.permissioncheck = function permissioncheck(controller, action, targetId) {
    var isok = true;

    function isInPermissions(listObj) { //指定的controller和action是否在权限列表中
        for (var i = 0; i < listObj.length; i++) {
            if ((listObj[i].Controller_Name.toLowerCase() == controller.toLowerCase() ||
                listObj[i].Controller_Name.toLowerCase().replace('controller', '') == controller.toLowerCase()) &&
                listObj[i].Action_Name.toLowerCase() == action.toLowerCase()) {
                return true;
            }
        }
        if (listObj.length == 0)
            return true;
        else
            return false;
    };

    var allPermissions = JSON.parse(window.localStorage.cat_action_permissions);
    var userPermissions = JSON.parse(window.localStorage.cat_user_action_permissions);

    if (isInPermissions(allPermissions)) {
        if (!isInPermissions(userPermissions)) {
            isok = false;
        }
    }

    if (!isok) {
        //console.info('$(targetId)', $(targetId));
        if (cat.global.ActionPermissionControllerModel == 'disable' || !cat.global.ActionPermissionControllerModel) {
            $(targetId).bind('click', function () { $.messager.alert('操作提示', '您没有此操作权限！'); });
            $(targetId).linkbutton('disable'); //禁用按钮
        }
        else if (cat.global.ActionPermissionControllerModel == 'hide') {
            $(targetId).hide(); //隐藏按钮
        }
        else if (cat.global.ActionPermissionControllerModel == 'none') {

        }
    };
    return isok;
};
/*
* 获取排序号：1970/01/01 到现在的秒数
*/
cat.admin.getSortNum = function () {
    return parseInt((new Date().getTime() / 1000) + 28800);
};