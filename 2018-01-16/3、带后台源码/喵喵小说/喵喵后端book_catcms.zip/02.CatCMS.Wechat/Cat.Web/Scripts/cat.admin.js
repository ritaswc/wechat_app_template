
window.onload = function () {
    $('#loading-mask').fadeOut();
}

var onlyOpenTitle = "欢迎使用";//不允许关闭的标签的标题

$(function () {
    setMenu(_menu,function () {
        InitLeftMenu();
        tabClose();
        tabCloseEven();
    });

    /* 选择TAB时刷新内容
        $('#tabs').tabs({
            onSelect: function (title) {
                var currTab = $('#tabs').tabs('getTab', title);
                var iframe = $(currTab.panel('options').content);
    
                var src = iframe.attr('src');
                if(src)
                    $('#tabs').tabs('update', { tab: currTab, options: { content: createFrame(src)} });
    
            }
        });
    */
})

//初始化左侧
function InitLeftMenu() {
    $("#nav").accordion({ animate: false, fit: true, border: false });
    var selectedPanelname = '';
    $.each(_menus.menus, function (i, n) {
        var menulist = '';
        menulist += '<ul class="navlist">';
        if (!!n.menus) {
            $.each(n.menus, function (j, o) {
                menulist += '<li><div ><a ref="' + o.menuid + '" href="javascript:;" rel="' + o.url + '" ><span class="icon ' + o.icon + '" >&nbsp;</span><span class="nav">' + o.menuname + '</span></a></div> ';

                if (o.child && o.child.length > 0) {
                    //li.find('div').addClass('icon-arrow');

                    menulist += '<ul class="third_ul">';
                    $.each(o.child, function (k, p) {
                        menulist += '<li><div><a ref="' + p.menuid + '" href="javascript:;" rel="' + p.url + '" ><span class="icon ' + p.icon + '" >&nbsp;</span><span class="nav">' + p.menuname + '</span></a></div> </li>'
                    });
                    menulist += '</ul>';
                }

                menulist += '</li>';
            })
        }
        menulist += '</ul>';

        $('#nav').accordion('add', {
            title: n.menuname,
            content: menulist,
            border: false,
            iconCls: 'icon ' + n.icon
        });

        if (i == 0)
            selectedPanelname = n.menuname;

    });
    $('#nav').accordion('select', selectedPanelname);



    $('.navlist li a').click(function () {
        var tabTitle = $(this).children('.nav').text();

        var url = $(this).attr("rel");
        var menuid = $(this).attr("ref");
        var icon = $(this).find('.icon').attr('class');
        
        var third = find(menuid);
        if (third && third.child && third.child.length > 0) {
            $('.third_ul').slideUp();

            var ul = $(this).parent().next();
            if (ul.is(":hidden"))
                ul.slideDown();
            else
                ul.slideUp();



        }
        else {
            addTab(tabTitle, url, icon);
            $('.navlist li div').removeClass("selected");
            $(this).parent().addClass("selected");
        }
    }).hover(function () {
        $(this).parent().addClass("hover");
    }, function () {
        $(this).parent().removeClass("hover");
    });





    //选中第一个
    //var panels = $('#nav').accordion('panels');
    //var t = panels[0].panel('options').title;
    //$('#nav').accordion('select', t);
}
//获取左侧导航的图标
function getIcon(menuid) {
    var icon = 'icon ';
    $.each(_menus.menus, function (i, n) {
        $.each(n.menus, function (j, o) {
            if (o.menuid == menuid) {
                icon += o.icon;
            }
        })
    })

    return icon;
}

function find(menuid) {
    var obj = null;
    $.each(_menus.menus, function (i, n) {
        //console.info('find', i, n, n.menus);
        if (!!n.menus) {
            $.each(n.menus, function (j, o) {
                if (o.menuid == menuid) {
                    obj = o;
                }
            });
        }
    });

    return obj;
}

function addTab(subtitle, url, icon) {
    if (!$('#tabs').tabs('exists', subtitle)) {
        $('#tabs').tabs('add', {
            title: subtitle,
            content: createFrame(url),
            closable: true,
            icon: icon
        });
    } else {
        $('#tabs').tabs('select', subtitle);
        $('#mm-tabupdate').click();
    }
    tabClose();
}

function createFrame(url) {
    var s = '<iframe scrolling="auto" frameborder="0"  src="' + url + '" style="width:100%;height:99%;border:0;"></iframe>';
    return s;
}

function tabClose() {
    /*双击关闭TAB选项卡*/
    $(".tabs-inner").dblclick(function () {
        var subtitle = $(this).children(".tabs-closable").text();
        $('#tabs').tabs('close', subtitle);
    })
    /*为选项卡绑定右键*/
    $(".tabs-inner").bind('contextmenu', function (e) {
        $('#mm').menu('show', {
            left: e.pageX,
            top: e.pageY
        });

        var subtitle = $(this).children(".tabs-closable").text();

        $('#mm').data("currtab", subtitle);
        $('#tabs').tabs('select', subtitle);
        return false;
    });
}


//绑定右键菜单事件
function tabCloseEven() {

    $('#mm').menu({
        onClick: function (item) {
            closeTab(item.id);
        }
    });

    return false;
}

function closeTab(action) {
    var alltabs = $('#tabs').tabs('tabs');
    var currentTab = $('#tabs').tabs('getSelected');
    var allTabtitle = [];
    $.each(alltabs, function (i, n) {
        allTabtitle.push($(n).panel('options').title);
    })


    switch (action) {
        case "refresh":
            var iframe = $(currentTab.panel('options').content);
            var src = iframe.attr('src');
            $('#tabs').tabs('update', {
                tab: currentTab,
                options: {
                    content: createFrame(src)
                }
            })
            break;
        case "close":
            var currtab_title = currentTab.panel('options').title;
            $('#tabs').tabs('close', currtab_title);
            break;
        case "closeall":
            $.each(allTabtitle, function (i, n) {
                if (n != onlyOpenTitle) {
                    $('#tabs').tabs('close', n);
                }
            });
            break;
        case "closeother":
            var currtab_title = currentTab.panel('options').title;
            $.each(allTabtitle, function (i, n) {
                if (n != currtab_title && n != onlyOpenTitle) {
                    $('#tabs').tabs('close', n);
                }
            });
            break;
        case "closeright":
            var tabIndex = $('#tabs').tabs('getTabIndex', currentTab);

            if (tabIndex == alltabs.length - 1) {
                return false;
            }
            $.each(allTabtitle, function (i, n) {
                if (i > tabIndex) {
                    if (n != onlyOpenTitle) {
                        $('#tabs').tabs('close', n);
                    }
                }
            });

            break;
        case "closeleft":
            var tabIndex = $('#tabs').tabs('getTabIndex', currentTab);
            if (tabIndex == 1) {
                return false;
            }
            $.each(allTabtitle, function (i, n) {
                if (i < tabIndex) {
                    if (n != onlyOpenTitle) {
                        $('#tabs').tabs('close', n);
                    }
                }
            });

            break;
        //case "exit":
        //    $('#closeMenu').menu('hide');
        //    break;
    }
}


//弹出信息窗口 title:标题 msgString:提示信息 msgType:信息类型 [error,info,question,warning]
function msgShow(title, msgString, msgType) {
    $.messager.alert(title, msgString, msgType);
}

var _menus = [];
function setMenu(data, callback) {
    var jsonData = data;
    var list = new Array();
    for (var i = 0; i < jsonData.length; i++) {
        list.push({
            id: jsonData[i].Menu_Permission_Id,
            menuid: jsonData[i].Menu_Permission_Id,
            icon: jsonData[i].Icon,
            menuname: jsonData[i].Menu_Name,
            url: jsonData[i].Redirect_URL,
            pid: jsonData[i].Parent_Id,
        })
    }
    //console.info('list', list);
    var menuFormatJson = getMeunFormat({ data: list, ignoreRoot: true, visibleFields: 'menuid,icon,menuname,url' });
    _menus = { menus: menuFormatJson };
    callback();
    //$.ajax({
    //    url: '/Admin/SysMenuPermission/GetListByPage',
    //    success: function (data) {
    //        var jsonData = $.parseJSON(data);
    //        var list = new Array();
    //        for (var i = 0; i < jsonData.List.length; i++) {
    //            list.push({
    //                id: jsonData.List[i].Menu_Permission_Id,
    //                menuid: jsonData.List[i].Menu_Permission_Id,
    //                icon: jsonData.List[i].Icon,
    //                menuname: jsonData.List[i].Menu_Name,
    //                url: jsonData.List[i].Redirect_URL,
    //                pid: jsonData.List[i].Parent_Id,
    //            })
    //        }
    //        //console.info('list', list);
    //        var menuFormatJson = getMeunFormat({ data: list, ignoreRoot: true, visibleFields: 'menuid,icon,menuname,url' });
    //        _menus = { menus: menuFormatJson };
    //        callback();
    //    }
    //});
};

/*
* 构造显示菜单所需的Json
*/
var getMeunFormat = function (opt) {
    var option = {
        //id字段名称
        idField: 'id',
        //父级id字段名称
        pidField: 'pid',
        //要显示的字段
        visibleFields: '',
        //是否去除根节点
        ignoreRoot: false,
        //数据源
        data: []
    }
    $.extend(option, opt);
    //console.info(option);
    var rows = option.data,
        idFieldName = option.idField,
        pidFieldName = option.pidField,
        fields = option.visibleFields;
    //是否去除根节点
    if (option.ignoreRoot) {
        for (var i = 0; i < rows.length; i++) {
            if (rows[i][option.pidField] == '') {
                rows.splice(i, 1);
            }
        }
    }
    function exists(rows, ParentId) {
        for (var i = 0; i < rows.length; i++) {
            if (rows[i][idFieldName] == ParentId)
                return true;
        }
        return false;
    }
    var nodes = [];
    for (var i = 0; i < rows.length; i++) {
        var row = rows[i];
        if (!exists(rows, row[pidFieldName])) {
            var data = {
                id: row[idFieldName]
            }
            var arrFiled = fields.split(",");
            for (var j = 0; j < arrFiled.length; j++) {
                if (arrFiled[j] != idFieldName)
                    data[arrFiled[j]] = row[arrFiled[j]];
            }
            nodes.push(data);
        }
    }

    var toDo = [];
    for (var i = 0; i < nodes.length; i++) {
        toDo.push(nodes[i]);
    }
    while (toDo.length) {
        var node = toDo.shift();
        for (var i = 0; i < rows.length; i++) {
            var row = rows[i];
            if (row[pidFieldName] == node.id) {
                var child = {
                    id: row[idFieldName]
                };
                var arrFiled = fields.split(",");
                for (var j = 0; j < arrFiled.length; j++) {
                    if (arrFiled[j] != idFieldName) {
                        child[arrFiled[j]] = row[arrFiled[j]];
                    }
                }
                if (node.menus) {
                    node.menus.push(child);
                } else {
                    node.menus = [child];
                }
                toDo.push(child);
            }
        }
    }
    return nodes;
};