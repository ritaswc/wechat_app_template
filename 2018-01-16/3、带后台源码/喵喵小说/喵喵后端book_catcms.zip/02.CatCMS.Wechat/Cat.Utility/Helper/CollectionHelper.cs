﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat.Utility
{
    /// <summary>
    /// 网页采集辅助类
    /// </summary>
    public class CollectionHelper
    {

    }
}
