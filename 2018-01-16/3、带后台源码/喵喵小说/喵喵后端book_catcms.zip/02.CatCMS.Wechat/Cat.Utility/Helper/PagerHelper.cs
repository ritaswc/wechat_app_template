﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cat.Utility
{
    /// <summary>
    /// 前台分页帮助类
    /// </summary>
    public class PagerHelper
    {
        /// <summary>
        /// 获取分页html
        /// 显示示例（前5后4）：首页 < 5 6 7 8 9 [10] 11 12 13 14 > 尾页
        /// 请配合样式使用:
        /// .catcms-page{padding:10px 0 100px 0;text-align:center;}
        /// .catcms-page a{display:inline-block;margin:0 3px;padding:0 15px;height:40px;border:1px solid #ccc;border-radius:5px;vertical-align:middle;font-size:18px;line-height:40px;-webkit-transition:All .3s ease;-moz-transition:All .3s ease;-o-transition:All .3s ease;transition:All .3s ease;}
        /// .catcms-page a.active,.catcms-page a:hover{border:1px solid #66bb6a;background:#66bb6a;color:#fff;}
        /// .catcms-page a.lr-p{font-size: 24px;}
        /// </summary>
        /// <param name="pn">当前页</param>
        /// <param name="ps">页大小</param>
        /// <param name="count">数据总数</param>
        /// <param name="hrefFormat">href的格式，如：/Web/Course/List?pn={0}</param>
        /// <returns></returns>
        public static string getPagerHtml1(int pn, int ps, int count, string hrefFormat)
        {
            StringBuilder sb = new StringBuilder();
            int pages = count / ps + (count % ps == 0 ? 0 : 1); //页数

            if (pages == 0)
            {
                return string.Empty;
            }
            else if (pages <= 10 || pn <= 5)
            {
                int _pages = pages > 10 ? 10 : pages; //要显示的页数
                for (var i = 0; i < _pages; i++)
                {
                    if (pn == (i + 1))
                    {
                        sb.Append("<a class=\"course-page-a active\" href=\"" + string.Format(hrefFormat, (i + 1)) + "\">" + (i + 1) + "</a>");
                    }
                    else
                    {
                        sb.Append("<a class=\"course-page-a\" href=\"" + string.Format(hrefFormat, (i + 1)) + "\">" + (i + 1) + "</a>");
                    }
                }
            }
            else
            {
                int right = pages - pn > 4 ? 4 : pages - pn; //当前页距离最后一页之间相差多少页（当前页的右侧计数）
                int left = 10 - right - 1; //当前页的左侧计数
                int idx = pn - left; //左侧第一个数（开始索引）
                for (var i = idx; i < 10 + idx; i++)
                {
                    if (pn == i)
                    {
                        sb.Append("<a class=\"course-page-a active\" href=\"" + string.Format(hrefFormat, i) + "\">" + i + "</a>");
                    }
                    else
                    {
                        sb.Append("<a class=\"course-page-a\" href=\"" + string.Format(hrefFormat, i) + "\">" + i + "</a>");
                    }
                }
            }

            int prevPn = pn > 1 ? pn - 1 : pn; //上一页
            int nextPn = pn < pages ? pn + 1 : pages; //下一页
            string leftHtml = "<a class=\"course-page-a\" href=\"" + string.Format(hrefFormat, 1) + "\">首页</a><a class=\"course-page-a lr-p\" href=\"" + string.Format(hrefFormat, prevPn) + "\">‹</a>";
            string rightHtml = "<a class=\"course-page-a lr-p\" href=\"" + string.Format(hrefFormat, nextPn) + "\">›</a><a class=\"course-page-a\" href=\"" + string.Format(hrefFormat, pages) + "\">尾页</a>";

            return string.Format("<div class=\"catcms-page\">{0}{1}{2}</div>", leftHtml, sb.ToString(), rightHtml);
        }



    }
}
