﻿using Aspose.Pdf;
using Aspose.Pdf.Devices;
using Aspose.Slides;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;

namespace Cat.Utility
{
    /// <summary>
    /// Aspose转换帮助类
    /// </summary>
    public partial class AsposeConverterHelper
    {
        /// <summary>
        /// 将PPT文档转换为PDF的方法
        /// </summary>
        /// <param name="total">转换后图片的总数</param>
        /// <param name="convertFile">要转换的ppt文件（物理路径）</param>
        /// <param name="dirPath">保存到指定目录（物理路径）</param>
        /// <param name="ignoreExist">已进行过转换的文件是否要重新转换</param>
        public static bool PPT2PdfConverter(out int total, string convertFile, string dirPath = null, bool ignoreExist = false)
        {
            total = 0;
            try
            {
                Presentation ppt = new Presentation(convertFile);

                string dirName = string.Format("{0}.image", convertFile.Substring(convertFile.LastIndexOf('\\') + 1)); //转换后的图片存放目录
                dirPath = dirPath ?? HttpContext.Current.Server.MapPath(string.Format("/ConvertFiles/ppt/{0}/", dirName));

                if (!Directory.Exists(dirPath))
                {
                    Directory.CreateDirectory(dirPath);
                }
                else
                {
                    if (ignoreExist)
                    {
                        Directory.Delete(dirPath, true);
                        Directory.CreateDirectory(dirPath);
                    }
                    else
                    {
                        return true;
                    }
                }

                ppt.Save(string.Format("{0}\\{1}.{2}", dirPath, 1, "pdf"), Aspose.Slides.Export.SaveFormat.Pdf);
                total++;

                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 将PPT文档转换为图片的方法（先转为pdf，再转为图片）
        /// </summary>
        /// <param name="total">转换后图片的总数</param>
        /// <param name="convertFile">要转换的ppt文件（物理路径）</param>
        /// <param name="dirPath">保存到指定目录（物理路径）</param>
        /// <param name="ignoreExist">已进行过转换的文件是否要重新转换</param>
        public static bool PPT2ImageConverter(out int total, string convertFile, string dirPath = null, bool ignoreExist = false)
        {
            total = 0;
            try
            {
                Presentation ppt = new Presentation(convertFile);

                string dirName = string.Format("{0}.image", convertFile.Substring(convertFile.LastIndexOf('\\') + 1)); //转换后的图片存放目录
                dirPath = dirPath ?? HttpContext.Current.Server.MapPath(string.Format("/ConvertFiles/ppt/{0}/", dirName));

                if (!Directory.Exists(dirPath))
                {
                    Directory.CreateDirectory(dirPath);
                }
                else
                {
                    if (ignoreExist)
                    {
                        Directory.Delete(dirPath, true);
                        Directory.CreateDirectory(dirPath);
                    }
                    else
                    {
                        return true;
                    }
                }

                string targetFile = string.Format("{0}\\{1}.{2}", dirPath, 1, "pdf");
                //保存为pdf
                ppt.Save(targetFile, Aspose.Slides.Export.SaveFormat.Pdf);
                //根据pdf生成图片，然后删除pdf
                Document pdfDocument = new Document(targetFile);
                for (var i = 0; i < pdfDocument.Pages.Count; i++)
                {
                    using (FileStream imageStream = new FileStream(string.Format("{0}\\{1}.png", dirPath, (i + 1)), FileMode.Create))
                    {
                        Resolution resolution = new Resolution(100);
                        JpegDevice jpegDevice = new JpegDevice(resolution, 70);
                        //convert a particular page and save the image to stream
                        jpegDevice.Process(pdfDocument.Pages[i + 1], imageStream);
                        //close stream
                        imageStream.Close();
                        total++;
                    }
                }
                File.Delete(targetFile);
                return true;
            }
            catch
            {
                Directory.Delete(dirPath, true);
                return false;
            }
        }

        /// <summary>
        /// 将PPTX文档转换为PDF的方法（先转为pdf，再转为图片）
        /// </summary>
        /// <param name="total">转换后图片的总数</param>
        /// <param name="convertFile">要转换的pptx文件（物理路径）</param>
        /// <param name="dirPath">保存到指定目录（物理路径）</param>
        /// <param name="ignoreExist">已进行过转换的文件是否要重新转换</param>
        public static bool PPTX2PDFConverter(out int total, string convertFile, string dirPath = null, bool ignoreExist = false)
        {
            total = 0;
            try
            {
                Aspose.Slides.Pptx.PresentationEx ppt = new Aspose.Slides.Pptx.PresentationEx(convertFile);

                string dirName = string.Format("{0}.image", convertFile.Substring(convertFile.LastIndexOf('\\') + 1)); //转换后的图片存放目录
                dirPath = dirPath ?? HttpContext.Current.Server.MapPath(string.Format("/ConvertFiles/ppt/{0}/", dirName));

                if (!Directory.Exists(dirPath))
                {
                    Directory.CreateDirectory(dirPath);
                }
                else
                {
                    if (ignoreExist)
                    {
                        Directory.Delete(dirPath, true);
                        Directory.CreateDirectory(dirPath);
                    }
                    else
                    {
                        return true;
                    }
                }

                ppt.Save(string.Format("{0}\\{1}.{2}", dirPath, 1, "pdf"), Aspose.Slides.Export.SaveFormat.Pdf);
                total++;

                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 将PPTX文档转换为图片的方法（先转为pdf，再转为图片）
        /// </summary>
        /// <param name="total">转换后图片的总数</param>
        /// <param name="convertFile">要转换的pptx文件（物理路径）</param>
        /// <param name="dirPath">保存到指定目录（物理路径）</param>
        /// <param name="ignoreExist">已进行过转换的文件是否要重新转换</param>
        public static bool PPTX2ImageConverter(out int total, string convertFile, string dirPath = null, bool ignoreExist = false)
        {
            total = 0;
            try
            {
                Aspose.Slides.Pptx.PresentationEx ppt = new Aspose.Slides.Pptx.PresentationEx(convertFile);

                string dirName = string.Format("{0}.image", convertFile.Substring(convertFile.LastIndexOf('\\') + 1)); //转换后的图片存放目录
                dirPath = dirPath ?? HttpContext.Current.Server.MapPath(string.Format("/ConvertFiles/ppt/{0}/", dirName));

                if (!Directory.Exists(dirPath))
                {
                    Directory.CreateDirectory(dirPath);
                }
                else
                {
                    if (ignoreExist)
                    {
                        Directory.Delete(dirPath, true);
                        Directory.CreateDirectory(dirPath);
                    }
                    else
                    {
                        return true;
                    }
                }

                string targetFile = string.Format("{0}\\{1}.{2}", dirPath, 1, "pdf");
                //保存为pdf
                ppt.Save(targetFile, Aspose.Slides.Export.SaveFormat.Pdf);
                //根据pdf生成图片，然后删除pdf
                Document pdfDocument = new Document(targetFile);
                for (var i = 0; i < pdfDocument.Pages.Count; i++)
                {
                    using (FileStream imageStream = new FileStream(string.Format("{0}\\{1}.png", dirPath, (i + 1)), FileMode.Create))
                    {
                        Resolution resolution = new Resolution(100);
                        JpegDevice jpegDevice = new JpegDevice(resolution, 70);
                        //convert a particular page and save the image to stream
                        jpegDevice.Process(pdfDocument.Pages[i + 1], imageStream);
                        //close stream
                        imageStream.Close();
                        total++;
                    }
                }
                File.Delete(targetFile);
                return true;
            }
            catch
            {
                Directory.Delete(dirPath, true);
                return false;
            }
        }

    }
}