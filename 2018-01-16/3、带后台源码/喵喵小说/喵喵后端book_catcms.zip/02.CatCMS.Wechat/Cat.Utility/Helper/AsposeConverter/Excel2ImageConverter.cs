﻿using Aspose.Cells;
using Aspose.Cells.Rendering;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;

namespace Cat.Utility
{
    /// <summary>
    /// Aspose转换帮助类
    /// </summary>
    public partial class AsposeConverterHelper
    {
        /// <summary>
        /// 将Excel文档转换为图片的方法
        /// </summary>
        /// <param name="total">转换后图片的总数</param>
        /// <param name="convertFile">要转换的excel文件（物理路径）</param>
        /// <param name="dirPath">保存到指定目录（物理路径）</param>
        /// <param name="ignoreExist">已进行过转换的文件是否要重新转换</param>
        public static bool Excel2ImageConverter(out int total, string convertFile, string dirPath = null, bool ignoreExist = false)
        {
            total = 0;
            try
            {
                Workbook book = new Workbook(convertFile);
                string dirName = string.Format("{0}.image", convertFile.Substring(convertFile.LastIndexOf('\\') + 1)); //转换后的图片存放目录
                dirPath = dirPath ?? HttpContext.Current.Server.MapPath(string.Format("/ConvertFiles/excel/{0}/", dirName));

                if (!Directory.Exists(dirPath))
                {
                    Directory.CreateDirectory(dirPath);
                }
                else
                {
                    if (ignoreExist)
                    {
                        Directory.Delete(dirPath, true);
                        Directory.CreateDirectory(dirPath);
                    }
                    else
                    {
                        return true;
                    }
                }

                for (var bookIndex = 0; bookIndex < book.Worksheets.Count; bookIndex++)
                {
                    Worksheet sheet = book.Worksheets[bookIndex];
                    ImageOrPrintOptions imgOptions = new ImageOrPrintOptions();
                    imgOptions.ImageFormat = ImageFormat.Png;
                    imgOptions.OnePagePerSheet = true;
                    imgOptions.PrintingPage = PrintingPageType.IgnoreBlank;
                    imgOptions.Quality = 100;
                    SheetRender sr = new SheetRender(sheet, imgOptions);
                    for (int i = 0; i < sr.PageCount; i++)
                    {
                        sr.ToImage(i, string.Format("{0}\\{1}.{2}", dirPath, i + 1 + bookIndex, imgOptions.ImageFormat));
                        total++;
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}