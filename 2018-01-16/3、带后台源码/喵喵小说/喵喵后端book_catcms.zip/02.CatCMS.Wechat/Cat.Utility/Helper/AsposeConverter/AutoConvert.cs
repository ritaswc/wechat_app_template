﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cat.Utility
{
    /// <summary>
    /// Aspose转换帮助类
    /// </summary>
    public partial class AsposeConverterHelper
    {
        /// <summary>
        /// 文档转换为图片的方法(自动识别文档类型)
        /// </summary>
        /// <param name="extension">文件的扩展名</param>
        /// <param name="total">转换后图片的总数</param>
        /// <param name="convertFile">要转换的文件（物理路径）</param>
        /// <param name="dirPath">保存到指定目录（物理路径）</param>
        /// <param name="ignoreExist">已进行过转换的文件是否要重新转换</param>
        public static bool AutoConvert(string extension, out int total, string convertFile, out string dirPath)
        {
            bool flag = false;
            total = 0;
            string fileName = System.IO.Path.GetFileName(convertFile);
            dirPath = "/UploadFiles/Convert";

            switch (extension.ToLower())
            {
                case ".xls":
                    dirPath = string.Format("{0}/{1}/{2}", dirPath, "xls", fileName);
                    flag = AsposeConverterHelper.Excel2ImageConverter(out total, convertFile, PathHelper.GetMapPath(dirPath), false);
                    break;
                case ".xlsx":
                    dirPath = string.Format("{0}/{1}/{2}", dirPath, "xlsx", fileName);
                    flag = AsposeConverterHelper.Excel2ImageConverter(out total, convertFile, PathHelper.GetMapPath(dirPath), false);
                    break;
                case ".doc":
                    dirPath = string.Format("{0}/{1}/{2}", dirPath, "doc", fileName);
                    flag = AsposeConverterHelper.Word2ImageConverter(out total, convertFile, PathHelper.GetMapPath(dirPath), false);
                    break;
                case ".docx":
                    dirPath = string.Format("{0}/{1}/{2}", dirPath, "docx", fileName);
                    flag = AsposeConverterHelper.Word2ImageConverter(out total, convertFile, PathHelper.GetMapPath(dirPath), false);
                    break;
                case ".ppt":
                    dirPath = string.Format("{0}/{1}/{2}", dirPath, "ppt", fileName);
                    flag = AsposeConverterHelper.PPT2ImageConverter(out total, convertFile, PathHelper.GetMapPath(dirPath), false);
                    break;
                case ".pptx":
                    dirPath = string.Format("{0}/{1}/{2}", dirPath, "pptx", fileName);
                    flag = AsposeConverterHelper.PPTX2ImageConverter(out total, convertFile, PathHelper.GetMapPath(dirPath), false);
                    break;
                case ".pdf":
                    dirPath = string.Format("{0}/{1}/{2}", dirPath, "pdf", fileName);
                    flag = AsposeConverterHelper.Pdf2ImageConverter(out total, convertFile, PathHelper.GetMapPath(dirPath), false);
                    break;
            }
            return flag;
        }
    }
}
