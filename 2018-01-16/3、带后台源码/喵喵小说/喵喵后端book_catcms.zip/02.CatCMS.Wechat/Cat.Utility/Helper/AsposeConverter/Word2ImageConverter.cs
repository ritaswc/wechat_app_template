﻿using Aspose.Words;
using Aspose.Words.Saving;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Cat.Utility
{
    /// <summary>
    /// Aspose转换帮助类
    /// </summary>
    public partial class AsposeConverterHelper
    {
        /// <summary>
        /// 将Word文档转换为图片的方法
        /// </summary>
        /// <param name="total">转换后图片的总数</param>
        /// <param name="convertFile">要转换的word文件（物理路径）</param>
        /// <param name="dirPath">保存到指定目录（物理路径）</param>
        /// <param name="ignoreExist">已进行过转换的文件是否要重新转换</param>
        public static bool Word2ImageConverter(out int total, string convertFile, string dirPath = null, bool ignoreExist = false)
        {
            total = 0;
            try
            {
                Document doc = new Document(convertFile);
                ImageSaveOptions iso = new ImageSaveOptions(SaveFormat.Png);
                iso.JpegQuality = 100;
                iso.Resolution = 100;
                iso.PrettyFormat = true;
                iso.UseAntiAliasing = true;
                string dirName = string.Format("{0}.image", convertFile.Substring(convertFile.LastIndexOf('\\') + 1)); //转换后的图片存放目录
                dirPath = dirPath ?? HttpContext.Current.Server.MapPath(string.Format("/ConvertFiles/word/{0}/", dirName));

                if (!Directory.Exists(dirPath))
                {
                    Directory.CreateDirectory(dirPath);
                }
                else
                {
                    if (ignoreExist)
                    {
                        Directory.Delete(dirPath, true);
                        Directory.CreateDirectory(dirPath);
                    }
                    else
                    {
                        return true;
                    }
                }

                for (int i = 0; i < doc.PageCount; i++)
                {
                    iso.PageIndex = i;
                    doc.Save(string.Format("{0}\\{1}.{2}", dirPath, i + 1, iso.SaveFormat), iso);
                    total++;
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}