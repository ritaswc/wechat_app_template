﻿using Aspose.Pdf;
using Aspose.Pdf.Devices;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Cat.Utility
{
    /// <summary>
    /// Aspose转换帮助类
    /// </summary>
    public partial class AsposeConverterHelper
    {
        /// <summary>
        /// 将Pdf文档转换为图片的方法
        /// </summary>
        /// <param name="total">转换后图片的总数</param>
        /// <param name="convertFile">要转换的pdf文件（物理路径）</param>
        /// <param name="dirPath">保存到指定目录（物理路径）</param>
        /// <param name="ignoreExist">已进行过转换的文件是否要重新转换</param>
        public static bool Pdf2ImageConverter(out int total, string convertFile, string dirPath = null, bool ignoreExist = false)
        {
            total = 0;
            try
            {
                //open document
                Document pdfDocument = new Document(convertFile);

                string dirName = string.Format("{0}.image", convertFile.Substring(convertFile.LastIndexOf('\\') + 1)); //转换后的图片存放目录
                dirPath = dirPath ?? HttpContext.Current.Server.MapPath(string.Format("/ConvertFiles/pdf/{0}/", dirName));

                if (!Directory.Exists(dirPath))
                {
                    Directory.CreateDirectory(dirPath);
                }
                else
                {
                    if (ignoreExist)
                    {
                        Directory.Delete(dirPath, true);
                        Directory.CreateDirectory(dirPath);
                    }
                    else
                    {
                        return true;
                    }
                }

                for (var i = 0; i < pdfDocument.Pages.Count; i++)
                {
                    using (FileStream imageStream = new FileStream(string.Format("{0}\\{1}.png", dirPath, (i + 1)), FileMode.Create))
                    {
                        Resolution resolution = new Resolution(100);
                        JpegDevice jpegDevice = new JpegDevice(resolution, 70);
                        //convert a particular page and save the image to stream
                        jpegDevice.Process(pdfDocument.Pages[i + 1], imageStream);
                        //close stream
                        imageStream.Close();
                        total++;
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}