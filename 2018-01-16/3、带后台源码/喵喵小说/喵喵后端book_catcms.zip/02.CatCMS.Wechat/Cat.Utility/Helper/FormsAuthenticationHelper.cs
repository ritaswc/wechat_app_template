﻿using System;
using System.Web;
using System.Web.Security;

namespace Cat.Utility
{
    /// <summary>
    /// 身份验证票据帮助类
    /// </summary>
    /// <typeparam name="T">应传入用户信息实体类</typeparam>
    public class FormsAuthenticationHelper<T> where T : class
    {
        /// <summary>
        /// 创建身份验证票据
        /// </summary>
        /// <param name="userId">用户id</param>
        /// <param name="t">用户信息实例</param>
        public static bool SetAuthCookie(string userId, T t)
        {
            try
            {
                FormsAuthenticationTicket ticket = new FormsAuthenticationTicket
                         (1,
                             userId,
                             DateTime.Now,
                             DateTime.Now.AddHours(12),
                             true,
                             Serializer.JsonSerialize(t),
                             "/"
                         );
                var cookie = new HttpCookie(FormsAuthentication.FormsCookieName, FormsAuthentication.Encrypt(ticket));
                cookie.HttpOnly = true;
                cookie.Expires = DateTime.Now.AddHours(12);
                HttpContext.Current.Response.Cookies.Add(cookie);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 获取与 Forms 身份验证票相关联的用户Id
        /// </summary>
        /// <returns></returns>
        public static string GetUserId()
        {
            var ticket = GetTiket();
            return ticket == null ? null : ticket.Name;
        }

        /// <summary>
        /// 获取一个存储在票证中的用户信息的实例
        /// </summary>
        /// <returns></returns>
        public static T GetUserInstance()
        {
            var ticket = GetTiket();
            if (ticket == null || string.IsNullOrEmpty(ticket.UserData))
                return null;
            return Serializer.JsonDeserialize<T>(ticket.UserData);
            //return JsonConvert.DeserializeObject<T>(ticket.UserData);
        }

        private static FormsAuthenticationTicket GetTiket()
        {
            var cookie = HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName];
            return cookie == null ? null : FormsAuthentication.Decrypt(cookie.Value);
        }

    }
}