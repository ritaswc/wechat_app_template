﻿using System.Web;

namespace Cat.Utility
{
    public class RequestHelper
    {
        #region 取得页面参数,兼容Get和Post两种方式
        /// <summary>
        /// 取得参数兼容Get和Post两种方式
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static string GetParms(string name)
        {
            if (HttpContext.Current != null)
            {
                var request = HttpContext.Current.Request;
                for (int i = 0; i < request.Form.Count; i++)
                {
                    if (request.Form.Keys[i].ToLower() == name.ToLower())
                    {
                        return request.Form[i];
                    }
                }
                for (int i = 0; i < request.QueryString.Count; i++)
                {
                    if (request.QueryString.Keys[i].ToLower() == name.ToLower())
                    {
                        return request.QueryString[i];
                    }
                }
            }
            return string.Empty;
        }
        #endregion
    }
}