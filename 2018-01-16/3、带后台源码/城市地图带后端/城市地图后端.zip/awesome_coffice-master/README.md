# awesome_coffice
![Language](https://img.shields.io/badge/language-Python-blue.svg?style=flat-square) ![License](https://img.shields.io/badge/license-MIT-blue.svg?style=flat-square)

AwesomeCoffice 微信小程序的 Django 后端 API，djangorestframework 和 JWT 加持。

## requirement.txt

### avatar-generator need some tweek

[avatar-generator](https://github.com/maethor/avatar-generator)

pip version is broken, use git version.

```shell
pip install git+https://github.com/maethor/avatar-generator.git
```

