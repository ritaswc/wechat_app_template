from django.apps import AppConfig


class CoffeeConfig(AppConfig):
    name = 'coffee'
