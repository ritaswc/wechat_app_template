# AwesomeCoffice

![Language](https://img.shields.io/badge/language-Node.js-brightgreen.svg?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-blue.svg?style=flat-square)

微信小程序：与自由工作者、程序员、设计师分享适合办公的咖啡馆、面包店

数据来源于: [ElaWorkshop/awesome-cn-cafe](https://github.com/ElaWorkshop/awesome-cn-cafe)
