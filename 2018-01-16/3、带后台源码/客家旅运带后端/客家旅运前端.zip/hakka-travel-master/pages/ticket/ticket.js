//ticket.js
//获取应用实例
const app = getApp()
Page({
  data: {
   
  },
  onLoad: function () {
      wx.showToast({
        title: ''
      })
  }
})
