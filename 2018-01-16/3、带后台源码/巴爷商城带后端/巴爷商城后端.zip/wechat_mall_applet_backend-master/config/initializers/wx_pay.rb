WxPay.appid = ENV['weapplet_app_id']
WxPay.key = ENV['WECHAT_STORE_KEY']
WxPay.mch_id = ENV['WECHAT_STORE_ID']
WxPay.debug_mode = false # default is `true`