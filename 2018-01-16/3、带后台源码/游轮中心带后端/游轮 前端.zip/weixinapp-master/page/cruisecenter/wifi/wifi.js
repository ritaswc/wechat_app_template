var WxParse = require('../../wxParse/wxParse.js');
Page({
  data: {
  },
  onLoad: function () {
    /*  
    wx.request({
        url: 'https://service.huiyoulun.com:80/services/getOption?id=24&openid=odZ6Yt8p5aYs5tOoWHosE8IyyzWI', 
        data: {
            
        },
        header: {
            'content-type': 'application/json'
        },
        success: function(res) {
            console.log(res.data)
            var article = res.data;
            var that = this;
            WxParse.wxParse('article', 'html', article, that,5);
        }
    })*/
  }
})

