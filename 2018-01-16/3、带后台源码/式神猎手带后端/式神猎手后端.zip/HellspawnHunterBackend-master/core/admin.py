from django.contrib import admin
from models import *

# Register your models here.

admin.site.register(Hellspawn)
admin.site.register(Scene)
admin.site.register(Secret)
admin.site.register(Membership)
admin.site.register(Team)
admin.site.register(Feedback)
admin.site.register(WeUser)
