# girls
小程序demo     
1、将php文件夹的文件，放到服务器跟目录，修改你服务器上的数据库名称，用户名密码。

2、将data文件下的db.sql数据导入你的数据库

3、将剩下的文件，全部放入小程序的目录


具体请参考
http://www.iamaddy.net/2017/04/create-little-programe-by-yourself/
