# weixin-xiaochengxu-music-client
微信小程序测试项目提供简单的在线播放音乐功能
