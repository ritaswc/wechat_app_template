# weixin-xiaochengxu-music-servlet
微信小程序测试项目提供简单的在线播放音乐功能-服务端程序（java）
