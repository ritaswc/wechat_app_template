<template>
  <div id="mapp">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
}
</script>

