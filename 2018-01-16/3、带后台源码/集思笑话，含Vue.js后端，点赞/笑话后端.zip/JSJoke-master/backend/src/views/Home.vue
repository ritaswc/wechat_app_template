<template>
  <div class="home">
    {{msg}}
  </div>
</template>

<script>
export default {
  data () {
    return {
      msg: '欢迎来到JSJoke'
    }
  }
}
</script>

